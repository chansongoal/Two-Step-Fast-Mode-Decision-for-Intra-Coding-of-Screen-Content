/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TEncCu.cpp
    \brief    Coding Unit (CU) encoder class
*/

#include <stdio.h>
#include "TEncTop.h"
#include "TEncCu.h"
#include "TEncAnalyze.h"
#include "TLibCommon/Debug.h"

#include <cmath>
#include <algorithm>
using namespace std;
#if LBCFMD
Int frame = -1;
#include "../App/TAppEncoder/TAppEncCfg.h"
#endif


//! \ingroup TLibEncoder
//! \{

// ====================================================================================================================
// Constructor / destructor / create / destroy
// ====================================================================================================================

/**
 \param    uhTotalDepth  total number of allowable depth
 \param    uiMaxWidth    largest CU width
 \param    uiMaxHeight   largest CU height
 \param    chromaFormat  chroma format
 */
Void TEncCu::create(UChar uhTotalDepth, UInt uiMaxWidth, UInt uiMaxHeight, ChromaFormat chromaFormat
                    , UInt uiPLTMaxSize, UInt uiPLTMaxPredSize
  )
{
  Int i;

  m_uhTotalDepth   = uhTotalDepth + 1;
  m_ppcBestCU      = new TComDataCU*[m_uhTotalDepth-1];
  m_ppcTempCU      = new TComDataCU*[m_uhTotalDepth-1];

  m_ppcPredYuvBest = new TComYuv*[m_uhTotalDepth-1];
  m_ppcResiYuvBest = new TComYuv*[m_uhTotalDepth-1];
  m_ppcRecoYuvBest = new TComYuv*[m_uhTotalDepth-1];
  m_ppcPredYuvTemp = new TComYuv*[m_uhTotalDepth-1];
  m_ppcResiYuvTemp = new TComYuv*[m_uhTotalDepth-1];
  m_ppcRecoYuvTemp = new TComYuv*[m_uhTotalDepth-1];
  m_ppcOrigYuv     = new TComYuv*[m_uhTotalDepth-1];
  m_ppcNoCorrYuv   = new TComYuv*[m_uhTotalDepth-1];

  UInt uiNumPartitions;
  for( i=0 ; i<m_uhTotalDepth-1 ; i++)
  {
    uiNumPartitions = 1<<( ( m_uhTotalDepth - i - 1 )<<1 );
    UInt uiWidth  = uiMaxWidth  >> i;
    UInt uiHeight = uiMaxHeight >> i;

    m_ppcBestCU[i] = new TComDataCU; m_ppcBestCU[i]->create( chromaFormat, uiNumPartitions, uiWidth, uiHeight, false, uiMaxWidth >> (m_uhTotalDepth - 1)
                 ,uiPLTMaxSize, uiPLTMaxPredSize
   );
    m_ppcTempCU[i] = new TComDataCU; m_ppcTempCU[i]->create( chromaFormat, uiNumPartitions, uiWidth, uiHeight, false, uiMaxWidth >> (m_uhTotalDepth - 1)
                    ,uiPLTMaxSize, uiPLTMaxPredSize
   );

    m_ppcPredYuvBest[i] = new TComYuv; m_ppcPredYuvBest[i]->create(uiWidth, uiHeight, chromaFormat);
    m_ppcResiYuvBest[i] = new TComYuv; m_ppcResiYuvBest[i]->create(uiWidth, uiHeight, chromaFormat);
    m_ppcRecoYuvBest[i] = new TComYuv; m_ppcRecoYuvBest[i]->create(uiWidth, uiHeight, chromaFormat);

    m_ppcPredYuvTemp[i] = new TComYuv; m_ppcPredYuvTemp[i]->create(uiWidth, uiHeight, chromaFormat);
    m_ppcResiYuvTemp[i] = new TComYuv; m_ppcResiYuvTemp[i]->create(uiWidth, uiHeight, chromaFormat);
    m_ppcRecoYuvTemp[i] = new TComYuv; m_ppcRecoYuvTemp[i]->create(uiWidth, uiHeight, chromaFormat);

    m_ppcOrigYuv    [i] = new TComYuv; m_ppcOrigYuv    [i]->create(uiWidth, uiHeight, chromaFormat);
    m_ppcNoCorrYuv  [i] = new TComYuv; m_ppcNoCorrYuv  [i]->create(uiWidth, uiHeight, chromaFormat);
  }

  m_bEncodeDQP                     = false;
  m_stillToCodeChromaQpOffsetFlag  = false;
  m_cuChromaQpOffsetIdxPlus1       = 0;
  m_bFastDeltaQP                   = false;

  // initialize partition order.
  UInt* piTmp = &g_auiZscanToRaster[0];
  initZscanToRaster( m_uhTotalDepth, 1, 0, piTmp);
  initRasterToZscan( uiMaxWidth, uiMaxHeight, m_uhTotalDepth );

  // initialize conversion matrix from partition index to pel
  initRasterToPelXY( uiMaxWidth, uiMaxHeight, m_uhTotalDepth );
}

Void TEncCu::destroy()
{
  Int i;

  for( i=0 ; i<m_uhTotalDepth-1 ; i++)
  {
    if(m_ppcBestCU[i])
    {
      m_ppcBestCU[i]->destroy();      delete m_ppcBestCU[i];      m_ppcBestCU[i] = NULL;
    }
    if(m_ppcTempCU[i])
    {
      m_ppcTempCU[i]->destroy();      delete m_ppcTempCU[i];      m_ppcTempCU[i] = NULL;
    }
    if(m_ppcPredYuvBest[i])
    {
      m_ppcPredYuvBest[i]->destroy(); delete m_ppcPredYuvBest[i]; m_ppcPredYuvBest[i] = NULL;
    }
    if(m_ppcResiYuvBest[i])
    {
      m_ppcResiYuvBest[i]->destroy(); delete m_ppcResiYuvBest[i]; m_ppcResiYuvBest[i] = NULL;
    }
    if(m_ppcRecoYuvBest[i])
    {
      m_ppcRecoYuvBest[i]->destroy(); delete m_ppcRecoYuvBest[i]; m_ppcRecoYuvBest[i] = NULL;
    }
    if(m_ppcPredYuvTemp[i])
    {
      m_ppcPredYuvTemp[i]->destroy(); delete m_ppcPredYuvTemp[i]; m_ppcPredYuvTemp[i] = NULL;
    }
    if(m_ppcResiYuvTemp[i])
    {
      m_ppcResiYuvTemp[i]->destroy(); delete m_ppcResiYuvTemp[i]; m_ppcResiYuvTemp[i] = NULL;
    }
    if(m_ppcRecoYuvTemp[i])
    {
      m_ppcRecoYuvTemp[i]->destroy(); delete m_ppcRecoYuvTemp[i]; m_ppcRecoYuvTemp[i] = NULL;
    }
    if(m_ppcOrigYuv[i])
    {
      m_ppcOrigYuv[i]->destroy();     delete m_ppcOrigYuv[i];     m_ppcOrigYuv[i] = NULL;
    }
    if(m_ppcNoCorrYuv[i])
    {
      m_ppcNoCorrYuv[i]->destroy();   delete m_ppcNoCorrYuv[i];   m_ppcNoCorrYuv[i] = NULL;
    }
  }
  if(m_ppcBestCU)
  {
    delete [] m_ppcBestCU;
    m_ppcBestCU = NULL;
  }
  if(m_ppcTempCU)
  {
    delete [] m_ppcTempCU;
    m_ppcTempCU = NULL;
  }

  if(m_ppcPredYuvBest)
  {
    delete [] m_ppcPredYuvBest;
    m_ppcPredYuvBest = NULL;
  }
  if(m_ppcResiYuvBest)
  {
    delete [] m_ppcResiYuvBest;
    m_ppcResiYuvBest = NULL;
  }
  if(m_ppcRecoYuvBest)
  {
    delete [] m_ppcRecoYuvBest;
    m_ppcRecoYuvBest = NULL;
  }
  if(m_ppcPredYuvTemp)
  {
    delete [] m_ppcPredYuvTemp;
    m_ppcPredYuvTemp = NULL;
  }
  if(m_ppcResiYuvTemp)
  {
    delete [] m_ppcResiYuvTemp;
    m_ppcResiYuvTemp = NULL;
  }
  if(m_ppcRecoYuvTemp)
  {
    delete [] m_ppcRecoYuvTemp;
    m_ppcRecoYuvTemp = NULL;
  }
  if(m_ppcOrigYuv)
  {
    delete [] m_ppcOrigYuv;
    m_ppcOrigYuv = NULL;
  }
  if(m_ppcNoCorrYuv)
  {
    delete [] m_ppcNoCorrYuv;
    m_ppcNoCorrYuv = NULL;
  }
}

/** \param    pcEncTop      pointer of encoder class
 */
Void TEncCu::init( TEncTop* pcEncTop )
{
  m_pcEncCfg           = pcEncTop;
  m_pcPredSearch       = pcEncTop->getPredSearch();
  m_pcTrQuant          = pcEncTop->getTrQuant();
  m_pcRdCost           = pcEncTop->getRdCost();

  m_pcEntropyCoder     = pcEncTop->getEntropyCoder();
  m_pcBinCABAC         = pcEncTop->getBinCABAC();

  m_pppcRDSbacCoder    = pcEncTop->getRDSbacCoder();
  m_pcRDGoOnSbacCoder  = pcEncTop->getRDGoOnSbacCoder();

  m_pcRateCtrl         = pcEncTop->getRateCtrl();
}

// ====================================================================================================================
// Public member functions
// ====================================================================================================================

/** 
 \param  pCtu pointer of CU data class
 */
Void TEncCu::compressCtu( TComDataCU* pCtu, UChar* lastPLTSize, UChar* lastPLTUsedSize, Pel lastPLT[][MAX_PLT_PRED_SIZE] )
{
  // initialize CU data
  m_ppcBestCU[0]->initCtu( pCtu->getPic(), pCtu->getCtuRsAddr() );
  m_ppcTempCU[0]->initCtu( pCtu->getPic(), pCtu->getCtuRsAddr() );

#if LBCFMD
  string CNNstep1_CTU[4] = {"4","4","4","4"};
  string CNNstep1_LeftCTU[4] = { "4","4","4","4" };
  string CNNstep1_AboveCTU[4] = { "4","4","4","4" };
  string CNNstep2_CTU[4] = { "4","4","4","4" };

  Int index = pCtu->getCtuRsAddr();
  
  if (pCtu->getCtuRsAddr() == 0)
  {
	  frame++;
  }

  Int picCol = Column >> 1;

//above CTU
  if (((index / picCol) << 1) != 0)
  {
	  CNNstep1_AboveCTU[2] = CNNResult[frame][((index / picCol) << 1) - 1][((index % picCol) << 1)];
	  CNNstep1_AboveCTU[3] = CNNResult[frame][((index / picCol) << 1) - 1][((index % picCol) << 1) + 1];
  }
  
//left CTU
  if (((index % picCol) << 1) != 0)
  {
	  CNNstep1_LeftCTU[1] = CNNResult[frame][(index / picCol) << 1][((index % picCol) << 1) - 1];
	  CNNstep1_LeftCTU[3] = CNNResult[frame][((index / picCol) << 1) + 1][((index % picCol) << 1) -1];
  }

  CNNstep1_CTU[0] = CNNResult[frame][(index / picCol) << 1][(index % picCol) << 1];
  CNNstep1_CTU[1] = CNNResult[frame][(index / picCol) << 1][((index % picCol) << 1) + 1];
  CNNstep1_CTU[2] = CNNResult[frame][((index / picCol) << 1)+ 1][(index % picCol) << 1];
  CNNstep1_CTU[3] = CNNResult[frame][((index / picCol) << 1) + 1][((index % picCol) << 1) + 1];

  CNNstep2_CTU[0] = CNNStep2Result[frame][(index / picCol) << 1][(index % picCol) << 1];
  CNNstep2_CTU[1] = CNNStep2Result[frame][(index / picCol) << 1][((index % picCol) << 1) + 1];
  CNNstep2_CTU[2] = CNNStep2Result[frame][((index / picCol) << 1) + 1][(index % picCol) << 1];
  CNNstep2_CTU[3] = CNNStep2Result[frame][((index / picCol) << 1) + 1][((index % picCol) << 1) + 1];
#endif

  for (UChar comp = 0; comp < MAX_NUM_COMPONENT; comp++)
  {
    m_ppcBestCU[0]->setLastPLTInLcuSizeFinal(comp, lastPLTSize[comp]);
    m_ppcTempCU[0]->setLastPLTInLcuSizeFinal(comp, lastPLTSize[comp]);
    for (UInt idx = 0; idx < pCtu->getSlice()->getSPS()->getSpsScreenExtension().getPLTMaxPredSize(); idx++)
    {
      m_ppcBestCU[0]->setLastPLTInLcuFinal(comp, lastPLT[comp][idx], idx);
      m_ppcTempCU[0]->setLastPLTInLcuFinal(comp, lastPLT[comp][idx], idx);
    }
  }

  // analysis of CU
  DEBUG_STRING_NEW(sDebug)

  xCompressCU( m_ppcBestCU[0], m_ppcTempCU[0], 0 DEBUG_STRING_PASS_INTO(sDebug) 
#if LBCFMD
  , CNNstep1_CTU, CNNstep1_LeftCTU, CNNstep1_AboveCTU, CNNstep2_CTU,pCtu
#endif
  );
  DEBUG_STRING_OUTPUT(std::cout, sDebug)

#if ADAPTIVE_QP_SELECTION
  if( m_pcEncCfg->getUseAdaptQpSelect() )
  {
    if(pCtu->getSlice()->getSliceType()!=I_SLICE) //IIII
    {
      xCtuCollectARLStats( pCtu );
    }
  }
#endif
}
/** \param  pCtu  pointer of CU data class
 */
Void TEncCu::encodeCtu ( TComDataCU* pCtu )
{
  if ( pCtu->getSlice()->getPPS()->getUseDQP() )
  {
    setdQPFlag(true);
  }

  if ( pCtu->getSlice()->getUseChromaQpAdj() )
  {
    setCodeChromaQpAdjFlag(true);
  }

  // Encode CU data
  xEncodeCU( pCtu, 0, 0 );
}

// ====================================================================================================================
// Protected member functions
// ====================================================================================================================
//! Derive small set of test modes for AMP encoder speed-up
#if AMP_ENC_SPEEDUP
#if AMP_MRG
Void TEncCu::deriveTestModeAMP (TComDataCU *pcBestCU, PartSize eParentPartSize, Bool &bTestAMP_Hor, Bool &bTestAMP_Ver, Bool &bTestMergeAMP_Hor, Bool &bTestMergeAMP_Ver)
#else
Void TEncCu::deriveTestModeAMP (TComDataCU *pcBestCU, PartSize eParentPartSize, Bool &bTestAMP_Hor, Bool &bTestAMP_Ver)
#endif
{
  if ( pcBestCU->getPartitionSize(0) == SIZE_2NxN )
  {
    bTestAMP_Hor = true;
  }
  else if ( pcBestCU->getPartitionSize(0) == SIZE_Nx2N )
  {
    bTestAMP_Ver = true;
  }
  else if ( pcBestCU->getPartitionSize(0) == SIZE_2Nx2N && pcBestCU->getMergeFlag(0) == false && pcBestCU->isSkipped(0) == false )
  {
    bTestAMP_Hor = true;
    bTestAMP_Ver = true;
  }

#if AMP_MRG
  //! Utilizing the partition size of parent PU
  if ( eParentPartSize >= SIZE_2NxnU && eParentPartSize <= SIZE_nRx2N )
  {
    bTestMergeAMP_Hor = true;
    bTestMergeAMP_Ver = true;
  }

  if ( eParentPartSize == NUMBER_OF_PART_SIZES ) //! if parent is intra
  {
    if ( pcBestCU->getPartitionSize(0) == SIZE_2NxN )
    {
      bTestMergeAMP_Hor = true;
    }
    else if ( pcBestCU->getPartitionSize(0) == SIZE_Nx2N )
    {
      bTestMergeAMP_Ver = true;
    }
  }

  if ( pcBestCU->getPartitionSize(0) == SIZE_2Nx2N && pcBestCU->isSkipped(0) == false )
  {
    bTestMergeAMP_Hor = true;
    bTestMergeAMP_Ver = true;
  }

  if ( pcBestCU->getWidth(0) == 64 )
  {
    bTestAMP_Hor = false;
    bTestAMP_Ver = false;
  }
#else
  //! Utilizing the partition size of parent PU
  if ( eParentPartSize >= SIZE_2NxnU && eParentPartSize <= SIZE_nRx2N )
  {
    bTestAMP_Hor = true;
    bTestAMP_Ver = true;
  }

  if ( eParentPartSize == SIZE_2Nx2N )
  {
    bTestAMP_Hor = false;
    bTestAMP_Ver = false;
  }
#endif
}
#endif



// ====================================================================================================================
// Static function
// ====================================================================================================================
/** Calculates the minimum of the H and V luma activity of a CU in the source image.
 *\param   pcCU
 *\param   uiAbsPartIdx
 *\param   ppcOrigYuv
 *\returns Intermediate_Int
 *
*/
static Intermediate_Int
CalculateMinimumHVLumaActivity(TComDataCU *pcCU, const UInt uiAbsPartIdx, const TComYuv * const * const ppcOrigYuv)
{
  const TComYuv *pOrgYuv = ppcOrigYuv[pcCU->getDepth(uiAbsPartIdx)];
  const Int      stride  = pOrgYuv->getStride(COMPONENT_Y);
  const Int      width   = pcCU->getWidth(uiAbsPartIdx);
  const Int      height  = pcCU->getHeight(uiAbsPartIdx);

  // Get activity
  Intermediate_Int hAct = 0;
  const Pel *pY = pOrgYuv->getAddr(COMPONENT_Y, uiAbsPartIdx);
  for (Int y = 0; y < height; y++)
  {
    for (Int x = 1; x < width; x++)
    {
      hAct += abs( pY[x] - pY[x - 1]);
    }
    pY += stride;
  }

  Intermediate_Int vAct = 0;
  pY = pOrgYuv->getAddr(COMPONENT_Y, 0) + stride;
  for (Int y = 1; y < height; y++)
  {
    for (Int x = 0; x < width; x++)
    {
      vAct += abs(pY[x] - pY[x - stride]);
    }
    pY += stride;
  }

  return std::min(hAct, vAct);
}

Void TEncCu::setEnableIntraTUACT(UInt uiDepth, TComSlice* pcSlice)
{
  if( m_pcEncCfg->getRGBFormatFlag() )
  {
    m_bEnableIntraTUACTRD = true;
    if( (m_pcEncCfg->getGOPSize() == 8 && pcSlice->getDepth() == 3) || (m_pcEncCfg->getGOPSize() == 4 && pcSlice->getDepth() != 2) || (uiDepth < 3) )
    {
      m_bEnableIntraTUACTRD = false;
    }
  }
  else
  {
    m_bEnableIntraTUACTRD = false;
  }
}

Void TEncCu::setEnableIBCTUACT(UInt uiDepth, TComSlice* pcSlice)
{
  if( m_pcEncCfg->getRGBFormatFlag() )
  {
    m_bEnableIBCTUACTRD = true;
    if( (m_pcEncCfg->getGOPSize() == 8 && pcSlice->getDepth() == 3) || (m_pcEncCfg->getGOPSize() == 4 && pcSlice->getDepth() != 2) || (uiDepth < 3) )
    {
      m_bEnableIBCTUACTRD = false;
    }
  }
  else
  {
    m_bEnableIBCTUACTRD = false;
  }
}

Void TEncCu::setEnableInterTUACT(UInt uiDepth, TComSlice* pcSlice)
{
  if( m_pcEncCfg->getRGBFormatFlag() )
  {
    m_bEnableInterTUACTRD = true;
    if( (pcSlice->getDepth() == 0) || (uiDepth < 2) )
    {
      m_bEnableInterTUACTRD = false;
    }
  }
  else
  {
    m_bEnableInterTUACTRD = false;
  }
}

// ====================================================================================================================
// Protected member functions
// ====================================================================================================================
/** Compress a CU block recursively with enabling sub-CTU-level delta QP
 *  - for loop of QP value to compress the current CU with all possible QP
*/
#if AMP_ENC_SPEEDUP
Void TEncCu::xCompressCU( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, const UInt uiDepth DEBUG_STRING_FN_DECLARE(sDebug_), 
#if LBCFMD
						 string* CNNstep1_CTU, string* CNNstep1_LeftCTU, string* CNNstep1_AboveCTU, string* CNNstep2_CTU,TComDataCU* pCtu,
#endif
						 PartSize eParentPartSize )
#else
Void TEncCu::xCompressCU( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, const UInt uiDepth )
#endif
{
#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
  UInt uiMinDepth = 0;
  UInt uiMaxDepth = 3;
#if ONLY_ENABLE_FOR_NATURE
  if (bEnableAWET)
#endif
  {
	//CU depth above
	const UInt uiNumNeighbor = 3;
	UInt uiDepthNeihbor[uiNumNeighbor];		//above, left, aboveleft, aboveright, belowleft
	UInt uiModeNeihbor[uiNumNeighbor];

	Double dDepthWeight[uiNumNeighbor] = { 3.1, 4.5, 2.4 };		//above, left, aboveleft, colocated
	Double dDepthPred = 0;
	UInt uiAbsPartIdx = rpcTempCU->getZorderIdxInCtu();

	TComDataCU* pNeighbor;
	UInt uiNeighbor;
	pNeighbor = const_cast<TComDataCU*>(rpcTempCU->getPUAbove(uiNeighbor, uiAbsPartIdx));
	getDepthModeNeighbor(pNeighbor, uiNeighbor, uiDepthNeihbor[0], uiModeNeihbor[0], 0, dDepthWeight[0]);

	pNeighbor = const_cast<TComDataCU*>(rpcTempCU->getPULeft(uiNeighbor, uiAbsPartIdx));
	getDepthModeNeighbor(pNeighbor, uiNeighbor, uiDepthNeihbor[1], uiModeNeihbor[1], 1, dDepthWeight[1]);

	pNeighbor = const_cast<TComDataCU*>(rpcTempCU->getPUAboveLeft(uiNeighbor, uiAbsPartIdx));
	getDepthModeNeighbor(pNeighbor, uiNeighbor, uiDepthNeihbor[2], uiModeNeihbor[2], 2, dDepthWeight[2]);

	//UInt uiMinDepth = 0;
	//UInt uiMaxDepth = 3;
	Double dTotalWeight = 0;
	for (UInt n = 0; n < uiNumNeighbor; n++)
	{
	  dTotalWeight += dDepthWeight[n];
	}
	if (dTotalWeight != 0)
	{
	  for (UInt weightIdx = 0; weightIdx < uiNumNeighbor; weightIdx++)
	  {
		dDepthWeight[weightIdx] = dDepthWeight[weightIdx] / dTotalWeight;
		dDepthPred += dDepthWeight[weightIdx] * uiDepthNeihbor[weightIdx];
	  }
	  if (dDepthPred <= th1)
	  {
		uiMinDepth = min1;
		uiMaxDepth = max1;
	  }
	  else if (dDepthPred <= th2)
	  {
		uiMinDepth = min2;
		uiMaxDepth = max2;
	  }
	  else if (dDepthPred <= th3)
	  {
		uiMinDepth = min3;
		uiMaxDepth = max3;
	  }
	  else
	  {
		uiMinDepth = min4;
		uiMaxDepth = max4;
	  }
	}
	else
	{
	  uiMinDepth = 0;
	  uiMaxDepth = 3;
	}
#if SET_SAME_DEPTH
	if ((uiDepthNeihbor[0] == uiDepthNeihbor[1] == uiDepthNeihbor[2]) && (uiDepthNeihbor[0] == 3 || uiDepthNeihbor[0] == 2))
	  //if (uiDepthNeihbor[0] == uiDepthNeihbor[1] == uiDepthNeihbor[2])
	{
	  uiMinDepth = uiDepthNeihbor[0];
	  uiMaxDepth = uiDepthNeihbor[0];
	}
#endif
  }

#endif

#if LBCFMD
	UInt ZIdxInCurCTU = rpcBestCU->getZorderIdxInCtu();
	UInt AbsIdxInCurCTU = g_auiZscanToRaster[ZIdxInCurCTU];
	Bool earlyTermination = false;

	Bool isNature = false;
	Bool isMix = false;

	Bool isText = false;
	Bool isNonText = false;
#if ENABLE_COLOR_PATCH
	Bool isColorPatch = false;
#endif
	Bool isSpecial = false;


	//  nature-screen and text - non-text classfier
	if (uiDepth == 0)
	{
		if (CNNstep1_CTU[0] == "0" && CNNstep1_CTU[1] == "0" && CNNstep1_CTU[2] == "0" && CNNstep1_CTU[3] == "0")
		{
			isNature = true;
		}
		else if (CNNstep1_CTU[0] == "1" && CNNstep1_CTU[1] == "1" && CNNstep1_CTU[2] == "1" && CNNstep1_CTU[3] == "1")
		{
			if (CNNstep2_CTU[0] == "0" && CNNstep2_CTU[1] == "0" && CNNstep2_CTU[2] == "0" && CNNstep2_CTU[3] == "0")
			{
				isText = true;
			}
			else if (CNNstep2_CTU[0] == "1" && CNNstep2_CTU[1] == "1" && CNNstep2_CTU[2] == "1" && CNNstep2_CTU[3] == "1")
			{
				isNonText = true;
			}
#if ENABLE_COLOR_PATCH
			else if (CNNstep2_CTU[0] == "2" && CNNstep2_CTU[1] == "2" && CNNstep2_CTU[2] == "2" && CNNstep2_CTU[3] == "2")
			{
			  isColorPatch = true;
			}
#endif
			else 
			{
				isMix = true;
			}
		}
		else 
		{
			isMix = true; 
		}
	}
	else 
	{
		Int index = rpcTempCU->getZorderIdxInCtu();
		if (index < 64)
		{
			isNature = CNNstep1_CTU[0] == "0" ? true : false;
			if (!isNature)
			{
				isText = CNNstep2_CTU[0] == "0" ? true : false;
#if ENABLE_COLOR_PATCH
				isNonText = CNNstep2_CTU[0] == "1" ? true : false;
				isColorPatch = CNNstep2_CTU[0] == "2" ? true : false;
#else
				isNonText = !isText;
#endif
			}
		}
		else if (index >= 64 && index < 128)
		{
			isNature = CNNstep1_CTU[1] == "0" ? true : false;
			if (!isNature)
			{
				isText = CNNstep2_CTU[1] == "0" ? true : false;
#if ENABLE_COLOR_PATCH
				isNonText = CNNstep2_CTU[1] == "1" ? true : false;
				isColorPatch = CNNstep2_CTU[1] == "2" ? true : false;
#else
				isNonText = !isText;
#endif
			}
		}
		else if (index >= 128 && index < 192)
		{
			isNature = CNNstep1_CTU[2] == "0" ? true : false;
			if (!isNature)
			{
				isText = CNNstep2_CTU[2] == "0" ? true : false;
#if ENABLE_COLOR_PATCH
				isNonText = CNNstep2_CTU[2] == "1" ? true : false;
				isColorPatch = CNNstep2_CTU[2] == "2" ? true : false;
#else
				isNonText = !isText;
#endif
			}
		}
		else if (index >= 192 && index < 256)
		{
			isNature = CNNstep1_CTU[3] == "0" ? true : false;
			if (!isNature)
			{
				isText = CNNstep2_CTU[3] == "0" ? true : false;
#if ENABLE_COLOR_PATCH
				isNonText = CNNstep2_CTU[3] == "1" ? true : false;
				isColorPatch = CNNstep2_CTU[3] == "2" ? true : false;
#else
				isNonText = !isText;
#endif
			}
		}
	}

#if ET_ONLINE
	UChar ucContentIdx = 5;
	if (isNature)
	  ucContentIdx = 0;
	else if (isNonText)
	  ucContentIdx = 1;
	else if (isText)
	  ucContentIdx = 2;
	else if (isColorPatch)
	  ucContentIdx = 3;
#endif

	Bool SkipCurDepthIntra = false;
	Bool SkipCurDepthIBC = false;
	Bool SkipCurDepthPLT = false;
	Bool SkipCurDepthMerge = false;
	Bool SkipCurDepthFastIBC = false;

	if(isNature)		//intra
	{
		SkipCurDepthIBC = true;
		SkipCurDepthPLT = true;
		SkipCurDepthIntra = (uiDepth==0)? true:false;
		SkipCurDepthFastIBC = false;
		SkipCurDepthMerge = true;
	}
	if(isText)			//PLT
	{
		SkipCurDepthIntra = true;
		SkipCurDepthIBC = (uiDepth < 3) ? true : false;
		SkipCurDepthFastIBC = false;
		SkipCurDepthMerge = (uiDepth < 3) ? true : false;
	}

	if(isNonText)		//intra, PLT
	{
		SkipCurDepthIntra = (uiDepth == 0)? true:false;
		SkipCurDepthIBC = (uiDepth < 2) ? true:false;
		SkipCurDepthFastIBC = false;
		SkipCurDepthMerge = (uiDepth < 2) ? true:false;

#if MAP_MODIFICATION
		const char* found = strstr(g_inputFileName.c_str(), "Map");
		if (found)
		{
			switch (m_pcEncCfg->getQP())
			{
			case 22:
				SkipCurDepthIntra = (uiDepth < 3) ? true : false;
				SkipCurDepthIBC = (uiDepth < 3) ? true : false;
				SkipCurDepthPLT = (uiDepth < 2) ? true : false;
				break;
			case 27:
				SkipCurDepthIntra = (uiDepth < 3) ? true : false;
				SkipCurDepthIBC = (uiDepth < 3) ? true : false;
				SkipCurDepthPLT = (uiDepth < 2) ? true : false;
				break;
			case 32:
				SkipCurDepthIntra = (uiDepth < 2) ? true : false;
				SkipCurDepthIBC = (uiDepth < 3) ? true : false;
				SkipCurDepthPLT = (uiDepth < 2) ? true : false;
				break;
			case 37:
				SkipCurDepthIntra = (uiDepth < 2) ? true : false;
				SkipCurDepthIBC = (uiDepth < 3) ? true : false;
				SkipCurDepthPLT = (uiDepth < 2) ? true : false;
				break;
			default:
				break;
	}
	}
#endif
	}

#if ENABLE_COLOR_PATCH
	if (isColorPatch && uiDepth < 2)	//intra
	{
	  SkipCurDepthPLT = true;
	  SkipCurDepthIntra = false;
	  SkipCurDepthIBC = true;
	  SkipCurDepthFastIBC = false;
	  SkipCurDepthMerge = true;
	}
#endif
	if (isMix)
	{
		SkipCurDepthIntra = true;
		SkipCurDepthIBC = true;
		SkipCurDepthPLT = true;
	}
#if OUTPUT_MODE_COST
	//print enabled modes
	printf("%d %d %d %d ", uiDepth, SkipCurDepthIntra, SkipCurDepthIBC, SkipCurDepthPLT);
#endif
	if (isNonText && uiDepth < 2)	//supplement intra mode for smooth regoin
	{
		ComponentID compIDG = ComponentID(0);
		TComPic* pcPic = rpcBestCU->getPic();
		m_ppcOrigYuv[uiDepth]->copyFromPicYuv( pcPic->getPicYuvOrg(), rpcBestCU->getCtuRsAddr(), rpcBestCU->getZorderIdxInCtu() );
		const UInt uiStrideG = m_ppcOrigYuv[uiDepth]->getStride(compIDG);
		Int diffG = 0;
		Pel *CUpixel_G;
		Pel *CUpixel_G_;
		UInt width = rpcBestCU->getWidth(0);

		CUpixel_G = m_ppcOrigYuv[uiDepth]->getAddr(compIDG)+32;
		CUpixel_G_ = m_ppcOrigYuv[uiDepth]->getAddr(compIDG) + 32 + uiStrideG;
		for (Int i = 0; i<(width>>1);i++)
		{
			diffG += abs(*CUpixel_G - *CUpixel_G_);
			CUpixel_G += uiStrideG<<1;
			CUpixel_G_ += uiStrideG<<1;
		}
		if (diffG < 10)
		{
			CUpixel_G = m_ppcOrigYuv[uiDepth]->getAddr(compIDG) + 32*uiStrideG;
			CUpixel_G_ = m_ppcOrigYuv[uiDepth]->getAddr(compIDG) + 32*uiStrideG+1;
			for (Int i = 0; i<(width>>1);i++)
			{
				diffG += abs(*CUpixel_G - *CUpixel_G_);
				CUpixel_G+=2;
				CUpixel_G+=2;
			}
			if (diffG < 20)
			{
				SkipCurDepthIntra = false;
			}
		}

	}

	if (uiDepth == 2 && (isNature||isText))    
	{
		UInt AbsNeighIdx[5] = {};
		UInt ZNeighIdx[5] = {};
		Int NeighLeftIn = 0;
		Int NeighAboveIn = 0;
		Int NeighAboveLeftIn = 0;

		//get left 4 CU  up to down 0,1,
		if (RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			AbsNeighIdx[0] = AbsIdxInCurCTU + 14;
			NeighLeftIn = 1;
		}
		else
		{
			AbsNeighIdx[0] = AbsIdxInCurCTU - 2;
		}
		AbsNeighIdx[1] = AbsNeighIdx[0] + 32;


		//get above 4 CU left to right 3,4
		if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16))
		{
			AbsNeighIdx[3] = AbsIdxInCurCTU + 224;
			NeighAboveIn = 1;
		}
		else
		{
			AbsNeighIdx[3] = AbsIdxInCurCTU - 32;
		}
		AbsNeighIdx[4] = AbsNeighIdx[3] + 2;

		//get AboveLeft 1 CU  2
		if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16) && RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 1;
			AbsNeighIdx[2] = AbsIdxInCurCTU + 238;
		}
		else if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 2;
			AbsNeighIdx[2] = AbsIdxInCurCTU + 222;
		}
		else if (RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 3;
			AbsNeighIdx[2] = AbsIdxInCurCTU - 18;
		}
		else
		{
			AbsNeighIdx[2] = AbsIdxInCurCTU - 34;
		}

		for (Int i = 0; i < 5; i++)
		{
			ZNeighIdx[i] = g_auiRasterToZscan[AbsNeighIdx[i]];
		}


		TComDataCU* m_CtuAboveLeft_CNN = rpcBestCU->getCtuAboveLeft();
		TComDataCU* m_pCtuAbove_CNN = rpcBestCU->getCtuAbove();
		TComDataCU* m_pCtuLeft_CNN = rpcBestCU->getCtuLeft();
		Int IBCorPLTcounts = 0;
		if (!(rpcBestCU->getCUPelX() == 0 && rpcBestCU->getCUPelY() == 0))
		{

			if (rpcBestCU->getCUPelX() == 0)
			{
				//first col --- above neighbor 3,4
				switch (NeighAboveIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[3]) || pCtu->getPLTModeFlag(ZNeighIdx[3])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[4]) || pCtu->getPLTModeFlag(ZNeighIdx[4])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[3]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[3])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[4]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[4])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
			else if (rpcBestCU->getCUPelY() == 0)
			{
				//first��row --- left neighbor 0.1
				switch (NeighLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[0]) || pCtu->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[1]) || pCtu->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[0]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[1]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
			else
			{
				switch (NeighAboveIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[3]) || pCtu->getPLTModeFlag(ZNeighIdx[3])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[4]) || pCtu->getPLTModeFlag(ZNeighIdx[4])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[3]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[3])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[4]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[4])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
				switch (NeighLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[0]) || pCtu->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[1]) || pCtu->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[0]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[1]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
				switch (NeighAboveLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[2]) || pCtu->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_CtuAboveLeft_CNN->isIntraBC(ZNeighIdx[2]) || m_CtuAboveLeft_CNN->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 2:
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[2]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 3:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[2]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
		}
		else
		{
			SkipCurDepthIBC = false;
			SkipCurDepthPLT = false;
		}

		if (IBCorPLTcounts != 0 && isNature)
		{
#if SUPPLEMENT_FOR_NATURE
		  if (bEnableSupplementForNature)
#endif
		  {
			SkipCurDepthIBC = false;
			SkipCurDepthPLT = false;
		  }
		}
		else if (IBCorPLTcounts != 5 && isText)
		{
			SkipCurDepthIntra = false;
		}
	}

	if (uiDepth == 3 && (isNature || isText))
	{
		UInt AbsNeighIdx[3] = {};
		UInt ZNeighIdx[3] = {};
		Int NeighAboveIn = 0; //0:cur,1:Above
		Int NeighLeftIn = 0;  //0:cur,1:Left
		Int NeighAboveLeftIn = 0; // 0:cur,1:aboveleft,2:above,3:left
		Int IBCorPLTcounts = 0;
		//get left 4 CU  up to down 0
		if (RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			AbsNeighIdx[0] = AbsIdxInCurCTU + 14;
			NeighLeftIn = 1;
		}
		else
		{
			AbsNeighIdx[0] = AbsIdxInCurCTU - 2;
		}


		//get above 4 CU left to right 2
		if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16))
		{
			AbsNeighIdx[2] = AbsIdxInCurCTU + 224;
			NeighAboveIn = 1;
		}
		else
		{
			AbsNeighIdx[2] = AbsIdxInCurCTU - 32;
		}

		//get AboveLeft 1 CU  1
		if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16) && RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 1;
			AbsNeighIdx[1] = AbsIdxInCurCTU + 238;
		}
		else if (RasterAddress::isZeroRow(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 2;
			AbsNeighIdx[1] = AbsIdxInCurCTU + 222;
		}
		else if (RasterAddress::isZeroCol(AbsIdxInCurCTU, 16))
		{
			NeighAboveLeftIn = 3;
			AbsNeighIdx[1] = AbsIdxInCurCTU - 18;
		}
		else
		{
			AbsNeighIdx[1] = AbsIdxInCurCTU - 34;
		}
		for (Int i = 0; i < 3; i++)
		{
			ZNeighIdx[i] = g_auiRasterToZscan[AbsNeighIdx[i]];
		}


		TComDataCU* m_CtuAboveLeft_CNN = rpcBestCU->getCtuAboveLeft();
		TComDataCU* m_pCtuAbove_CNN = rpcBestCU->getCtuAbove();
		TComDataCU* m_pCtuLeft_CNN = rpcBestCU->getCtuLeft();
		if (!(rpcBestCU->getCUPelX() == 0 && rpcBestCU->getCUPelY() == 0))
		{// not at left-top of PIC
			if (rpcBestCU->getCUPelX() == 0)
			{
				//first col --- above neighbor 2
				switch (NeighAboveIn)
				{
				case 0: //cur
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[2]) || pCtu->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1: //above
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[2]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
			else if (rpcBestCU->getCUPelY() == 0)
			{
				//first��row --- left neighbor 0
				switch (NeighLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[0]) || pCtu->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[0]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
			else
			{
				switch (NeighAboveIn)
				{
				case 0: //cur
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[2]) || pCtu->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1: //above
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[2]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[2])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
				switch (NeighLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[0]) || pCtu->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[0]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[0])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
				switch (NeighAboveLeftIn)
				{
				case 0:
					IBCorPLTcounts = (pCtu->isIntraBC(ZNeighIdx[1]) || pCtu->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 1:
					IBCorPLTcounts = (m_CtuAboveLeft_CNN->isIntraBC(ZNeighIdx[1]) || m_CtuAboveLeft_CNN->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 2:
					IBCorPLTcounts = (m_pCtuAbove_CNN->isIntraBC(ZNeighIdx[1]) || m_pCtuAbove_CNN->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				case 3:
					IBCorPLTcounts = (m_pCtuLeft_CNN->isIntraBC(ZNeighIdx[1]) || m_pCtuLeft_CNN->getPLTModeFlag(ZNeighIdx[1])) ? IBCorPLTcounts + 1 : IBCorPLTcounts;
					break;
				default:
					break;
				}
			}
		}
		else
		{
			SkipCurDepthIBC = false;
			SkipCurDepthPLT = false;
		}
		if (IBCorPLTcounts != 0 && isNature)
		{
#if SUPPLEMENT_FOR_NATURE
		  if (bEnableSupplementForNature)
#endif
		  {
			SkipCurDepthIBC = false;
			SkipCurDepthPLT = false;
		  }
		}
		else if (IBCorPLTcounts != 3 && isText)
		{
			SkipCurDepthIntra = false;
		}
	}
#if OUTPUT_MODE_COST
	//print enabled modes
	printf("%d %d %d ", SkipCurDepthIntra, SkipCurDepthIBC, SkipCurDepthPLT);
	SkipCurDepthIntra = false;	//enable intra to get cost of intra
#endif

#if ONLY_CBC_EARLY_TERMINATION
  SkipCurDepthIntra = false;
  SkipCurDepthIBC = false;
  SkipCurDepthPLT = false;
#endif
#if ONLY_SUBMODE
  SkipCurDepthIntra = false;
  SkipCurDepthIBC = false;
  SkipCurDepthPLT = false;
#endif
#endif

#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
#if ONLY_ENABLE_FOR_NATURE
	if (bEnableAWET)
#endif
	{
	  if ((uiDepth == uiMaxDepth) && (SkipCurDepthIntra == true && SkipCurDepthIBC == true && SkipCurDepthPLT == true) && (rpcBestCU->getPartitionSize(0) == NUMBER_OF_PART_SIZES))
	  {
		SkipCurDepthIBC = false;
		SkipCurDepthPLT = false;
		//SkipCurDepthIntra = false;
	  }
	}
#endif
  TComMv lastIntraBCMv[2];
  for(Int i=0; i<2; i++)
  {
    lastIntraBCMv[i] = rpcBestCU->getLastIntraBCMv(i);
  }

  UChar lastPLTSize[3];
  UInt numValidComp = rpcBestCU->getPic()->getNumberValidComponents();
  Pel*  lastPLT[MAX_NUM_COMPONENT];
  for (UInt ch = 0; ch < numValidComp; ch++)
  {
    lastPLT[ch] = (Pel*)xMalloc(Pel, rpcBestCU->getSlice()->getSPS()->getSpsScreenExtension().getPLTMaxPredSize());
  }
  for (UInt ch = 0; ch < numValidComp; ch++)
  {
    lastPLTSize[ch] = rpcBestCU->getLastPLTInLcuSizeFinal(ch);
    for (UInt i = 0; i < rpcBestCU->getSlice()->getSPS()->getSpsScreenExtension().getPLTMaxPredSize(); i++)
    {
      lastPLT[ch][i] = rpcBestCU->getLastPLTInLcuFinal(ch, i);
    }
  }

  TComPic* pcPic = rpcBestCU->getPic();
  DEBUG_STRING_NEW(sDebug)
  const TComPPS &pps=*(rpcTempCU->getSlice()->getPPS());
  const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
  
  // These are only used if getFastDeltaQp() is true
  const UInt fastDeltaQPCuMaxSize    = Clip3(sps.getMaxCUHeight()>>sps.getLog2DiffMaxMinCodingBlockSize(), sps.getMaxCUHeight(), 32u);

  // get Original YUV data from picture
  m_ppcOrigYuv[uiDepth]->copyFromPicYuv( pcPic->getPicYuvOrg(), rpcBestCU->getCtuRsAddr(), rpcBestCU->getZorderIdxInCtu() );

  // variable for Cbf fast mode PU decision
  Bool    doNotBlockPu = true;
  Bool    earlyDetectionSkipMode = false;

  const UInt uiLPelX   = rpcBestCU->getCUPelX();
  const UInt uiRPelX   = uiLPelX + rpcBestCU->getWidth(0)  - 1;
  const UInt uiTPelY   = rpcBestCU->getCUPelY();
  const UInt uiBPelY   = uiTPelY + rpcBestCU->getHeight(0) - 1;
  const UInt uiWidth   = rpcBestCU->getWidth(0);

  Int iBaseQP = xComputeQP( rpcBestCU, uiDepth );
  Int iMinQP;
  Int iMaxQP;
  Bool isAddLowestQP = false;

  const UInt numberValidComponents = rpcBestCU->getPic()->getNumberValidComponents();
  Bool isPerfectMatch = false;
  Bool terminateAllFurtherRDO = false;

  TComMv iMVCandList[4][10];
  memset( iMVCandList, 0, sizeof( TComMv )*4*10 );

  if( uiDepth <= pps.getMaxCuDQPDepth() )
  {
    Int idQP = m_pcEncCfg->getMaxDeltaQP();
    iMinQP = Clip3( -sps.getQpBDOffset(CHANNEL_TYPE_LUMA), MAX_QP, iBaseQP-idQP );
    iMaxQP = Clip3( -sps.getQpBDOffset(CHANNEL_TYPE_LUMA), MAX_QP, iBaseQP+idQP );
  }
  else
  {
    iMinQP = rpcTempCU->getQP(0);
    iMaxQP = rpcTempCU->getQP(0);
  }

  if ( m_pcEncCfg->getUseRateCtrl() )
  {
    iMinQP = m_pcRateCtrl->getRCQP();
    iMaxQP = m_pcRateCtrl->getRCQP();
  }

  // transquant-bypass (TQB) processing loop variable initialisation ---

  const Int lowestQP = iMinQP; // For TQB, use this QP which is the lowest non TQB QP tested (rather than QP'=0) - that way delta QPs are smaller, and TQB can be tested at all CU levels.

  if ( (pps.getTransquantBypassEnableFlag()) )
  {
    isAddLowestQP = true; // mark that the first iteration is to cost TQB mode.
    iMinQP = iMinQP - 1;  // increase loop variable range by 1, to allow testing of TQB mode along with other QPs
    if ( m_pcEncCfg->getCUTransquantBypassFlagForceValue() )
    {
      iMaxQP = iMinQP;
    }
  }

  TComSlice * pcSlice = rpcTempCU->getPic()->getSlice(rpcTempCU->getPic()->getCurrSliceIdx());

  if(rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans())
  {
    m_ppcBestCU[uiDepth]->tmpIntraBCRDCost   = MAX_DOUBLE;
    m_ppcTempCU[uiDepth]->tmpIntraBCRDCost   = MAX_DOUBLE;
    m_ppcBestCU[uiDepth]->bIntraBCCSCEnabled = true;
    m_ppcTempCU[uiDepth]->bIntraBCCSCEnabled = true;

    m_ppcBestCU[uiDepth]->tmpInterRDCost     = MAX_DOUBLE;
    m_ppcTempCU[uiDepth]->tmpInterRDCost     = MAX_DOUBLE;
    m_ppcBestCU[uiDepth]->bInterCSCEnabled   = true;
    m_ppcTempCU[uiDepth]->bInterCSCEnabled   = true;
    setEnableIntraTUACT(uiDepth, pcSlice);
    setEnableIBCTUACT(uiDepth, pcSlice);
    setEnableInterTUACT(uiDepth, pcSlice);
  }

  const Bool bBoundary = !( uiRPelX < sps.getPicWidthInLumaSamples() && uiBPelY < sps.getPicHeightInLumaSamples() );

#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
  if (!bBoundary && uiDepth >= uiMinDepth)
#else
  if (!bBoundary)
#endif
  {
    for (Int iQP=iMinQP; iQP<=iMaxQP; iQP++)
    {
      const Bool bIsLosslessMode = isAddLowestQP && (iQP == iMinQP);

      if (bIsLosslessMode)
      {
        iQP = lowestQP;
      }

      m_cuChromaQpOffsetIdxPlus1 = 0;
      if (pcSlice->getUseChromaQpAdj())
      {
        /* Pre-estimation of chroma QP based on input block activity may be performed
         * here, using for example m_ppcOrigYuv[uiDepth] */
        /* To exercise the current code, the index used for adjustment is based on
         * block position
         */
        Int lgMinCuSize = sps.getLog2MinCodingBlockSize() +
                          std::max<Int>(0, sps.getLog2DiffMaxMinCodingBlockSize()-Int(pps.getPpsRangeExtension().getDiffCuChromaQpOffsetDepth()));
        m_cuChromaQpOffsetIdxPlus1 = ((uiLPelX >> lgMinCuSize) + (uiTPelY >> lgMinCuSize)) % (pps.getPpsRangeExtension().getChromaQpOffsetListLen() + 1);
      }

      rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

      // do inter modes, SKIP and 2Nx2N
      if ( ( !rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->getSliceType() != I_SLICE ) ||
           ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && !rpcBestCU->getSlice()->isOnlyCurrentPictureAsReference() ) )
      {
        if ( m_pcEncCfg->getUseHashBasedME() )
        {
          xCheckRDCostHashInter( rpcBestCU, rpcTempCU, isPerfectMatch DEBUG_STRING_PASS_INTO(sDebug) );
          rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

          if ( isPerfectMatch )
          {
            if ( uiDepth == 0 )
            {
              terminateAllFurtherRDO = true;
            }
          }
        }

        // 2Nx2N
        if(m_pcEncCfg->getUseEarlySkipDetection() && !terminateAllFurtherRDO)
        {
          xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2Nx2N DEBUG_STRING_PASS_INTO(sDebug) );
          rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );//by Competition for inter_2Nx2N
        }
        // SKIP
        xCheckRDCostMerge2Nx2N( rpcBestCU, rpcTempCU DEBUG_STRING_PASS_INTO(sDebug), &earlyDetectionSkipMode, terminateAllFurtherRDO );//by Merge for inter_2Nx2N
        rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

        if(!m_pcEncCfg->getUseEarlySkipDetection() && !terminateAllFurtherRDO)
        {
          // 2Nx2N, NxN
          xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2Nx2N DEBUG_STRING_PASS_INTO(sDebug) );
          rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
          if(m_pcEncCfg->getUseCbfFastMode())
          {
            doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
          }
        }
      }

      if (bIsLosslessMode) // Restore loop variable if lossless mode was searched.
      {
        iQP = iMinQP;
      }
    }

    if(!earlyDetectionSkipMode && !terminateAllFurtherRDO)
    {
      for (Int iQP=iMinQP; iQP<=iMaxQP; iQP++)
      {
        const Bool bIsLosslessMode = isAddLowestQP && (iQP == iMinQP); // If lossless, then iQP is irrelevant for subsequent modules.

        if (bIsLosslessMode)
        {
          iQP = lowestQP;
        }

        rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

        // do inter modes, NxN, 2NxN, and Nx2N
        if ( ( !rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->getSliceType() != I_SLICE ) ||
             ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && !rpcBestCU->getSlice()->isOnlyCurrentPictureAsReference() ) )
        {
          // 2Nx2N, NxN

          if(!( (rpcBestCU->getWidth(0)==8) && (rpcBestCU->getHeight(0)==8) ))
          {
            if( uiDepth == sps.getLog2DiffMaxMinCodingBlockSize() && doNotBlockPu)
            {
              xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_NxN DEBUG_STRING_PASS_INTO(sDebug)   );
              rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            }
          }

          if(doNotBlockPu)
          {
            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_Nx2N DEBUG_STRING_PASS_INTO( sDebug ), false, iMVCandList[SIZE_Nx2N] );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_Nx2N )
            {
              doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
            }
          }
          if(doNotBlockPu)
          {
            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxN DEBUG_STRING_PASS_INTO( sDebug ), false, iMVCandList[SIZE_2NxN] );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_2NxN)
            {
              doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
            }
          }

          //! Try AMP (SIZE_2NxnU, SIZE_2NxnD, SIZE_nLx2N, SIZE_nRx2N)
          if(sps.getUseAMP() && uiDepth < sps.getLog2DiffMaxMinCodingBlockSize() )
          {
#if AMP_ENC_SPEEDUP
            Bool bTestAMP_Hor = false, bTestAMP_Ver = false;

#if AMP_MRG
            Bool bTestMergeAMP_Hor = false, bTestMergeAMP_Ver = false;

            deriveTestModeAMP (rpcBestCU, eParentPartSize, bTestAMP_Hor, bTestAMP_Ver, bTestMergeAMP_Hor, bTestMergeAMP_Ver);
#else
            deriveTestModeAMP (rpcBestCU, eParentPartSize, bTestAMP_Hor, bTestAMP_Ver);
#endif

            //! Do horizontal AMP
            if ( bTestAMP_Hor )
            {
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnU DEBUG_STRING_PASS_INTO(sDebug) );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_2NxnU )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnD DEBUG_STRING_PASS_INTO(sDebug) );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_2NxnD )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
            }
#if AMP_MRG
            else if ( bTestMergeAMP_Hor )
            {
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnU DEBUG_STRING_PASS_INTO(sDebug), true );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_2NxnU )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnD DEBUG_STRING_PASS_INTO(sDebug), true );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_2NxnD )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
            }
#endif

            //! Do horizontal AMP
            if ( bTestAMP_Ver )
            {
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nLx2N DEBUG_STRING_PASS_INTO(sDebug) );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_nLx2N )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nRx2N DEBUG_STRING_PASS_INTO(sDebug) );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }
            }
#if AMP_MRG
            else if ( bTestMergeAMP_Ver )
            {
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nLx2N DEBUG_STRING_PASS_INTO(sDebug), true );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
                if(m_pcEncCfg->getUseCbfFastMode() && rpcBestCU->getPartitionSize(0) == SIZE_nLx2N )
                {
                  doNotBlockPu = rpcBestCU->getQtRootCbf( 0 ) != 0;
                }
              }
              if(doNotBlockPu)
              {
                xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nRx2N DEBUG_STRING_PASS_INTO(sDebug), true );
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }
            }
#endif

#else
            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnU );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_2NxnD );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nLx2N );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

            xCheckRDCostInter( rpcBestCU, rpcTempCU, SIZE_nRx2N );
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

#endif
          }
        }

        // do normal intra modes
        // speedup for inter frames
        Double intraCost = MAX_DOUBLE;
        Double dIntraBcCostPred = 0.0;

#if LBCFMD
		sad = MAX_DOUBLE;
#endif
		
#if OUTPUT_MODE_COST
		rpcBestCU->setRdCostMode(0, MAX_DOUBLE);
		rpcBestCU->setRdCostMode(1, MAX_DOUBLE);
		rpcBestCU->setRdCostMode(2, MAX_DOUBLE);
#endif

        if ( ( !rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->getSliceType() == I_SLICE ) ||
             ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->isOnlyCurrentPictureAsReference() ) ||
             !rpcBestCU->isSkipped(0) ) // avoid very complex intra if it is unlikely
        {
#if LBCFMD
#if SCM_S0067_MAX_CAND_SIZE
	        if (m_pcEncCfg->getUseIntraBlockCopyFastSearch() && rpcTempCU->getWidth(0) <= SCM_S0067_MAX_CAND_SIZE &&!SkipCurDepthIBC)
#else
          if (m_pcEncCfg->getUseIntraBlockCopyFastSearch() && rpcTempCU->getWidth(0) <= 16 )
#endif
#else
#if SCM_S0067_MAX_CAND_SIZE
		 if (m_pcEncCfg->getUseIntraBlockCopyFastSearch() && rpcTempCU->getWidth(0) <= SCM_S0067_MAX_CAND_SIZE )
#else
          if (m_pcEncCfg->getUseIntraBlockCopyFastSearch() && rpcTempCU->getWidth(0) <= 16 )
#endif
#endif
          {
#if !DISABLE_FAST_IBC
#if TIME_MODE_DEPTH
			clock_t lResult;
			clock_t lBefore = clock();
#endif
            xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, false, SIZE_2Nx2N, dIntraBcCostPred, true DEBUG_STRING_PASS_INTO(sDebug)); //set testPredOnly=true to perform fast IBC search�� //testPredOnly=true means only check MVP, not do MV search, see xIntraPatternSearch()
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
			lResult = clock() - lBefore;
			lTimeFastIBC[uiDepth] += lResult;
			lTimeFastIBC[4] += lResult;
			uiCheckFastIBC[uiDepth]++;
			uiCheckFastIBC[4]++;
#endif
#endif
          }
#if LBCFMD
		    if(!SkipCurDepthIntra && ( rpcBestCU->getPredictionMode(0) == NUMBER_OF_PREDICTION_MODES ||
              ((!m_pcEncCfg->getDisableIntraPUsInInterSlices()) && (
               (rpcBestCU->getCbf( 0, COMPONENT_Y  ) != 0)                                            ||
              ((rpcBestCU->getCbf( 0, COMPONENT_Cb ) != 0) && (numberValidComponents > COMPONENT_Cb)) ||
              ((rpcBestCU->getCbf( 0, COMPONENT_Cr ) != 0) && (numberValidComponents > COMPONENT_Cr))  ) // avoid very complex intra if it is unlikely
            )))	//Cbf=0 means residue=0, if there's one component's residue!=0 then check intra mode 
#else
		    if(rpcBestCU->getPredictionMode(0) == NUMBER_OF_PREDICTION_MODES ||
              ((!m_pcEncCfg->getDisableIntraPUsInInterSlices()) && (
               (rpcBestCU->getCbf( 0, COMPONENT_Y  ) != 0)                                            ||
              ((rpcBestCU->getCbf( 0, COMPONENT_Cb ) != 0) && (numberValidComponents > COMPONENT_Cb)) ||
              ((rpcBestCU->getCbf( 0, COMPONENT_Cr ) != 0) && (numberValidComponents > COMPONENT_Cr))  ) // avoid very complex intra if it is unlikely
            ))
#endif
          {
            if(rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && ( !bIsLosslessMode || (sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA ))))
            {
              Double tempIntraCost = MAX_DOUBLE;
              TComDataCU *pStoredBestCU = rpcBestCU;
              if(m_pcEncCfg->getRGBFormatFlag())
              {
                xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
					isNonText||isText,isSpecial,
#endif
					tempIntraCost, SIZE_2Nx2N, ACT_TRAN_CLR, false DEBUG_STRING_PASS_INTO(sDebug) );
              }
              else
              {
                if( uiDepth < 3 || bIsLosslessMode )
                {
                  xCheckRDCostIntra( rpcBestCU, rpcTempCU, 
#if LBCFMD
					isNonText||isText,isSpecial,
#endif					  
					  intraCost, SIZE_2Nx2N DEBUG_STRING_PASS_INTO(sDebug));
                }
                else
                {
                  xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
					isNonText||isText,isSpecial,
#endif					  
					  intraCost, SIZE_2Nx2N, ACT_ORG_CLR, false DEBUG_STRING_PASS_INTO(sDebug) );
                }
              }
              Bool bSkipRGBCoding = pStoredBestCU == rpcBestCU ? !rpcTempCU->getQtRootCbf( 0 ): !rpcBestCU->getQtRootCbf( 0 );	//Rate distortion cost of the second colour space is invoked only when there is at least one non-zero coefficient in the first colour
#if DISABLE_INTRACSC
			  bSkipRGBCoding = true;
#endif
			  if(!bSkipRGBCoding) 
              {
                rpcTempCU->initRQTData( uiDepth, rpcBestCU, (pStoredBestCU != rpcBestCU), false, true );
                if(m_pcEncCfg->getRGBFormatFlag())
                {
                  if( !getEnableIntraTUACT() ) 
                  {
                    xCheckRDCostIntra( rpcBestCU, rpcTempCU,
#if LBCFMD
						isNonText||isText,isSpecial,
#endif						
						intraCost, SIZE_2Nx2N DEBUG_STRING_PASS_INTO(sDebug), true );
                  }
                  else
                  {
                    xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif						
						intraCost, SIZE_2Nx2N, ACT_TWO_CLR, true DEBUG_STRING_PASS_INTO(sDebug) );
                  }
                }
                else
                {
                  xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif					  
  				        tempIntraCost, SIZE_2Nx2N, ACT_TRAN_CLR, true DEBUG_STRING_PASS_INTO(sDebug) );
                }
                intraCost = std::min(intraCost, tempIntraCost);
              }
              else
                intraCost = tempIntraCost;
            }
            else
            {
              xCheckRDCostIntra( rpcBestCU, rpcTempCU, 
#if LBCFMD
					isNonText||isText,isSpecial,
#endif				  
				  intraCost, SIZE_2Nx2N DEBUG_STRING_PASS_INTO(sDebug) );
            }
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            if( uiDepth == sps.getLog2DiffMaxMinCodingBlockSize() )
            {
              if( rpcTempCU->getWidth(0) > ( 1 << sps.getQuadtreeTULog2MinSize() ) )
              {
                Double tmpIntraCost;
                if(rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && ( !bIsLosslessMode || (sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA ))))
                {
                  Double      tempIntraCost = MAX_DOUBLE;
                  TComDataCU *pStoredBestCU = rpcBestCU;
                  if(m_pcEncCfg->getRGBFormatFlag())
                  {
                    xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
					isNonText||isText,isSpecial,
#endif						
						tempIntraCost, SIZE_NxN, ACT_TRAN_CLR, false DEBUG_STRING_PASS_INTO(sDebug) );
                  }
                  else
                  {
                    if( uiDepth < 3 || bIsLosslessMode )
                    {
                      xCheckRDCostIntra( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif						  
						  tmpIntraCost, SIZE_NxN DEBUG_STRING_PASS_INTO(sDebug) );
                    }
                    else
                    {
                      xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif						  
						  tmpIntraCost, SIZE_NxN, ACT_ORG_CLR, false DEBUG_STRING_PASS_INTO(sDebug) );
                    }
                  }
                  Bool bSkipRGBCoding = pStoredBestCU == rpcBestCU ? !rpcTempCU->getQtRootCbf( 0 ) : !rpcBestCU->getQtRootCbf( 0 );
#if DISABLE_INTRACSC
				  bSkipRGBCoding = true;
#endif
				  if(!bSkipRGBCoding) 
                  {
                    rpcTempCU->initRQTData( uiDepth, rpcBestCU, (pStoredBestCU != rpcBestCU), false, true );
                    if(m_pcEncCfg->getRGBFormatFlag())
                    {
                      if( !getEnableIntraTUACT() )
                      {
                        xCheckRDCostIntra( rpcBestCU, rpcTempCU, 
#if LBCFMD
							isNonText||isText,isSpecial,
#endif							
							tmpIntraCost, SIZE_NxN DEBUG_STRING_PASS_INTO(sDebug), true );
                      }
                      else
                      {
                        xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
							isNonText||isText,isSpecial,
#endif							
							tmpIntraCost, SIZE_NxN, ACT_TWO_CLR, true DEBUG_STRING_PASS_INTO(sDebug) );
                      }
                    }
                    else
                    {
                      xCheckRDCostIntraCSC( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif						  
						  tempIntraCost, SIZE_NxN, ACT_TRAN_CLR, true DEBUG_STRING_PASS_INTO(sDebug) );
                    }
                    tmpIntraCost = std::min(tmpIntraCost, tempIntraCost);
                  }
                  else
                    tmpIntraCost = tempIntraCost;
                }
                else
                {
                  xCheckRDCostIntra( rpcBestCU, rpcTempCU, 
#if LBCFMD
						isNonText||isText,isSpecial,
#endif					  
					  tmpIntraCost, SIZE_NxN DEBUG_STRING_PASS_INTO(sDebug)   );
                }
                intraCost = std::min(intraCost, tmpIntraCost);
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }
            }
          }

          if( rpcBestCU->isIntraBC( 0 ) )
          {
            intraCost = dIntraBcCostPred;
          }
        }
#if LBCFMD	  //early termination
#if EARLY_TERMINATION_CBC
		if (isNature && uiDepth != 3 )
		{
			Int qp = rpcBestCU->getQP(0);
			Double SADadjust = 0.944*pow(2, 0.0388*(qp - 22));
			Int SAD_weight = 0;
			Double FormatFactor = 0.8;

			if( m_pcEncCfg->getRGBFormatFlag())
			{
				FormatFactor = 1.2;
			}
			switch(uiDepth)
			{
			case 0:
				SAD_weight = 1000;
				break;
			case 1:
				SAD_weight = 600;
				break;
			case 2:
				SAD_weight = 300;
				break;
			}
#if ONLY_CBC_EARLY_TERMINATION
      if (sad < FormatFactor*dThNature*SADadjust*SAD_weight)
#else
			if (sad < FormatFactor*NATURE_EARLY_TERMINATION*SADadjust*SAD_weight)
#endif
			{
				earlyTermination = true;
			}
		}
		
		if (isNonText && uiDepth != 3 )
		{
			Int qp = rpcBestCU->getQP(0);
			Double SADadjust = 0.944*pow(2, 0.0388*(qp - 22));
			Int SAD_weight = 0;
			Double FormatFactor = 1.6;

			if( m_pcEncCfg->getRGBFormatFlag())
			{
				FormatFactor = 1;
			}
			switch(uiDepth)
			{
			case 0:
				SAD_weight = 200;
				break;
			case 1:
				SAD_weight = 120;
				break;
			case 2:
				SAD_weight = 75;
				break;
			}
#if ONLY_CBC_EARLY_TERMINATION
      if (sad < FormatFactor*dThNonText*SADadjust*SAD_weight)
#else
			if (sad < FormatFactor*NATURE_EARLY_TERMINATION*SADadjust*SAD_weight)
#endif
			{
				earlyTermination = true;
			}
		}		
#endif

#if SUPPLEMENT_FOR_NATURE
		if (bEnableSupplementForNature)
#endif
		{
		  if (isNature && (uiDepth == 2 || uiDepth == 3) && (SkipCurDepthPLT || SkipCurDepthIBC))
		  {
			Int qp = rpcBestCU->getQP(0);
			Double SADadjust = 0.944*pow(2, 0.0388*(qp - 22));
			Int SAD_weight = 0;
			if (uiDepth == 2)
			{
			  SAD_weight = 256 * 10;
			}
			else if (uiDepth == 3)
			{
			  SAD_weight = 64;
			}
			if (sad >= NATURESADTHRESHOLD*SADadjust*SAD_weight)
			{
			  SkipCurDepthPLT = false;
			  SkipCurDepthIBC = false;
			}
		  }
		}
#endif

#if OUTPUT_MODE_COST
		//print enabled modes
		printf("%d %d %d ", SkipCurDepthIntra, SkipCurDepthIBC, SkipCurDepthPLT);
		SkipCurDepthIBC = false;
		SkipCurDepthPLT = false;	//to get cost of IBC and PLT
#endif
        intraCost = MAX_DOUBLE;
#if DEBUG_GCS
		//printf("intra done %d %d %d\n", rpcBestCU->getCtuRsAddr(), rpcBestCU->getZorderIdxInCtu(), uiDepth );
#endif
        // test PCM
        if(sps.getUsePCM()
          && rpcTempCU->getWidth(0) <= (1<<sps.getPCMLog2MaxSize())
          && rpcTempCU->getWidth(0) >= (1<<sps.getPCMLog2MinSize()) )
        {
          UInt uiRawBits = getTotalBits(rpcBestCU->getWidth(0), rpcBestCU->getHeight(0), rpcBestCU->getPic()->getChromaFormat(), sps.getBitDepths().recon);
          UInt uiBestBits = rpcBestCU->getTotalBits();
          if((uiBestBits > uiRawBits) || (rpcBestCU->getTotalCost() > m_pcRdCost->calcRdCost(uiRawBits, 0)))
          {
            xCheckIntraPCM (rpcBestCU, rpcTempCU);
            rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
          }
        }

        Bool bUse1DSearchFor8x8        = false;
        Bool bSkipIntraBlockCopySearch = false;

#if LBCFMD
#if NONTEXT_MODIFICATION
		Bool bFlag = false;
		if (SkipCurDepthIBC && uiDepth == 1)
		{
		  SkipCurDepthIBC = false;
		  bFlag = true;
		}
#endif
		if (rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && (!SkipCurDepthIBC ) )
#else
		if (rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy())
#endif
        {
          xCheckRDCostIntraBCMerge2Nx2N( rpcBestCU, rpcTempCU );
          rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
        }
#if NONTEXT_MODIFICATION
		if (bFlag && uiDepth == 1)
		{
		  SkipCurDepthIBC = true;
		}
#endif
        if( !rpcBestCU->isSkipped(0) ) // avoid very complex intra if it is unlikely
        {
          if (m_pcEncCfg->getUseIntraBlockCopyFastSearch())
          {
            bSkipIntraBlockCopySearch = ((rpcTempCU->getWidth(0) > 16) || (intraCost < std::max(32*m_pcRdCost->getLambda(), 48.0)));

            if (rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() &&
                !bSkipIntraBlockCopySearch &&
                rpcTempCU->getWidth(0) == 8 &&
                !m_ppcBestCU[uiDepth -1]->isIntraBC(0) )
            {
              bUse1DSearchFor8x8 = (CalculateMinimumHVLumaActivity(rpcTempCU, 0, m_ppcOrigYuv) < (168 << (sps.getBitDepth( CHANNEL_TYPE_LUMA ) - 8)));
            }
          }


#if LBCFMD
		  if (rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && !SkipCurDepthIBC )
#else
          if (rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy())
#endif
          {
            if (!bSkipIntraBlockCopySearch)
            {
              Double adIntraBcCost[NUMBER_OF_PART_SIZES] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
#if TIME_MODE_DEPTH
			  clock_t lResult;
			  clock_t lBefore = clock();
#endif
              xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, bUse1DSearchFor8x8, SIZE_2Nx2N, adIntraBcCost[SIZE_2Nx2N] DEBUG_STRING_PASS_INTO(sDebug));	//for 16x16 and 8x8
              rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
			  lResult = clock() - lBefore;
			  lTimeNormalIBC[uiDepth] += lResult;
			  lTimeNormalIBC[4] += lResult;
			  uiCheckNormalIBC[uiDepth]++;
			  uiCheckNormalIBC[4]++;
#endif
              if (m_pcEncCfg->getUseIntraBlockCopyFastSearch())
              {
                if( uiDepth == sps.getLog2DiffMaxMinCodingBlockSize() ) // Only additionally check Nx2N, 2NxN, NxN at the bottom level in fast search //only for 8x8
                {
                  intraCost = std::min( intraCost, adIntraBcCost[SIZE_2Nx2N] );

                  Double dTH2 = std::max( 60 * m_pcRdCost->getLambda(),  56.0 );
                  Double dTH3 = std::max( 66 * m_pcRdCost->getLambda(), 800.0 );
                  if( intraCost >= dTH2 ) // only check Nx2N depending on best intraCost (and intraBCcost so far)
                  {
#if TIME_MODE_DEPTH
					clock_t lResult;
					clock_t lBefore = clock();
#endif
                    xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, true, SIZE_Nx2N, adIntraBcCost[SIZE_Nx2N], false, (iMVCandList[SIZE_Nx2N]+8) DEBUG_STRING_PASS_INTO(sDebug));
                    rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
					lResult = clock() - lBefore;
					lTimeNormalIBC[uiDepth] += lResult;
					lTimeNormalIBC[4] += lResult;
					lTimeAsyIBC[uiDepth] += lResult;
					lTimeAsyIBC[4] += lResult;
					uiCheckNormalIBC[uiDepth]++;
					uiCheckNormalIBC[4]++;
					uiCheckAsyIBC[uiDepth]++;
					uiCheckAsyIBC[4]++;
#endif
                    intraCost = std::min( intraCost, adIntraBcCost[SIZE_Nx2N] );

                    if ( ( !rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->getSliceType() != I_SLICE ) ||
                         ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && !rpcBestCU->getSlice()->isOnlyCurrentPictureAsReference() ) )
                    {
#if TIME_MODE_DEPTH
					  clock_t lResult;
					  clock_t lBefore = clock();
#endif
                      xCheckRDCostIntraBCMixed( rpcBestCU, rpcTempCU, SIZE_Nx2N, adIntraBcCost[SIZE_Nx2N] DEBUG_STRING_PASS_INTO(sDebug), iMVCandList[SIZE_Nx2N]);
                      rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
					  lResult = clock() - lBefore;
					  lTimeIBCMix[uiDepth] += lResult;
					  lTimeIBCMix[4] += lResult;
					  uiCheckIBCMix[uiDepth]++;
					  uiCheckIBCMix[4]++;
#endif
                      intraCost = std::min( intraCost, adIntraBcCost[SIZE_Nx2N] );
                    }
                  }

                  if( intraCost >= dTH2 && !bIsLosslessMode ) // only check 2NxN depending on best intraCost (and intraBCcost so far) and if it is not lossless
                  {
#if TIME_MODE_DEPTH
					clock_t lResult;
					clock_t lBefore = clock();
#endif
                    xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, ( bUse1DSearchFor8x8 || intraCost < dTH3 ), SIZE_2NxN, adIntraBcCost[SIZE_2NxN], false, (iMVCandList[SIZE_2NxN]+8) DEBUG_STRING_PASS_INTO(sDebug));
                    rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
					lResult = clock() - lBefore;
					lTimeNormalIBC[uiDepth] += lResult;
					lTimeNormalIBC[4] += lResult;
					lTimeAsyIBC[uiDepth] += lResult;
					lTimeAsyIBC[4] += lResult;
					uiCheckNormalIBC[uiDepth]++;
					uiCheckNormalIBC[4]++;
					uiCheckAsyIBC[uiDepth]++;
					uiCheckAsyIBC[4]++;
#endif
                    intraCost = std::min( intraCost, adIntraBcCost[SIZE_2NxN] );

                    if ( ( !rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && rpcBestCU->getSlice()->getSliceType() != I_SLICE ) ||
                         ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseIntraBlockCopy() && !rpcBestCU->getSlice()->isOnlyCurrentPictureAsReference() ) )
                    {
#if TIME_MODE_DEPTH
					  clock_t lResult;
					  clock_t lBefore = clock();
#endif
                      xCheckRDCostIntraBCMixed( rpcBestCU, rpcTempCU, SIZE_2NxN, adIntraBcCost[SIZE_2NxN] DEBUG_STRING_PASS_INTO(sDebug), iMVCandList[SIZE_2NxN]);
                      rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
#if TIME_MODE_DEPTH
					  lResult = clock() - lBefore;
					  lTimeIBCMix[uiDepth] += lResult;
					  lTimeIBCMix[4] += lResult;
					  uiCheckIBCMix[uiDepth]++;
					  uiCheckIBCMix[4]++;
#endif
                      intraCost = std::min( intraCost, adIntraBcCost[SIZE_2NxN] );
                    }
                }
              }
            }
            else
            {
              // full search (bUse1DSearchFor8x8 will be false but is kept here for consistency).

              xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, bUse1DSearchFor8x8, SIZE_Nx2N, adIntraBcCost[SIZE_Nx2N] DEBUG_STRING_PASS_INTO(sDebug));
              rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              xCheckRDCostIntraBC( rpcBestCU, rpcTempCU, bUse1DSearchFor8x8, SIZE_2NxN, adIntraBcCost[SIZE_2NxN] DEBUG_STRING_PASS_INTO(sDebug));
              rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
            }
          }
        }

          if (bIsLosslessMode) // Restore loop variable if lossless mode was searched.
          {
            iQP = iMinQP;
          }

#if LBCFMD
          if ( rpcBestCU->getSlice()->getSPS()->getSpsScreenExtension().getUsePLTMode() && !SkipCurDepthPLT)
#else
          if ( rpcBestCU->getSlice()->getSPS()->getSpsScreenExtension().getUsePLTMode() )
#endif
          {
#if TIME_MODE_DEPTH
			clock_t lResult;
			clock_t lBefore = clock();
#endif
            //Change PLT QP dependent error limit
            Int iQP_PLT=Int(rpcBestCU->getQP(0));
            Int iQPrem = iQP_PLT % 6;
            Int iQPper = iQP_PLT / 6;
            Double quantiserScale = g_quantScales[iQPrem];
            Int quantiserRightShift = QUANT_SHIFT + iQPper;

            Double dQP=((Double)(1<<quantiserRightShift))/quantiserScale;

            UInt pltQP;
            pltQP=(UInt)(2.0*dQP/3.0+0.5);
            m_pcPredSearch->setPLTErrLimit(pltQP);

            Bool forcePLTPrediction = false;
            for( UChar ch = 0; ch < numValidComp; ch++ )
            {
              forcePLTPrediction = forcePLTPrediction || ( rpcTempCU->getLastPLTInLcuSizeFinal( ch ) > 0 );
            }

            UInt uiIterNumber=0, pltSize[2] = {MAX_PLT_SIZE, MAX_PLT_SIZE}, testedModes[4];

            if( rpcTempCU->getWidth(0) != 64)
            {
              uiIterNumber = 0;
              testedModes[uiIterNumber]=xCheckPLTMode( rpcBestCU, rpcTempCU, false, uiIterNumber, pltSize);
              rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

              if (pltSize[0]>2 && testedModes[0]>0)
              {
                uiIterNumber = 2;
                testedModes[uiIterNumber]=xCheckPLTMode( rpcBestCU, rpcTempCU, false, uiIterNumber, pltSize);
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }

              if( forcePLTPrediction)
              {
                uiIterNumber = 1;
                testedModes[uiIterNumber]=xCheckPLTMode( rpcBestCU, rpcTempCU, true, uiIterNumber, pltSize+1);
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }

              if (forcePLTPrediction && pltSize[1]>2 && testedModes[1]>0)
              {
                uiIterNumber = 3;
                testedModes[uiIterNumber]=xCheckPLTMode( rpcBestCU, rpcTempCU, true, uiIterNumber, pltSize+1);
                rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
              }
            }
#if TIME_MODE_DEPTH
			lResult = clock() - lBefore;
			lTimePLT[uiDepth] += lResult;
			lTimePLT[4] += lResult;
			uiCheckPLT[uiDepth]++;
			uiCheckPLT[4]++;
#endif
          }
        }
      }
    }
#if OUTPUT_MODE_COST
	if (rpcBestCU->getRdCostMode(0) == MAX_DOUBLE)	rpcBestCU->setRdCostMode(0, -1);
	if (rpcBestCU->getRdCostMode(1) == MAX_DOUBLE)	rpcBestCU->setRdCostMode(1, -1);
	if (rpcBestCU->getRdCostMode(2) == MAX_DOUBLE)	rpcBestCU->setRdCostMode(2, -1);
	printf("%f %f %f\n", rpcBestCU->getRdCostMode(0), rpcBestCU->getRdCostMode(1), rpcBestCU->getRdCostMode(2));
#endif
    // If Intra BC keep last coded Mv
    if(rpcBestCU->isInter(0))
    {
      Int iRefIdxFirst = rpcBestCU->getCUMvField( REF_PIC_LIST_0 )->getRefIdx( 0 );
      Int iRefIdxLast = rpcBestCU->getCUMvField( REF_PIC_LIST_0 )->getRefIdx( rpcBestCU->getTotalNumPart() - 1 );
      Bool isIntraBCFirst = ( iRefIdxFirst >= 0 ) ? rpcBestCU->getSlice()->getRefPic( REF_PIC_LIST_0, iRefIdxFirst )->getPOC() == rpcBestCU->getSlice()->getPOC() : false;
      Bool isIntraBCLast = ( iRefIdxLast >= 0 ) ? rpcBestCU->getSlice()->getRefPic( REF_PIC_LIST_0, iRefIdxLast )->getPOC() == rpcBestCU->getSlice()->getPOC() : false;

      if (  isIntraBCFirst || isIntraBCLast  )
      {
        if( rpcBestCU->getPartitionSize( 0 ) == SIZE_2Nx2N)
        {
          if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) != rpcBestCU->getLastIntraBCMv(0))
          {
            rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(0), 1 );
            rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) );
          }
        }
        else if(rpcBestCU->getPartitionSize( 0 ) == SIZE_2NxN || rpcBestCU->getPartitionSize( 0 ) == SIZE_Nx2N)
        {
          // mixed PU, only one partition is IntraBC coded
          if( isIntraBCFirst != isIntraBCLast )
          {
            if(isIntraBCFirst)
            {
              // Part 0
              if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( 0 ) != rpcBestCU->getLastIntraBCMv())
              {
                rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(), 1);
                rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( 0 ) );
              }
            }
            else if(isIntraBCLast)
            {
              // Part 1
              if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) != rpcBestCU->getLastIntraBCMv())
              {
                rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(), 1);
                rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) );
              }
            }
          }
          else // normal IntraBC CU
          {
            // Part 0
            if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( 0 ) != rpcBestCU->getLastIntraBCMv())
            {
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(), 1);
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( 0 ) );
            }
            // Part 1
            if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) != rpcBestCU->getLastIntraBCMv())
            {
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(), 1);
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 1 ) );
            }
          }
        }
        else
        {
          // NxN
          for(Int part=0; part<4; part++)
          {
            if( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 4 + part ) != rpcBestCU->getLastIntraBCMv())
            {
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getLastIntraBCMv(), 1 );
              rpcBestCU->setLastIntraBCMv( rpcBestCU->getCUMvField(REF_PIC_LIST_0)->getMv( rpcBestCU->getTotalNumPart() - 4 + part ) );
            }
          }
        }
      }
    } // is inter
    if (rpcBestCU->getPLTModeFlag(0))
    {
      rpcBestCU->saveLastPLTInLcuFinal( rpcBestCU, 0, MAX_NUM_COMPONENT );
    }

    if( rpcBestCU->getTotalCost()!=MAX_DOUBLE )
    {
      m_pcRDGoOnSbacCoder->load(m_pppcRDSbacCoder[uiDepth][CI_NEXT_BEST]);
      m_pcEntropyCoder->resetBits();
      m_pcEntropyCoder->encodeSplitFlag( rpcBestCU, 0, uiDepth, true );
      rpcBestCU->getTotalBits() += m_pcEntropyCoder->getNumberOfWrittenBits(); // split bits
      rpcBestCU->getTotalBins() += ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
      rpcBestCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcBestCU->getTotalBits(), rpcBestCU->getTotalDistortion() );
      m_pcRDGoOnSbacCoder->store(m_pppcRDSbacCoder[uiDepth][CI_NEXT_BEST]);
    }
  }

  // copy original YUV samples to PCM buffer
  if( rpcBestCU->getPLTModeFlag(0) == false )
  {
    if( rpcBestCU->getTotalCost()!=MAX_DOUBLE && rpcBestCU->isLosslessCoded(0) && (rpcBestCU->getIPCMFlag(0) == false))
    {
      xFillPCMBuffer(rpcBestCU, m_ppcOrigYuv[uiDepth]);
    }
  }

  if( uiDepth == pps.getMaxCuDQPDepth() )
  {
    Int idQP = m_pcEncCfg->getMaxDeltaQP();
    iMinQP = Clip3( -sps.getQpBDOffset(CHANNEL_TYPE_LUMA), MAX_QP, iBaseQP-idQP );
    iMaxQP = Clip3( -sps.getQpBDOffset(CHANNEL_TYPE_LUMA), MAX_QP, iBaseQP+idQP );
  }
  else if( uiDepth < pps.getMaxCuDQPDepth() )
  {
    iMinQP = iBaseQP;
    iMaxQP = iBaseQP;
  }
  else
  {
    const Int iStartQP = rpcTempCU->getQP(0);
    iMinQP = iStartQP;
    iMaxQP = iStartQP;
  }

  if ( m_pcEncCfg->getUseRateCtrl() )
  {
    iMinQP = m_pcRateCtrl->getRCQP();
    iMaxQP = m_pcRateCtrl->getRCQP();
  }

  if ( m_pcEncCfg->getCUTransquantBypassFlagForceValue() )
  {
    iMaxQP = iMinQP; // If all TUs are forced into using transquant bypass, do not loop here.
  }

  Bool bSubBranch = bBoundary || !( m_pcEncCfg->getUseEarlyCU() && rpcBestCU->getTotalCost()!=MAX_DOUBLE && rpcBestCU->isSkipped(0) );

  if( rpcBestCU->isIntraBC(0) && rpcBestCU->getQtRootCbf(0) == 0 )
  {
    bSubBranch = false;
  }
#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
  if (uiDepth >= uiMaxDepth && !bBoundary)
  {
	bSubBranch = false;
  }
#endif
#if ENABLE_COLOR_PATCH
  if (isColorPatch && rpcBestCU->getCtuRsAddr() < (sps.getPicWidthInLumaSamples() >> 6) * (sps.getPicHeightInLumaSamples() >> 6) && rpcBestCU->getTotalCost() != MAX_DOUBLE)
  {
	terminateAllFurtherRDO = true;
  }
#endif

#if ET_ONLINE
  dTotalCostNonSplit = rpcBestCU->getTotalCost();
  if (uiValidNum[uiDepth][ucContentIdx] > uiValidNumTh[uiDepth][ucContentIdx] && dTotalCostNonSplit < dAptEtTh[uiDepth][ucContentIdx] && !bBoundary)
  {
	uiSkipNum[uiDepth][ucContentIdx] ++;
	terminateAllFurtherRDO = true;
  }
#endif

#if LBCFMD
  if( !earlyTermination && !terminateAllFurtherRDO && bSubBranch && uiDepth < sps.getLog2DiffMaxMinCodingBlockSize() && (!getFastDeltaQp() || uiWidth > fastDeltaQPCuMaxSize || bBoundary))
#else
  if( !terminateAllFurtherRDO && bSubBranch && uiDepth < sps.getLog2DiffMaxMinCodingBlockSize() && (!getFastDeltaQp() || uiWidth > fastDeltaQPCuMaxSize || bBoundary))
#endif
  {
    PaletteInfoBuffer tempPalettePredictor;

    if( iMinQP != iMaxQP )
    {
      memcpy( tempPalettePredictor.lastPLTSize, lastPLTSize, sizeof( lastPLTSize ) );
      memcpy( tempPalettePredictor.lastPLT[0],  lastPLT[0], sizeof( tempPalettePredictor.lastPLT[0] ) );
      memcpy( tempPalettePredictor.lastPLT[1],  lastPLT[1], sizeof( tempPalettePredictor.lastPLT[1] ) );
      memcpy( tempPalettePredictor.lastPLT[2],  lastPLT[2], sizeof( tempPalettePredictor.lastPLT[2] ) );
    }

    // further split
    for (Int iQP=iMinQP; iQP<=iMaxQP; iQP++)
    {
      const Bool bIsLosslessMode = false; // False at this level. Next level down may set it to true.

      rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );

      UChar       uhNextDepth         = uiDepth+1;
      TComDataCU* pcSubBestPartCU     = m_ppcBestCU[uhNextDepth];
      TComDataCU* pcSubTempPartCU     = m_ppcTempCU[uhNextDepth];
      DEBUG_STRING_NEW(sTempDebug)

      if( iMinQP != iMaxQP && iQP != iMinQP )
      {
        memcpy( lastPLTSize, tempPalettePredictor.lastPLTSize, sizeof( lastPLTSize ) );
        memcpy( lastPLT[0],  tempPalettePredictor.lastPLT[0],  sizeof( tempPalettePredictor.lastPLT[0] ) );
        memcpy( lastPLT[1],  tempPalettePredictor.lastPLT[1],  sizeof( tempPalettePredictor.lastPLT[1] ) );
        memcpy( lastPLT[2],  tempPalettePredictor.lastPLT[2],  sizeof( tempPalettePredictor.lastPLT[2] ) );
      }

      for ( UInt uiPartUnitIdx = 0; uiPartUnitIdx < 4; uiPartUnitIdx++ )
      {
        pcSubBestPartCU->initSubCU( rpcTempCU, uiPartUnitIdx, uhNextDepth, iQP );           // clear sub partition datas or init.
        pcSubTempPartCU->initSubCU( rpcTempCU, uiPartUnitIdx, uhNextDepth, iQP );           // clear sub partition datas or init.

        for(Int i=0; i<2; i++)
        {
          pcSubBestPartCU->setLastIntraBCMv( lastIntraBCMv[i], i );
          pcSubTempPartCU->setLastIntraBCMv( lastIntraBCMv[i], i );
        }

        for (UInt ch = 0; ch < numValidComp; ch++)
        {
          pcSubBestPartCU->setLastPLTInLcuSizeFinal(ch, lastPLTSize[ch]);
          pcSubTempPartCU->setLastPLTInLcuSizeFinal(ch, lastPLTSize[ch]);
          for (UInt i = 0; i < pcSlice->getSPS()->getSpsScreenExtension().getPLTMaxPredSize(); i++)
          {
            pcSubBestPartCU->setLastPLTInLcuFinal(ch, lastPLT[ch][i], i);
            pcSubTempPartCU->setLastPLTInLcuFinal(ch, lastPLT[ch][i], i);
          }
        }


        if( ( pcSubBestPartCU->getCUPelX() < sps.getPicWidthInLumaSamples() ) && ( pcSubBestPartCU->getCUPelY() < sps.getPicHeightInLumaSamples() ) )
        {
          if ( 0 == uiPartUnitIdx) //initialize RD with previous depth buffer
          {
            m_pppcRDSbacCoder[uhNextDepth][CI_CURR_BEST]->load(m_pppcRDSbacCoder[uiDepth][CI_CURR_BEST]);
          }
          else
          {
            m_pppcRDSbacCoder[uhNextDepth][CI_CURR_BEST]->load(m_pppcRDSbacCoder[uhNextDepth][CI_NEXT_BEST]);
          }

#if AMP_ENC_SPEEDUP
          DEBUG_STRING_NEW(sChild)
          if ( !(rpcBestCU->getTotalCost()!=MAX_DOUBLE && rpcBestCU->isInter(0)) )
          {
            xCompressCU( pcSubBestPartCU, pcSubTempPartCU, uhNextDepth DEBUG_STRING_PASS_INTO(sChild),
#if LBCFMD
				CNNstep1_CTU,  CNNstep1_LeftCTU, CNNstep1_AboveCTU, CNNstep2_CTU, pCtu,
#endif
				NUMBER_OF_PART_SIZES );
          }
          else
          {

            xCompressCU( pcSubBestPartCU, pcSubTempPartCU, uhNextDepth DEBUG_STRING_PASS_INTO(sChild), 
#if LBCFMD
				CNNstep1_CTU,  CNNstep1_LeftCTU, CNNstep1_AboveCTU, CNNstep2_CTU, pCtu,
#endif
				rpcBestCU->getPartitionSize(0) );
          }
          DEBUG_STRING_APPEND(sTempDebug, sChild)
#else
          xCompressCU( pcSubBestPartCU, pcSubTempPartCU, uhNextDepth );
#endif

          // NOTE: RExt - (0,0) is used as an indicator that IntraBC has not been used within the CU.
          if( pcSubBestPartCU->getLastIntraBCMv().getHor() != 0 || pcSubBestPartCU->getLastIntraBCMv().getVer() != 0 )
          {
            for(Int i=0; i<2; i++)
            {
              lastIntraBCMv[i] = pcSubBestPartCU->getLastIntraBCMv(i);
            }
          }

          if (pcSubBestPartCU->getLastPLTInLcuSizeFinal(COMPONENT_Y) != 0)
          {
            for (UInt ch = 0; ch < numValidComp; ch++)
            {
              lastPLTSize[ch] = pcSubBestPartCU->getLastPLTInLcuSizeFinal(ch);
              for (UInt i = 0; i < pcSlice->getSPS()->getSpsScreenExtension().getPLTMaxPredSize(); i++)
              {

                lastPLT[ch][i] = pcSubBestPartCU->getLastPLTInLcuFinal(ch, i);
              }
            }
          }


          rpcTempCU->copyPartFrom( pcSubBestPartCU, uiPartUnitIdx, uhNextDepth );         // Keep best part data to current temporary data.
          xCopyYuv2Tmp( pcSubBestPartCU->getTotalNumPart()*uiPartUnitIdx, uhNextDepth );
        }
        else
        {
          pcSubBestPartCU->copyToPic( uhNextDepth );
          rpcTempCU->copyPartFrom( pcSubBestPartCU, uiPartUnitIdx, uhNextDepth );
        }
      }

      m_pcRDGoOnSbacCoder->load(m_pppcRDSbacCoder[uhNextDepth][CI_NEXT_BEST]);
      if( !bBoundary )
      {

        m_pcEntropyCoder->resetBits();
        m_pcEntropyCoder->encodeSplitFlag( rpcTempCU, 0, uiDepth, true );

        rpcTempCU->getTotalBits() += m_pcEntropyCoder->getNumberOfWrittenBits(); // split bits
        rpcTempCU->getTotalBins() += ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
      }
      rpcTempCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

      if( uiDepth == pps.getMaxCuDQPDepth() && pps.getUseDQP())
      {
        Bool hasResidual = false;
        for( UInt uiBlkIdx = 0; uiBlkIdx < rpcTempCU->getTotalNumPart(); uiBlkIdx ++)
        {
          if( (     rpcTempCU->getCbf(uiBlkIdx, COMPONENT_Y)
                || (rpcTempCU->getCbf(uiBlkIdx, COMPONENT_Cb) && (numberValidComponents > COMPONENT_Cb))
                || (rpcTempCU->getCbf(uiBlkIdx, COMPONENT_Cr) && (numberValidComponents > COMPONENT_Cr)) ) 
                || ( rpcTempCU->getPLTModeFlag(uiBlkIdx) && rpcTempCU->getPLTEscape(COMPONENT_Y, uiBlkIdx) )
                )
          {
            hasResidual = true;
            break;
          }
        }

        if ( hasResidual )
        {
          m_pcEntropyCoder->resetBits();
          m_pcEntropyCoder->encodeQP( rpcTempCU, 0, false );
          rpcTempCU->getTotalBits() += m_pcEntropyCoder->getNumberOfWrittenBits(); // dQP bits
          rpcTempCU->getTotalBins() += ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
          rpcTempCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

          Bool foundNonZeroCbf = false;
          rpcTempCU->setQPSubCUs( rpcTempCU->getRefQP( 0 ), 0, uiDepth, foundNonZeroCbf );
          assert( foundNonZeroCbf );
        }
        else
        {
          rpcTempCU->setQPSubParts( rpcTempCU->getRefQP( 0 ), 0, uiDepth ); // set QP to default QP
        }
      }

      m_pcRDGoOnSbacCoder->store(m_pppcRDSbacCoder[uiDepth][CI_TEMP_BEST]);

      // If the configuration being tested exceeds the maximum number of bytes for a slice / slice-segment, then
      // a proper RD evaluation cannot be performed. Therefore, termination of the
      // slice/slice-segment must be made prior to this CTU.
      // This can be achieved by forcing the decision to be that of the rpcTempCU.
      // The exception is each slice / slice-segment must have at least one CTU.
      if (rpcBestCU->getTotalCost()!=MAX_DOUBLE)
      {
        const Bool isEndOfSlice        =    pcSlice->getSliceMode()==FIXED_NUMBER_OF_BYTES
                                         && ((pcSlice->getSliceBits()+rpcBestCU->getTotalBits())>pcSlice->getSliceArgument()<<3)
                                         && rpcBestCU->getCtuRsAddr() != pcPic->getPicSym()->getCtuTsToRsAddrMap(pcSlice->getSliceCurStartCtuTsAddr())
                                         && rpcBestCU->getCtuRsAddr() != pcPic->getPicSym()->getCtuTsToRsAddrMap(pcSlice->getSliceSegmentCurStartCtuTsAddr());
        const Bool isEndOfSliceSegment =    pcSlice->getSliceSegmentMode()==FIXED_NUMBER_OF_BYTES
                                         && ((pcSlice->getSliceSegmentBits()+rpcBestCU->getTotalBits()) > pcSlice->getSliceSegmentArgument()<<3)
                                         && rpcBestCU->getCtuRsAddr() != pcPic->getPicSym()->getCtuTsToRsAddrMap(pcSlice->getSliceSegmentCurStartCtuTsAddr());
                                             // Do not need to check slice condition for slice-segment since a slice-segment is a subset of a slice.
        if(isEndOfSlice||isEndOfSliceSegment)
        {
          rpcBestCU->getTotalCost()=MAX_DOUBLE;
        }
      }
#if ET_ONLINE
	  dTotalCostSplit = rpcTempCU->getTotalCost();
	  if (dTotalCostNonSplit < dTotalCostSplit)
	  {
		dAptEtSum[uiDepth][ucContentIdx] += dTotalCostNonSplit;
		uiValidNum[uiDepth][ucContentIdx] ++;
		dAptEtAvg[uiDepth][ucContentIdx] = dAptEtSum[uiDepth][ucContentIdx] / uiValidNum[uiDepth][ucContentIdx];
		dAptEtTh[uiDepth][ucContentIdx] = dAptEtAvg[uiDepth][ucContentIdx] / dAptEtFactor[uiDepth][ucContentIdx];
	  }
#endif
      xCheckBestMode( rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTempDebug) DEBUG_STRING_PASS_INTO(false) ); // RD compare current larger prediction
                                                                                                                                                       // with sub partitioned prediction.
    }
  }

  DEBUG_STRING_APPEND(sDebug_, sDebug);

  rpcBestCU->copyToPic(uiDepth);                                                     // Copy Best data to Picture for next partition prediction.

  xCopyYuv2Pic( rpcBestCU->getPic(), rpcBestCU->getCtuRsAddr(), rpcBestCU->getZorderIdxInCtu(), uiDepth, uiDepth, rpcBestCU );   // Copy Yuv data to picture Yuv
  for (UInt ch = 0; ch < numValidComp; ch++)
  {
    if (lastPLT[ch])
    {
      xFree(lastPLT[ch]);
      lastPLT[ch] = NULL;
    }
  }
  if (bBoundary)
  {
    return;
  }
#if DEBUG_GCS
  //printf("%d %d %d %d %d %f %f\n", rpcBestCU->getCtuRsAddr(), rpcBestCU->getZorderIdxInCtu(), uiDepth, rpcBestCU->getPartitionSize(0), rpcBestCU->getPredictionMode(0), rpcBestCU->getTotalCost(), rpcTempCU->getTotalCost());
#endif
  // Assert if Best prediction mode is NONE
  // Selected mode's RD-cost must be not MAX_DOUBLE.
  assert( rpcBestCU->getPartitionSize ( 0 ) != NUMBER_OF_PART_SIZES       );
  assert( rpcBestCU->getPredictionMode( 0 ) != NUMBER_OF_PREDICTION_MODES );
  assert( rpcBestCU->getTotalCost     (   ) != MAX_DOUBLE                 );
}

/** finish encoding a cu and handle end-of-slice conditions
 * \param pcCU
 * \param uiAbsPartIdx
 * \param uiDepth
 * \returns Void
 */
Void TEncCu::finishCU( TComDataCU* pcCU, UInt uiAbsPartIdx )
{
  TComPic* pcPic = pcCU->getPic();
  TComSlice * pcSlice = pcCU->getPic()->getSlice(pcCU->getPic()->getCurrSliceIdx());

  //Calculate end address
  const Int  currentCTUTsAddr = pcPic->getPicSym()->getCtuRsToTsAddrMap(pcCU->getCtuRsAddr());
  const Bool isLastSubCUOfCtu = pcCU->isLastSubCUOfCtu(uiAbsPartIdx);
  if ( isLastSubCUOfCtu )
  {
    // The 1-terminating bit is added to all streams, so don't add it here when it's 1.
    // i.e. when the slice segment CurEnd CTU address is the current CTU address+1.
    if (pcSlice->getSliceSegmentCurEndCtuTsAddr() != currentCTUTsAddr+1)
    {
      m_pcEntropyCoder->encodeTerminatingBit( 0 );
    }
  }
}

/** Compute QP for each CU
 * \param pcCU Target CU
 * \param uiDepth CU depth
 * \returns quantization parameter
 */
Int TEncCu::xComputeQP( TComDataCU* pcCU, UInt uiDepth )
{
  Int iBaseQp = pcCU->getSlice()->getSliceQp();
  Int iQpOffset = 0;
  if ( m_pcEncCfg->getUseAdaptiveQP() )
  {
    TEncPic* pcEPic = dynamic_cast<TEncPic*>( pcCU->getPic() );
    UInt uiAQDepth = min( uiDepth, pcEPic->getMaxAQDepth()-1 );
    TEncPicQPAdaptationLayer* pcAQLayer = pcEPic->getAQLayer( uiAQDepth );
    UInt uiAQUPosX = pcCU->getCUPelX() / pcAQLayer->getAQPartWidth();
    UInt uiAQUPosY = pcCU->getCUPelY() / pcAQLayer->getAQPartHeight();
    UInt uiAQUStride = pcAQLayer->getAQPartStride();
    TEncQPAdaptationUnit* acAQU = pcAQLayer->getQPAdaptationUnit();

    Double dMaxQScale = pow(2.0, m_pcEncCfg->getQPAdaptationRange()/6.0);
    Double dAvgAct = pcAQLayer->getAvgActivity();
    Double dCUAct = acAQU[uiAQUPosY * uiAQUStride + uiAQUPosX].getActivity();
    Double dNormAct = (dMaxQScale*dCUAct + dAvgAct) / (dCUAct + dMaxQScale*dAvgAct);
    Double dQpOffset = log(dNormAct) / log(2.0) * 6.0;
    iQpOffset = Int(floor( dQpOffset + 0.49999 ));
  }

  return Clip3(-pcCU->getSlice()->getSPS()->getQpBDOffset(CHANNEL_TYPE_LUMA), MAX_QP, iBaseQp+iQpOffset );
}

/** encode a CU block recursively
 * \param pcCU
 * \param uiAbsPartIdx
 * \param uiDepth
 * \returns Void
 */
Void TEncCu::xEncodeCU( TComDataCU* pcCU, UInt uiAbsPartIdx, UInt uiDepth )
{
        TComPic   *const pcPic   = pcCU->getPic();
        TComSlice *const pcSlice = pcCU->getSlice();
  const TComSPS   &sps =*(pcSlice->getSPS());
  const TComPPS   &pps =*(pcSlice->getPPS());

  const UInt maxCUWidth  = sps.getMaxCUWidth();
  const UInt maxCUHeight = sps.getMaxCUHeight();

        Bool bBoundary = false;
        UInt uiLPelX   = pcCU->getCUPelX() + g_auiRasterToPelX[ g_auiZscanToRaster[uiAbsPartIdx] ];
  const UInt uiRPelX   = uiLPelX + (maxCUWidth>>uiDepth)  - 1;
        UInt uiTPelY   = pcCU->getCUPelY() + g_auiRasterToPelY[ g_auiZscanToRaster[uiAbsPartIdx] ];
  const UInt uiBPelY   = uiTPelY + (maxCUHeight>>uiDepth) - 1;

  if( ( uiRPelX < sps.getPicWidthInLumaSamples() ) && ( uiBPelY < sps.getPicHeightInLumaSamples() ) )
  {
    m_pcEntropyCoder->encodeSplitFlag( pcCU, uiAbsPartIdx, uiDepth );
  }
  else
  {
    bBoundary = true;
  }

  if( ( ( uiDepth < pcCU->getDepth( uiAbsPartIdx ) ) && ( uiDepth < sps.getLog2DiffMaxMinCodingBlockSize() ) ) || bBoundary )
  {
    UInt uiQNumParts = ( pcPic->getNumPartitionsInCtu() >> (uiDepth<<1) )>>2;
    if( uiDepth == pps.getMaxCuDQPDepth() && pps.getUseDQP())
    {
      setdQPFlag(true);
    }

    if( uiDepth == pps.getPpsRangeExtension().getDiffCuChromaQpOffsetDepth() && pcSlice->getUseChromaQpAdj())
    {
      setCodeChromaQpAdjFlag(true);
    }

    for ( UInt uiPartUnitIdx = 0; uiPartUnitIdx < 4; uiPartUnitIdx++, uiAbsPartIdx+=uiQNumParts )
    {
      uiLPelX   = pcCU->getCUPelX() + g_auiRasterToPelX[ g_auiZscanToRaster[uiAbsPartIdx] ];
      uiTPelY   = pcCU->getCUPelY() + g_auiRasterToPelY[ g_auiZscanToRaster[uiAbsPartIdx] ];
      if( ( uiLPelX < sps.getPicWidthInLumaSamples() ) && ( uiTPelY < sps.getPicHeightInLumaSamples() ) )
      {
        xEncodeCU( pcCU, uiAbsPartIdx, uiDepth+1 );
      }
    }
    return;
  }

  if( uiDepth <= pps.getMaxCuDQPDepth() && pps.getUseDQP())
  {
    setdQPFlag(true);
  }

  if( uiDepth <= pps.getPpsRangeExtension().getDiffCuChromaQpOffsetDepth() && pcSlice->getUseChromaQpAdj())
  {
    setCodeChromaQpAdjFlag(true);
  }

  if (pps.getTransquantBypassEnableFlag())
  {
    m_pcEntropyCoder->encodeCUTransquantBypassFlag( pcCU, uiAbsPartIdx );
  }

  if( !pcCU->getSlice()->isIntra() )
  {
    m_pcEntropyCoder->encodeSkipFlag( pcCU, uiAbsPartIdx );
  }

  if( pcCU->isSkipped( uiAbsPartIdx ) )
  {
    m_pcEntropyCoder->encodeMergeIndex( pcCU, uiAbsPartIdx );
    finishCU(pcCU,uiAbsPartIdx);
    return;
  }

  m_pcEntropyCoder->encodePredMode( pcCU, uiAbsPartIdx );

#if SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdj = getCodeChromaQpAdjFlag();

  m_pcEntropyCoder->encodePLTModeInfo( pcCU, uiAbsPartIdx, false, &bCodeDQP, &codeChromaQpAdj );
#endif

  if ( pcCU->getPLTModeFlag(uiAbsPartIdx) )
  {
#if SCM_S0043_PLT_DELTA_QP
    setCodeChromaQpAdjFlag( codeChromaQpAdj );
    setdQPFlag( bCodeDQP );
#endif
    finishCU(pcCU,uiAbsPartIdx);
    return;
  }

  m_pcEntropyCoder->encodePartSize( pcCU, uiAbsPartIdx, uiDepth );

  if (pcCU->isIntra( uiAbsPartIdx ) && pcCU->getPartitionSize( uiAbsPartIdx ) == SIZE_2Nx2N )
  {
    m_pcEntropyCoder->encodeIPCMInfo( pcCU, uiAbsPartIdx );

    if(pcCU->getIPCMFlag(uiAbsPartIdx))
    {
      // Encode slice finish
      finishCU(pcCU,uiAbsPartIdx);
      return;
    }
  }

  // prediction Info ( Intra : direction mode, Inter : Mv, reference idx )
  m_pcEntropyCoder->encodePredInfo( pcCU, uiAbsPartIdx );

  // Encode Coefficients
#if !SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdj = getCodeChromaQpAdjFlag();
#endif

  m_pcEntropyCoder->encodeCoeff( pcCU, uiAbsPartIdx, uiDepth, bCodeDQP, codeChromaQpAdj );
  setCodeChromaQpAdjFlag( codeChromaQpAdj );
  setdQPFlag( bCodeDQP );

  // --- write terminating bit ---
  finishCU(pcCU,uiAbsPartIdx);
}

Int xCalcHADs8x8_ISlice(Pel *piOrg, Int iStrideOrg)
{
  Int k, i, j, jj;
  Int diff[64], m1[8][8], m2[8][8], m3[8][8], iSumHad = 0;

  for( k = 0; k < 64; k += 8 )
  {
    diff[k+0] = piOrg[0] ;
    diff[k+1] = piOrg[1] ;
    diff[k+2] = piOrg[2] ;
    diff[k+3] = piOrg[3] ;
    diff[k+4] = piOrg[4] ;
    diff[k+5] = piOrg[5] ;
    diff[k+6] = piOrg[6] ;
    diff[k+7] = piOrg[7] ;

    piOrg += iStrideOrg;
  }

  //horizontal
  for (j=0; j < 8; j++)
  {
    jj = j << 3;
    m2[j][0] = diff[jj  ] + diff[jj+4];
    m2[j][1] = diff[jj+1] + diff[jj+5];
    m2[j][2] = diff[jj+2] + diff[jj+6];
    m2[j][3] = diff[jj+3] + diff[jj+7];
    m2[j][4] = diff[jj  ] - diff[jj+4];
    m2[j][5] = diff[jj+1] - diff[jj+5];
    m2[j][6] = diff[jj+2] - diff[jj+6];
    m2[j][7] = diff[jj+3] - diff[jj+7];

    m1[j][0] = m2[j][0] + m2[j][2];
    m1[j][1] = m2[j][1] + m2[j][3];
    m1[j][2] = m2[j][0] - m2[j][2];
    m1[j][3] = m2[j][1] - m2[j][3];
    m1[j][4] = m2[j][4] + m2[j][6];
    m1[j][5] = m2[j][5] + m2[j][7];
    m1[j][6] = m2[j][4] - m2[j][6];
    m1[j][7] = m2[j][5] - m2[j][7];

    m2[j][0] = m1[j][0] + m1[j][1];
    m2[j][1] = m1[j][0] - m1[j][1];
    m2[j][2] = m1[j][2] + m1[j][3];
    m2[j][3] = m1[j][2] - m1[j][3];
    m2[j][4] = m1[j][4] + m1[j][5];
    m2[j][5] = m1[j][4] - m1[j][5];
    m2[j][6] = m1[j][6] + m1[j][7];
    m2[j][7] = m1[j][6] - m1[j][7];
  }

  //vertical
  for (i=0; i < 8; i++)
  {
    m3[0][i] = m2[0][i] + m2[4][i];
    m3[1][i] = m2[1][i] + m2[5][i];
    m3[2][i] = m2[2][i] + m2[6][i];
    m3[3][i] = m2[3][i] + m2[7][i];
    m3[4][i] = m2[0][i] - m2[4][i];
    m3[5][i] = m2[1][i] - m2[5][i];
    m3[6][i] = m2[2][i] - m2[6][i];
    m3[7][i] = m2[3][i] - m2[7][i];

    m1[0][i] = m3[0][i] + m3[2][i];
    m1[1][i] = m3[1][i] + m3[3][i];
    m1[2][i] = m3[0][i] - m3[2][i];
    m1[3][i] = m3[1][i] - m3[3][i];
    m1[4][i] = m3[4][i] + m3[6][i];
    m1[5][i] = m3[5][i] + m3[7][i];
    m1[6][i] = m3[4][i] - m3[6][i];
    m1[7][i] = m3[5][i] - m3[7][i];

    m2[0][i] = m1[0][i] + m1[1][i];
    m2[1][i] = m1[0][i] - m1[1][i];
    m2[2][i] = m1[2][i] + m1[3][i];
    m2[3][i] = m1[2][i] - m1[3][i];
    m2[4][i] = m1[4][i] + m1[5][i];
    m2[5][i] = m1[4][i] - m1[5][i];
    m2[6][i] = m1[6][i] + m1[7][i];
    m2[7][i] = m1[6][i] - m1[7][i];
  }

  for (i = 0; i < 8; i++)
  {
    for (j = 0; j < 8; j++)
    {
      iSumHad += abs(m2[i][j]);
    }
  }
  iSumHad -= abs(m2[0][0]);
  iSumHad =(iSumHad+2)>>2;
  return(iSumHad);
}

Int  TEncCu::updateCtuDataISlice(TComDataCU* pCtu, Int width, Int height)
{
  Int  xBl, yBl;
  const Int iBlkSize = 8;

  Pel* pOrgInit   = pCtu->getPic()->getPicYuvOrg()->getAddr(COMPONENT_Y, pCtu->getCtuRsAddr(), 0);
  Int  iStrideOrig = pCtu->getPic()->getPicYuvOrg()->getStride(COMPONENT_Y);
  Pel  *pOrg;

  Int iSumHad = 0;
  for ( yBl=0; (yBl+iBlkSize)<=height; yBl+= iBlkSize)
  {
    for ( xBl=0; (xBl+iBlkSize)<=width; xBl+= iBlkSize)
    {
      pOrg = pOrgInit + iStrideOrig*yBl + xBl;
      iSumHad += xCalcHADs8x8_ISlice(pOrg, iStrideOrig);
    }
  }
  return(iSumHad);
}

Void TEncCu::xCheckRDCostIntraBCMerge2Nx2N( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU )
{
  TComMvField  cMvFieldNeighbours[2 * MRG_MAX_NUM_CANDS]; // double length for mv of both lists
  UChar uhInterDirNeighbours[MRG_MAX_NUM_CANDS];
  Int numValidMergeCand = 0;
  const Bool bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);

  for( UInt ui = 0; ui < rpcTempCU->getSlice()->getMaxNumMergeCand(); ++ui )
  {
    uhInterDirNeighbours[ui] = 0;
  }

  Int xPos = rpcTempCU->getCUPelX();
  Int yPos = rpcTempCU->getCUPelY();
  Int width = rpcTempCU->getWidth( 0 );
  Int height = rpcTempCU->getHeight( 0 );
  UChar uhDepth = rpcTempCU->getDepth( 0 );
  rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uhDepth );
  rpcTempCU->getInterMergeCandidates( 0, 0, cMvFieldNeighbours,uhInterDirNeighbours, numValidMergeCand );
  rpcTempCU->xRestrictBipredMergeCand( 0, cMvFieldNeighbours, uhInterDirNeighbours, numValidMergeCand );

  Int mergeCandBuffer[MRG_MAX_NUM_CANDS]; //denote whether the residue of current candidate mode is zero
  for( UInt ui = 0; ui < numValidMergeCand; ++ui )
  {
    mergeCandBuffer[ui] = 0;
  }

  Bool bestIsSkip = false;

  UInt iteration;
  if ( rpcTempCU->isLosslessCoded(0))
  {
    iteration = 1;	//normal coding
  }
  else
  {
    iteration = 2;	//force residue to 0
  }

#if DISABLE_MERGE_2Nx2N
  iteration = 1;
  UInt uiDepth = rpcTempCU->getDepth(0);
  Bool bSkipResidue = false;
  if (uiDepth < 3)
  {
	bSkipResidue = true;
  }
#endif
  const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
  for( UInt uiNoResidual = 0; uiNoResidual < iteration; ++uiNoResidual )
  {
#if TIME_MODE_DEPTH
	clock_t lResult;
	clock_t lBefore = clock();
#endif
    for( UInt uiMergeCand = 0; uiMergeCand < numValidMergeCand; ++uiMergeCand )
    {
      if(!(uiNoResidual==1 && mergeCandBuffer[uiMergeCand]==1))	//only check the candidate mode whose residue is not zero in the second iteration
      {
        if( !(bestIsSkip && uiNoResidual == 0) )
        {
          if ( uhInterDirNeighbours[uiMergeCand] != 1 )
          {
            continue;
          }

          if ( rpcTempCU->getSlice()->getRefPic( REF_PIC_LIST_0, cMvFieldNeighbours[uiMergeCand<<1].getRefIdx() )->getPOC() != rpcTempCU->getSlice()->getPOC() )
          {
            continue;
          }

          if ( !m_pcPredSearch->isBlockVectorValid( xPos, yPos, width, height, rpcTempCU, 0,
                  0, 0, (cMvFieldNeighbours[uiMergeCand<<1].getHor() >> 2), (cMvFieldNeighbours[uiMergeCand<<1].getVer()>>2), sps.getMaxCUWidth() ) )
          {
            continue;
          }

          // set MC parameters
          rpcTempCU->setPredModeSubParts( MODE_INTER, 0, uhDepth ); // interprets depth relative to LCU level
          rpcTempCU->setCUTransquantBypassSubParts( bTransquantBypassFlag, 0, uhDepth );
          rpcTempCU->setChromaQpAdjSubParts( bTransquantBypassFlag ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uhDepth );
          rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uhDepth ); // interprets depth relative to LCU level
          rpcTempCU->setMergeFlagSubParts( true, 0, 0, uhDepth ); // interprets depth relative to LCU level
          rpcTempCU->setMergeIndexSubParts( uiMergeCand, 0, 0, uhDepth ); // interprets depth relative to LCU level
          rpcTempCU->setInterDirSubParts( uhInterDirNeighbours[uiMergeCand], 0, 0, uhDepth ); // interprets depth relative to LCU level
          rpcTempCU->getCUMvField( REF_PIC_LIST_0 )->setAllMvField( cMvFieldNeighbours[0 + 2*uiMergeCand], SIZE_2Nx2N, 0, 0 ); // interprets depth relative to rpcTempCU level
          rpcTempCU->getCUMvField( REF_PIC_LIST_1 )->setAllMvField( cMvFieldNeighbours[1 + 2*uiMergeCand], SIZE_2Nx2N, 0, 0 ); // interprets depth relative to rpcTempCU level

          // do MC
          m_pcPredSearch->motionCompensation ( rpcTempCU, m_ppcPredYuvTemp[uhDepth] );
          Bool bColourTrans = (m_pcEncCfg->getRGBFormatFlag() && rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans())? true : false;

          if( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
            bColourTrans = false;

          TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uhDepth];
          if( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && (!bTransquantBypassFlag || sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
          {
            if(!getEnableIBCTUACT())
            {
              m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                         m_ppcOrigYuv    [uhDepth],
                                                         pcTmpPredYuv             ,
                                                         m_ppcResiYuvTemp[uhDepth],
                                                         m_ppcResiYuvBest[uhDepth],
                                                         m_ppcRecoYuvTemp[uhDepth],
#if DISABLE_MERGE_2Nx2N
														 bSkipResidue,
#else
                                                         (uiNoResidual != 0),
#endif
                                                         m_ppcNoCorrYuv  [uhDepth],
                                                         (bColourTrans? ACT_TRAN_CLR: ACT_ORG_CLR)
                                                         DEBUG_STRING_PASS_INTO(tmpStr) );
            }
            else
            {
              m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                         m_ppcOrigYuv    [uhDepth],
                                                         pcTmpPredYuv             ,
                                                         m_ppcResiYuvTemp[uhDepth],
                                                         m_ppcResiYuvBest[uhDepth],
                                                         m_ppcRecoYuvTemp[uhDepth],
#if DISABLE_MERGE_2Nx2N
														 bSkipResidue,
#else
														 (uiNoResidual != 0),
#endif
                                                         m_ppcNoCorrYuv  [uhDepth],
                                                         ACT_TWO_CLR
                                                         DEBUG_STRING_PASS_INTO(tmpStr) );
            }
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                       m_ppcOrigYuv    [uhDepth],
                                                       pcTmpPredYuv             ,
                                                       m_ppcResiYuvTemp[uhDepth],
                                                       m_ppcResiYuvBest[uhDepth],
                                                       m_ppcRecoYuvTemp[uhDepth],
#if DISABLE_MERGE_2Nx2N
													   bSkipResidue,
#else
													   (uiNoResidual != 0),
#endif
                                                       m_ppcNoCorrYuv  [uhDepth],
                                                       ACT_ORG_CLR
                                                       DEBUG_STRING_PASS_INTO(tmpStr) );
          }

          if ((uiNoResidual == 0) && (rpcTempCU->getQtRootCbf(0) == 0))
          {
            // If no residual when allowing for one, then set mark to not try case where residual is forced to 0
            mergeCandBuffer[uiMergeCand] = 1;
          }

          rpcTempCU->setSkipFlagSubParts( rpcTempCU->getQtRootCbf(0) == 0, 0, uhDepth );
          Int orgQP = rpcTempCU->getQP( 0 );
          xCheckDQP( rpcTempCU );
          TComDataCU *rpcTempCUPre = rpcTempCU;
#if OUTPUT_MODE_COST
		  if (rpcTempCU->getTotalCost() < rpcBestCU->getRdCostMode(1))
			  rpcBestCU->setRdCostMode(1, rpcTempCU->getTotalCost());
#endif
          xCheckBestMode(rpcBestCU, rpcTempCU, uhDepth DEBUG_STRING_PASS_INTO(bestStr) DEBUG_STRING_PASS_INTO(tmpStr));

          if(rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && !uiNoResidual && rpcTempCUPre->getQtRootCbf(0) )
          {
            if( rpcTempCU != rpcTempCUPre )
            {
              rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag );
              rpcTempCU->copyPartFrom( rpcBestCU, 0, uhDepth );
            }
            if(!getEnableIBCTUACT())
            {
              bColourTrans = !bColourTrans;
            }
            else
            {
              bColourTrans = m_pcEncCfg->getRGBFormatFlag();
            }
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                       m_ppcOrigYuv    [uhDepth],
                                                       pcTmpPredYuv             ,
                                                       m_ppcResiYuvTemp[uhDepth],
                                                       m_ppcResiYuvBest[uhDepth],
                                                       m_ppcRecoYuvTemp[uhDepth],
#if DISABLE_MERGE_2Nx2N
													   bSkipResidue,
#else
													   (uiNoResidual != 0),
#endif
                                                       m_ppcNoCorrYuv  [uhDepth],
                                                       (bColourTrans? ACT_TRAN_CLR: ACT_ORG_CLR)
                                                       DEBUG_STRING_PASS_INTO(tmpStr) );
            rpcTempCU->setSkipFlagSubParts( rpcTempCU->getQtRootCbf(0) == 0, 0, uhDepth );
            //Double rdCost = rpcTempCU->getTotalCost();

            xCheckDQP( rpcTempCU );
            if(rpcTempCU->getQtRootCbf(0))
            {
#if OUTPUT_MODE_COST
				if (rpcTempCU->getTotalCost() < rpcBestCU->getRdCostMode(1))
					rpcBestCU->setRdCostMode(1, rpcTempCU->getTotalCost());
#endif
              xCheckBestMode( rpcBestCU, rpcTempCU, uhDepth );
            }
          }
          rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag );

          if( m_pcEncCfg->getUseFastDecisionForMerge() && !bestIsSkip )
          {
            bestIsSkip = rpcBestCU->getQtRootCbf(0) == 0;
          }
#if TIME_MODE_DEPTH
		  UInt uiDepth = rpcTempCU->getDepth(0);
		  if (uiNoResidual == 0)
		  {
			uiCheckMergeCand[uiDepth] ++;
			uiCheckMergeCand[4] ++;
		  }
		  else if (uiNoResidual == 1)
		  {
			uiCheckSkipCand[uiDepth] ++;
			uiCheckSkipCand[4] ++;
		  }
#endif
        }
      }
    }
#if TIME_MODE_DEPTH
	UInt uiDepth = rpcTempCU->getDepth(0);
	lResult = clock() - lBefore;
	if (uiNoResidual == 0)
	{
	  lTimeMerge[uiDepth] += lResult;
	  lTimeMerge[4] += lResult;
	}
	else if (uiNoResidual == 1)
	{
	  lTimeSkip[uiDepth] += lResult;
	  lTimeSkip[4] += lResult;
	}
#endif
  }
#if TIME_MODE_DEPTH
  UInt uiDepth = rpcTempCU->getDepth(0);
  uiCheckMerge[uiDepth]++;
  uiCheckMerge[4]++;
#endif
}

/** check RD costs for a CU block encoded with merge
 * \param rpcBestCU
 * \param rpcTempCU
 * \param earlyDetectionSkipMode
 */
Void TEncCu::xCheckRDCostMerge2Nx2N( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU DEBUG_STRING_FN_DECLARE(sDebug), Bool *earlyDetectionSkipMode, Bool checkSkipOnly )
{
  assert( rpcTempCU->getSlice()->getSliceType() != I_SLICE );
  if(getFastDeltaQp())
  {
    return;   // never check merge in fast deltaqp mode
  }
  TComMvField  cMvFieldNeighbours[2 * MRG_MAX_NUM_CANDS]; // double length for mv of both lists
  UChar uhInterDirNeighbours[MRG_MAX_NUM_CANDS];
  Int numValidMergeCand = 0;
  const Bool bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);

  for( UInt ui = 0; ui < rpcTempCU->getSlice()->getMaxNumMergeCand(); ++ui )
  {
    uhInterDirNeighbours[ui] = 0;
  }
  UChar uhDepth = rpcTempCU->getDepth( 0 );
  rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uhDepth ); // interprets depth relative to CTU level
  rpcTempCU->getInterMergeCandidates( 0, 0, cMvFieldNeighbours,uhInterDirNeighbours, numValidMergeCand );
  rpcTempCU->xRestrictBipredMergeCand(0, cMvFieldNeighbours, uhInterDirNeighbours, numValidMergeCand );

  Int mergeCandBuffer[MRG_MAX_NUM_CANDS]; //denote whether the residue of current candidate mode is zero
  for( UInt ui = 0; ui < numValidMergeCand; ++ui )
  {
    mergeCandBuffer[ui] = 0;
  }

  Bool bestIsSkip = false;

  UInt iteration;
  UInt iterationBegin = checkSkipOnly ? 1 : 0;
  if ( rpcTempCU->isLosslessCoded(0))
  {
    iteration = 1;
    iterationBegin = 0;
  }
  else
  {
    iteration = 2;
  }
  DEBUG_STRING_NEW(bestStr)

  const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
  for( UInt uiNoResidual = iterationBegin; uiNoResidual < iteration; ++uiNoResidual )
  {
    for( UInt uiMergeCand = 0; uiMergeCand < numValidMergeCand; ++uiMergeCand )
    {
      if(!(uiNoResidual==1 && mergeCandBuffer[uiMergeCand]==1))
      {
        if( !(bestIsSkip && uiNoResidual == 0) )
        {
          if ( (uhInterDirNeighbours[uiMergeCand] == 1 || uhInterDirNeighbours[uiMergeCand] == 3) && rpcTempCU->getSlice()->getRefPic( REF_PIC_LIST_0, cMvFieldNeighbours[uiMergeCand<<1].getRefIdx() )->getPOC() == rpcTempCU->getSlice()->getPOC() )
          {
            continue;
          }

          DEBUG_STRING_NEW(tmpStr)
          // set MC parameters
          rpcTempCU->setPredModeSubParts( MODE_INTER, 0, uhDepth ); // interprets depth relative to CTU level
          rpcTempCU->setCUTransquantBypassSubParts( bTransquantBypassFlag, 0, uhDepth );
          rpcTempCU->setChromaQpAdjSubParts( bTransquantBypassFlag ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uhDepth );
          rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uhDepth ); // interprets depth relative to CTU level
          rpcTempCU->setMergeFlagSubParts( true, 0, 0, uhDepth ); // interprets depth relative to CTU level
          rpcTempCU->setMergeIndexSubParts( uiMergeCand, 0, 0, uhDepth ); // interprets depth relative to CTU level
          rpcTempCU->setInterDirSubParts( uhInterDirNeighbours[uiMergeCand], 0, 0, uhDepth ); // interprets depth relative to CTU level
          rpcTempCU->getCUMvField( REF_PIC_LIST_0 )->setAllMvField( cMvFieldNeighbours[0 + 2*uiMergeCand], SIZE_2Nx2N, 0, 0 ); // interprets depth relative to rpcTempCU level
          rpcTempCU->getCUMvField( REF_PIC_LIST_1 )->setAllMvField( cMvFieldNeighbours[1 + 2*uiMergeCand], SIZE_2Nx2N, 0, 0 ); // interprets depth relative to rpcTempCU level

          // do MC
          m_pcPredSearch->motionCompensation ( rpcTempCU, m_ppcPredYuvTemp[uhDepth] );
          Bool bColourTrans = (m_pcEncCfg->getRGBFormatFlag() && rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans())? true : false;

          if ( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
          {
            bColourTrans = false;
          }
          TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uhDepth];
          if( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && (!bTransquantBypassFlag || sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
          {
            if(!getEnableInterTUACT())
            {
              m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                         m_ppcOrigYuv    [uhDepth],
                                                         pcTmpPredYuv             ,
                                                         m_ppcResiYuvTemp[uhDepth],
                                                         m_ppcResiYuvBest[uhDepth],
                                                         m_ppcRecoYuvTemp[uhDepth],
                                                         (uiNoResidual != 0),
                                                         m_ppcNoCorrYuv  [uhDepth],
                                                         (bColourTrans? ACT_TRAN_CLR: ACT_ORG_CLR)
                                                         DEBUG_STRING_PASS_INTO(tmpStr) );
            }
            else
            {
              m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                         m_ppcOrigYuv    [uhDepth],
                                                         pcTmpPredYuv             ,
                                                         m_ppcResiYuvTemp[uhDepth],
                                                         m_ppcResiYuvBest[uhDepth],
                                                         m_ppcRecoYuvTemp[uhDepth],
                                                         (uiNoResidual != 0),
                                                         m_ppcNoCorrYuv  [uhDepth],
                                                         ACT_TWO_CLR
                                                         DEBUG_STRING_PASS_INTO(tmpStr) );
            }
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                       m_ppcOrigYuv    [uhDepth],
                                                       pcTmpPredYuv             ,
                                                       m_ppcResiYuvTemp[uhDepth],
                                                       m_ppcResiYuvBest[uhDepth],
                                                       m_ppcRecoYuvTemp[uhDepth],
                                                       (uiNoResidual != 0),
                                                       m_ppcNoCorrYuv  [uhDepth],
                                                       ACT_ORG_CLR
                                                       DEBUG_STRING_PASS_INTO(tmpStr) );
          }
          rpcTempCU->setSkipFlagSubParts( rpcTempCU->getQtRootCbf(0) == 0, 0, uhDepth );

#if DEBUG_STRING
          DebugInterPredResiReco(tmpStr, *(m_ppcPredYuvTemp[uhDepth]), *(m_ppcResiYuvBest[uhDepth]), *(m_ppcRecoYuvTemp[uhDepth]), DebugStringGetPredModeMask(rpcTempCU->getPredictionMode(0)));
#endif

          if ((uiNoResidual == 0) && (rpcTempCU->getQtRootCbf(0) == 0))
          {
            // If no residual when allowing for one, then set mark to not try case where residual is forced to 0
            mergeCandBuffer[uiMergeCand] = 1;
          }

          Double rdCost1 = rpcTempCU->getTotalCost();
          if ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() )
          {
            if ( rdCost1 < m_ppcBestCU[uhDepth]->tmpInterRDCost )
            {
              m_ppcBestCU[uhDepth]->tmpInterRDCost = rdCost1;
              m_ppcBestCU[uhDepth]->bInterCSCEnabled = true;
              m_ppcTempCU[uhDepth]->tmpInterRDCost = rdCost1;
              m_ppcTempCU[uhDepth]->bInterCSCEnabled = true;
            }
          }

          Int orgQP = rpcTempCU->getQP( 0 );
          xCheckDQP( rpcTempCU );
          TComDataCU *rpcTempCUPre = rpcTempCU;

          xCheckBestMode(rpcBestCU, rpcTempCU, uhDepth DEBUG_STRING_PASS_INTO(bestStr) DEBUG_STRING_PASS_INTO(tmpStr));

          Bool bParentUseCSC = ( rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans()
                                 && (uhDepth != 0) && (m_ppcBestCU[uhDepth -1]->bInterCSCEnabled) );
          bParentUseCSC = bParentUseCSC || rpcBestCU->getQtRootCbf(0) == 0 || rpcBestCU->getMergeFlag( 0 );
          if(rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && !uiNoResidual && rpcTempCUPre->getQtRootCbf(0) && !bParentUseCSC && (!bTransquantBypassFlag || sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
          {
            if( rpcTempCU != rpcTempCUPre )
            {
              rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag );
              rpcTempCU->copyPartFrom( rpcBestCU, 0, uhDepth );
            }
            if ( !getEnableInterTUACT() )
            {
              bColourTrans = !bColourTrans;
            }
            else
            {
              bColourTrans = m_pcEncCfg->getRGBFormatFlag();
            }
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU,
                                                       m_ppcOrigYuv    [uhDepth],
                                                       pcTmpPredYuv             ,
                                                       m_ppcResiYuvTemp[uhDepth],
                                                       m_ppcResiYuvBest[uhDepth],
                                                       m_ppcRecoYuvTemp[uhDepth],
                                                       (uiNoResidual != 0),
                                                       m_ppcNoCorrYuv  [uhDepth],
                                                       (bColourTrans? ACT_TRAN_CLR: ACT_ORG_CLR)
                                                       DEBUG_STRING_PASS_INTO(tmpStr) );
            rpcTempCU->setSkipFlagSubParts( rpcTempCU->getQtRootCbf(0) == 0, 0, uhDepth );
            Double rdCost = rpcTempCU->getTotalCost();
            if(rdCost < m_ppcBestCU[uhDepth]->tmpInterRDCost )
            {
              m_ppcBestCU[uhDepth]->tmpInterRDCost   = rdCost;
              m_ppcBestCU[uhDepth]->bInterCSCEnabled = false;
              m_ppcTempCU[uhDepth]->tmpInterRDCost   = rdCost;
              m_ppcTempCU[uhDepth]->bInterCSCEnabled = false;
            }

            xCheckDQP( rpcTempCU );
            if(rpcTempCU->getQtRootCbf(0))
            {
              xCheckBestMode( rpcBestCU, rpcTempCU, uhDepth DEBUG_STRING_PASS_INTO(bestStr) DEBUG_STRING_PASS_INTO(tmpStr) );
            }
          }
          rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag );

          if( m_pcEncCfg->getUseFastDecisionForMerge() && !bestIsSkip )
          {
            bestIsSkip = rpcBestCU->getQtRootCbf(0) == 0;
          }
        }
      }
    }

    if(uiNoResidual == 0 && m_pcEncCfg->getUseEarlySkipDetection())
    {
      if(rpcBestCU->getQtRootCbf( 0 ) == 0)
      {
        if( rpcBestCU->getMergeFlag( 0 ))
        {
          *earlyDetectionSkipMode = true;
        }
        else if(m_pcEncCfg->getMotionEstimationSearchMethod() != MESEARCH_SELECTIVE)
        {
          Int absoulte_MV=0;
          for ( UInt uiRefListIdx = 0; uiRefListIdx < 2; uiRefListIdx++ )
          {
            if ( rpcBestCU->getSlice()->getNumRefIdx( RefPicList( uiRefListIdx ) ) > 0 )
            {
              TComCUMvField* pcCUMvField = rpcBestCU->getCUMvField(RefPicList( uiRefListIdx ));
              Int iHor = pcCUMvField->getMvd( 0 ).getAbsHor();
              Int iVer = pcCUMvField->getMvd( 0 ).getAbsVer();
              absoulte_MV+=iHor+iVer;
            }
          }

          if(absoulte_MV == 0)
          {
            *earlyDetectionSkipMode = true;
          }
        }
      }
    }
  }
  DEBUG_STRING_APPEND(sDebug, bestStr)
}


#if AMP_MRG
Void TEncCu::xCheckRDCostInter( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, PartSize ePartSize DEBUG_STRING_FN_DECLARE(sDebug), Bool bUseMRG, TComMv *iMVCandList)
#else
Void TEncCu::xCheckRDCostInter( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, PartSize ePartSize, TComMv *iMVCandList )
#endif
{
  DEBUG_STRING_NEW(sTest)

  if(getFastDeltaQp())
  {
    const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
    const UInt fastDeltaQPCuMaxSize = Clip3(sps.getMaxCUHeight()>>(sps.getLog2DiffMaxMinCodingBlockSize()), sps.getMaxCUHeight(), 32u);
    if(ePartSize != SIZE_2Nx2N || rpcTempCU->getWidth( 0 ) > fastDeltaQPCuMaxSize)
    {
      return; // only check necessary 2Nx2N Inter in fast deltaqp mode
    }
  }

  // prior to this, rpcTempCU will have just been reset using rpcTempCU->initEstData( uiDepth, iQP, bIsLosslessMode );
  UChar uhDepth = rpcTempCU->getDepth( 0 );

  rpcTempCU->setPartSizeSubParts  ( ePartSize,  0, uhDepth );
  rpcTempCU->setPredModeSubParts  ( MODE_INTER, 0, uhDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uhDepth );

#if AMP_MRG
  rpcTempCU->setMergeAMP (true);
  Bool valid = m_pcPredSearch->predInterSearch ( rpcTempCU, m_ppcOrigYuv[uhDepth], m_ppcPredYuvTemp[uhDepth], m_ppcResiYuvTemp[uhDepth], m_ppcRecoYuvTemp[uhDepth] DEBUG_STRING_PASS_INTO(sTest), false, bUseMRG, iMVCandList );
#else
  Bool valid = m_pcPredSearch->predInterSearch ( rpcTempCU, m_ppcOrigYuv[uhDepth], m_ppcPredYuvTemp[uhDepth], m_ppcResiYuvTemp[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, iMVCandList );
#endif

  if( !valid )
  {
    return;
  }

#if AMP_MRG
  if ( !rpcTempCU->getMergeAMP() )
  {
    return;
  }
#endif

  TComDataCU *rpcTempCUPre = NULL;
  Bool   bEnableTrans      = rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans();

  UChar  uiColourTransform = 0;
  Bool   bRGB              = m_pcEncCfg->getRGBFormatFlag();
  SChar  orgQP             = rpcTempCU->getQP( 0 );
  Bool   bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);
  const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
  if ( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
  {
    bEnableTrans = false;
  }
  TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uhDepth];
  for(UInt i = 0;  i < 2 ; i++)
  {
    uiColourTransform = (bRGB && bEnableTrans)? (1-i): i;
    if ( i == 0 )
    {
      if ( bEnableTrans )
      {
        if ( !getEnableInterTUACT() )
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], (uiColourTransform? ACT_TRAN_CLR: ACT_ORG_CLR) DEBUG_STRING_PASS_INTO(sTest) );
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TWO_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
      else
      {
        m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
      }
    }
    else
    {
      if ( m_pcEncCfg->getRGBFormatFlag() )
      {
        if ( !getEnableInterTUACT() )
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
      else
      {
        if ( !getEnableInterTUACT() )
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
    }
    rpcTempCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

#if DEBUG_STRING
    DebugInterPredResiReco(sTest, *(m_ppcPredYuvTemp[uhDepth]), *(m_ppcResiYuvBest[uhDepth]), *(m_ppcRecoYuvTemp[uhDepth]), DebugStringGetPredModeMask(rpcTempCU->getPredictionMode(0)));
#endif

    xCheckDQP( rpcTempCU );

    if ( bEnableTrans )
    {
      if ( !i )
      {
        Double rdCost1 = rpcTempCU->getTotalCost();
        if ( rdCost1 < m_ppcBestCU[uhDepth]->tmpInterRDCost )
        {
          m_ppcBestCU[uhDepth]->tmpInterRDCost = rdCost1;
          m_ppcBestCU[uhDepth]->bInterCSCEnabled = true;
          m_ppcTempCU[uhDepth]->tmpInterRDCost = rdCost1;
          m_ppcTempCU[uhDepth]->bInterCSCEnabled = true;
        }
      }
      else
      {
        Double rdCost = rpcTempCU->getTotalCost();
        if ( rdCost < m_ppcBestCU[uhDepth]->tmpInterRDCost )
        {
          m_ppcBestCU[uhDepth]->tmpInterRDCost = rdCost;
          m_ppcBestCU[uhDepth]->bInterCSCEnabled = false;
          m_ppcTempCU[uhDepth]->tmpInterRDCost = rdCost;
          m_ppcTempCU[uhDepth]->bInterCSCEnabled = false;
        }
      }
    }
    rpcTempCUPre = rpcTempCU;

    xCheckBestMode(rpcBestCU, rpcTempCU, uhDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest));

    if(bEnableTrans)
    {
      if( !rpcBestCU->isInter(0) || rpcBestCU->isSkipped(0) )
      {
        return;
      }
      Bool bParentUseCSC = ( (uhDepth != 0) && (m_ppcBestCU[uhDepth -1]->bInterCSCEnabled) );
      if(!i && (!rpcTempCUPre->getQtRootCbf(0) || bParentUseCSC))
      {
        return;
      }
      else if(!i && rpcTempCUPre->getQtRootCbf(0))
      {
        if( rpcTempCU != rpcTempCUPre )
        {
          rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag);
          rpcTempCU->copyPartFrom( rpcBestCU, 0, uhDepth );
        }
      }
    }
    else
    {
      return;
    }
  }
}

Void TEncCu::xCheckRDCostIntraCSC( TComDataCU     *&rpcBestCU,
                                   TComDataCU     *&rpcTempCU,
#if LBCFMD
								   	Bool isNonText,
									Bool& isSpecial,
#endif
                                   Double         &cost,
                                   PartSize       eSize,
                                   ACTRDTestTypes eACTRDTestType,
                                   Bool           bReuseIntraMode
                                   DEBUG_STRING_FN_DECLARE(sDebug)
                                 )
{
#if TIME_MODE_DEPTH
  clock_t lResult;
  clock_t lBefore = clock();
#endif
  DEBUG_STRING_NEW(sTest)

  UInt uiDepth = rpcTempCU->getDepth( 0 );
  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );
  rpcTempCU->setPartSizeSubParts( eSize, 0, uiDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTRA, 0, uiDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );

  m_pcPredSearch->estIntraPredQTCT( 
#if LBCFMD
	  isNonText,isSpecial, 
#endif
	  rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth], eACTRDTestType, bReuseIntraMode DEBUG_STRING_PASS_INTO(sTest) );

  m_pcRDGoOnSbacCoder->load(m_pppcRDSbacCoder[uiDepth][CI_CURR_BEST]);
  m_pcEntropyCoder->resetBits();

  if ( rpcTempCU->getSlice()->getPPS()->getTransquantBypassEnableFlag() )
  {
    m_pcEntropyCoder->encodeCUTransquantBypassFlag( rpcTempCU, 0, true );
  }

  m_pcEntropyCoder->encodeSkipFlag ( rpcTempCU, 0, true );

  m_pcEntropyCoder->encodePredMode( rpcTempCU, 0, true );
#if SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdjFlag = getCodeChromaQpAdjFlag();

  m_pcEntropyCoder->encodePLTModeInfo( rpcTempCU, 0, true, &bCodeDQP, &codeChromaQpAdjFlag );
#endif
  m_pcEntropyCoder->encodePartSize( rpcTempCU, 0, uiDepth, true );
  m_pcEntropyCoder->encodePredInfo( rpcTempCU, 0 );
  m_pcEntropyCoder->encodeIPCMInfo(rpcTempCU, 0, true );

  // Encode Coefficients
#if !SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdjFlag = getCodeChromaQpAdjFlag();
#endif

  m_pcEntropyCoder->encodeCoeff( rpcTempCU, 0, uiDepth, bCodeDQP, codeChromaQpAdjFlag );
  setCodeChromaQpAdjFlag( codeChromaQpAdjFlag );
  setdQPFlag( bCodeDQP );

  m_pcRDGoOnSbacCoder->store(m_pppcRDSbacCoder[uiDepth][CI_TEMP_BEST]);

  rpcTempCU->getTotalBits() = m_pcEntropyCoder->getNumberOfWrittenBits();
  rpcTempCU->getTotalBins() = ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
  rpcTempCU->getTotalCost() = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

  xCheckDQP( rpcTempCU );

  cost = rpcTempCU->getTotalCost();
#if OUTPUT_MODE_COST
  if (cost < rpcBestCU->getRdCostMode(0))
	  rpcBestCU->setRdCostMode(0, cost);
#endif
  xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest));
#if TIME_MODE_DEPTH
  lResult = clock() - lBefore;
  lTimeIntraCSCF[uiDepth] += lResult;
  lTimeIntraCSCF[4] += lResult;
  uiCheckIntraCSCF[uiDepth]++;
  uiCheckIntraCSCF[4]++;
  if (eACTRDTestType == ACT_ORG_CLR)
  {
	lTimeIntraM[uiDepth] += lResult;
	lTimeIntraM[4] += lResult;
	uiCheckIntraM[uiDepth]++;
	uiCheckIntraM[4]++;
  }
  else if (eACTRDTestType == ACT_TRAN_CLR)
  {
	lTimeIntraCSCM[uiDepth] += lResult;
	lTimeIntraCSCM[4] += lResult;
	uiCheckIntraCSCM[uiDepth]++;
	uiCheckIntraCSCM[4]++;
  }
  else
  {
	printf("\nACT_TWO_CLR\n");
  }
#endif
}

Void TEncCu::xCheckRDCostIntra( TComDataCU *&rpcBestCU,
                                TComDataCU *&rpcTempCU,
#if LBCFMD
								Bool isNonText,
								Bool &isSpecial,
#endif
                                Double      &cost,
                                PartSize     eSize
                                DEBUG_STRING_FN_DECLARE(sDebug),
                                Bool         bRGBIntraModeReuse
                               )
{
#if TIME_MODE_DEPTH
  clock_t lResult;
  clock_t lBefore = clock();
#endif
  DEBUG_STRING_NEW(sTest)

  if(getFastDeltaQp())
  {
    const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
    const UInt fastDeltaQPCuMaxSize = Clip3(sps.getMaxCUHeight()>>(sps.getLog2DiffMaxMinCodingBlockSize()), sps.getMaxCUHeight(), 32u);
    if(rpcTempCU->getWidth( 0 ) > fastDeltaQPCuMaxSize)
    {
      return; // only check necessary 2Nx2N Intra in fast deltaqp mode
    }
  }

  UInt uiDepth = rpcTempCU->getDepth( 0 );

  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );

  rpcTempCU->setPartSizeSubParts( eSize, 0, uiDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTRA, 0, uiDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );
  rpcTempCU->setColourTransformSubParts(false, 0 ,uiDepth);

  Pel resiLuma[NUMBER_OF_STORED_RESIDUAL_TYPES][MAX_CU_SIZE * MAX_CU_SIZE];

  if( bRGBIntraModeReuse )
  {
    m_pcPredSearch->estIntraPredLumaQTWithModeReuse( rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth], resiLuma );
  }
  else
  {
    m_pcPredSearch->estIntraPredLumaQT( 
#if LBCFMD
		isNonText,isSpecial,
#endif
		rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth], resiLuma DEBUG_STRING_PASS_INTO(sTest) );
  }

  m_ppcRecoYuvTemp[uiDepth]->copyToPicComponent(COMPONENT_Y, rpcTempCU->getPic()->getPicYuvRec(), rpcTempCU->getCtuRsAddr(), rpcTempCU->getZorderIdxInCtu() );

  if (rpcBestCU->getPic()->getChromaFormat()!=CHROMA_400)
  {
    if( bRGBIntraModeReuse )
    {
      m_pcPredSearch->estIntraPredChromaQTWithModeReuse( rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth], resiLuma );
    }
    else
    {
      m_pcPredSearch->estIntraPredChromaQT( rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth], resiLuma DEBUG_STRING_PASS_INTO(sTest) );
    }
  }

  m_pcEntropyCoder->resetBits();

  if ( rpcTempCU->getSlice()->getPPS()->getTransquantBypassEnableFlag())
  {
    m_pcEntropyCoder->encodeCUTransquantBypassFlag( rpcTempCU, 0,          true );
  }

  m_pcEntropyCoder->encodeSkipFlag ( rpcTempCU, 0,          true );
  m_pcEntropyCoder->encodePredMode( rpcTempCU, 0,          true );
#if SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdjFlag = getCodeChromaQpAdjFlag();

  m_pcEntropyCoder->encodePLTModeInfo( rpcTempCU, 0, true, &bCodeDQP, &codeChromaQpAdjFlag );
#endif
  m_pcEntropyCoder->encodePartSize( rpcTempCU, 0, uiDepth, true );
  m_pcEntropyCoder->encodePredInfo( rpcTempCU, 0 );
  m_pcEntropyCoder->encodeIPCMInfo(rpcTempCU, 0, true );

  // Encode Coefficients
#if !SCM_S0043_PLT_DELTA_QP
  Bool bCodeDQP = getdQPFlag();
  Bool codeChromaQpAdjFlag = getCodeChromaQpAdjFlag();
#endif
  m_pcEntropyCoder->encodeCoeff( rpcTempCU, 0, uiDepth, bCodeDQP, codeChromaQpAdjFlag );
  setCodeChromaQpAdjFlag( codeChromaQpAdjFlag );
  setdQPFlag( bCodeDQP );

  m_pcRDGoOnSbacCoder->store(m_pppcRDSbacCoder[uiDepth][CI_TEMP_BEST]);

  rpcTempCU->getTotalBits() = m_pcEntropyCoder->getNumberOfWrittenBits();
  rpcTempCU->getTotalBins() = ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
  rpcTempCU->getTotalCost() = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

  xCheckDQP( rpcTempCU );

  cost = rpcTempCU->getTotalCost();
#if OUTPUT_MODE_COST
  if (cost < rpcBestCU->getRdCostMode(0))
	rpcBestCU->setRdCostMode(0, cost);
#endif
  xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest));
#if TIME_MODE_DEPTH
  lResult = clock() - lBefore;
  lTimeIntraF[uiDepth] += lResult;
  lTimeIntraF[4] += lResult;
  uiCheckIntraF[uiDepth]++;
  uiCheckIntraF[4]++;
  lTimeIntraM[uiDepth] += lResult;
  lTimeIntraM[4] += lResult;
  uiCheckIntraM[uiDepth]++;
  uiCheckIntraM[4]++;
#endif
}

Void TEncCu::xCheckRDCostIntraBC( TComDataCU *&rpcBestCU,
                                  TComDataCU *&rpcTempCU,
                                  Bool         bUse1DSearchFor8x8,
                                  PartSize     eSize,
                                  Double      &rdCost,
                                  Bool         testPredOnly,
                                  TComMv      *iMVCandList
                                  DEBUG_STRING_FN_DECLARE(sDebug))
{
  DEBUG_STRING_NEW(sTest)
  UInt uiDepth = rpcTempCU->getDepth( 0 );

  rpcTempCU->setDepthSubParts( uiDepth, 0 );
  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );
  rpcTempCU->setPartSizeSubParts( eSize, 0, uiDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTER, 0, uiDepth );

  rpcTempCU->setIntraDirSubParts( CHANNEL_TYPE_LUMA, DC_IDX, 0, uiDepth );
  rpcTempCU->setIntraDirSubParts( CHANNEL_TYPE_CHROMA, DC_IDX, 0, uiDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );

  // intra BV search
  const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
  if( rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans () && m_pcEncCfg->getRGBFormatFlag() && (!rpcTempCU->getCUTransquantBypass(0) || (sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA ))) )
  {
    m_ppcOrigYuv[uiDepth]->copyFromPicYuv( rpcTempCU->getPic()->getPicYuvResi(), rpcTempCU->getCtuRsAddr(), rpcTempCU->getZorderIdxInCtu() );
    rpcTempCU->getPic()->exchangePicYuvRec();                                                                          //YCgCo reference picture
  }

  Bool bValid = m_pcPredSearch->predIntraBCSearch ( rpcTempCU,
                                                    m_ppcOrigYuv[uiDepth],
                                                    m_ppcPredYuvTemp[uiDepth],
                                                    m_ppcResiYuvTemp[uiDepth],
                                                    m_ppcRecoYuvTemp[uiDepth]
                                                    DEBUG_STRING_PASS_INTO(sTest),
                                                    bUse1DSearchFor8x8,
                                                    false,
                                                    testPredOnly
                                                    );

  if ( bValid && (rpcTempCU->getWidth( 0 ) <= 16) && (eSize == SIZE_2NxN || eSize == SIZE_Nx2N) )
  {
    Int iDummyWidth, iDummyHeight;
    UInt uiPartAddr = 0;
    rpcTempCU->getPartIndexAndSize( 1, uiPartAddr, iDummyWidth, iDummyHeight );
    iMVCandList[0] = rpcTempCU->getCUMvField( REF_PIC_LIST_0 )->getMv( 0 );
    iMVCandList[1] = rpcTempCU->getCUMvField( REF_PIC_LIST_0 )->getMv( uiPartAddr );
  }
  if( rpcTempCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && m_pcEncCfg->getRGBFormatFlag() && (!rpcTempCU->getCUTransquantBypass(0) || (sps.getBitDepth( CHANNEL_TYPE_LUMA ) == sps.getBitDepth( CHANNEL_TYPE_CHROMA ))) )
  {
    m_ppcOrigYuv[uiDepth]->copyFromPicYuv( rpcTempCU->getPic()->getPicYuvOrg(), rpcTempCU->getCtuRsAddr(), rpcTempCU->getZorderIdxInCtu() );
    rpcTempCU->getPic()->exchangePicYuvRec();
  }

  if (bValid)
  {
    TComDataCU *rpcTempCUPre = NULL;
    Bool   bEnableTrans      = rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans();
    UChar  uiColourTransform = 0;
    Bool   bRGB              = m_pcEncCfg->getRGBFormatFlag();
    Double dCostFst          = MAX_DOUBLE;
    SChar   orgQP            = rpcTempCU->getQP( 0 );
    Bool   bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);
    if ( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
    {
      bEnableTrans = false;
    }
    TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uiDepth];
    for(UInt i = 0;  i < (testPredOnly ? 1 : 2) ; i++)
    {
      uiColourTransform = ( bRGB && bEnableTrans )? (1-i): i;

      if( uiColourTransform && m_pcEncCfg->getRGBFormatFlag())
      {
        m_pcPredSearch->motionCompensation ( rpcTempCU, m_ppcPredYuvTemp[uiDepth] );
      }

      if ( i == 0 )
      {
        if ( bEnableTrans )
        {
          if ( !getEnableIBCTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], (uiColourTransform? ACT_TRAN_CLR: ACT_ORG_CLR) DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TWO_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
      else
      {
        if ( m_pcEncCfg->getRGBFormatFlag() )
        {
          if ( !getEnableIBCTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          if ( !getEnableIBCTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
      }
      rpcTempCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );
      rdCost = rpcTempCU->getTotalCost();
#if OUTPUT_MODE_COST
	  if (rdCost < rpcBestCU->getRdCostMode(1))
		rpcBestCU->setRdCostMode(1, rdCost);
#endif
#if DEBUG_STRING
      DebugInterPredResiReco(sTest, *(m_ppcPredYuvTemp[uiDepth]), *(m_ppcResiYuvBest[uiDepth]), *(m_ppcRecoYuvTemp[uiDepth]), DebugStringGetPredModeMask(rpcTempCU->getPredictionMode(0)));
#endif

      if ( bEnableTrans )
      {
        if ( !i )
        {
          if ( rdCost < m_ppcBestCU[uiDepth]->tmpIntraBCRDCost )
          {
            m_ppcBestCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcBestCU[uiDepth]->bIntraBCCSCEnabled = true;
            m_ppcTempCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcTempCU[uiDepth]->bIntraBCCSCEnabled = true;
          }
        }
        else
        {
          if ( rdCost < m_ppcBestCU[uiDepth]->tmpIntraBCRDCost )
          {
            m_ppcBestCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcBestCU[uiDepth]->bIntraBCCSCEnabled = false;
            m_ppcTempCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcTempCU[uiDepth]->bIntraBCCSCEnabled = false;
          }
        }
      }
      xCheckDQP( rpcTempCU );
      rpcTempCUPre = rpcTempCU;
      xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest));
      if( bEnableTrans )
      {
        if( testPredOnly || !rpcBestCU->isIntraBC(0) )
        {
          return;
        }
        Bool bParentUseCSC = ( ((uiDepth > 2)) && (m_ppcBestCU[uiDepth -1]->bIntraBCCSCEnabled) );
        if(!i && (!rpcTempCUPre->getQtRootCbf(0) || bParentUseCSC))
        {
          return;
        }
        else if(!i)
        {
          dCostFst = rdCost;
          if( rpcTempCU != rpcTempCUPre )
          {
            rpcTempCU->initEstData( uiDepth, orgQP, bTransquantBypassFlag );
            rpcTempCU->copyPartFrom( rpcBestCU, 0, uiDepth );
          }
        }
        else
        {
          if ( rpcTempCU == rpcTempCUPre )
          {
            rdCost = dCostFst;
#if OUTPUT_MODE_COST
			if (rdCost < rpcBestCU->getRdCostMode(1))
				rpcBestCU->setRdCostMode(1, rdCost);
#endif
          }
        }
      }
      else
      {
        return;
      }
    }
  }
  else
  {
    rdCost = MAX_DOUBLE;
  }
}
//only for 8x8
Void TEncCu::xCheckRDCostIntraBCMixed( TComDataCU *&rpcBestCU,
                                                TComDataCU *&rpcTempCU,
                                                PartSize     eSize,
                                                Double      &rdCost
                                                DEBUG_STRING_FN_DECLARE( sDebug ),
                                                TComMv* iMVCandList
)
{
  DEBUG_STRING_NEW( sTest )
  UInt uiDepth = rpcTempCU->getDepth( 0 );
  rpcTempCU->setPredModeSubParts( MODE_INTER, 0, uiDepth );
  rpcTempCU->setDepthSubParts( uiDepth, 0 );
  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );
  rpcTempCU->setPartSizeSubParts( eSize, 0, uiDepth );
  rpcTempCU->setIntraDirSubParts( CHANNEL_TYPE_LUMA, DC_IDX, 0, uiDepth );
  rpcTempCU->setIntraDirSubParts( CHANNEL_TYPE_CHROMA, DC_IDX, 0, uiDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass( 0 ) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );

  Bool bValid = m_pcPredSearch->predMixedIntraBCInterSearch( rpcTempCU,
    m_ppcOrigYuv[uiDepth],
    m_ppcPredYuvTemp[uiDepth],
    m_ppcResiYuvTemp[uiDepth],
    m_ppcRecoYuvTemp[uiDepth]
    DEBUG_STRING_PASS_INTO( sTest ),
    iMVCandList,
    false
    );

  if ( bValid )
  {
    TComDataCU *rpcTempCUPre = NULL;
    Bool   bEnableTrans      = rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans();
    UChar  uiColourTransform = 0;
    Bool   bRGB              = m_pcEncCfg->getRGBFormatFlag();
    Double dCostFst          = MAX_DOUBLE;
    SChar   orgQP            = rpcTempCU->getQP( 0 );
    Bool   bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);
    const TComSPS &sps       = *(rpcTempCU->getSlice()->getSPS());
    if ( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
    {
      bEnableTrans = false;
    }
    TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uiDepth];

    for(UInt i = 0;  i < 2 ; i++)
    {
      uiColourTransform = (bRGB && bEnableTrans)? (1-i): i;
      if ( i == 0 )
      {
        if ( bEnableTrans )
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], (uiColourTransform? ACT_TRAN_CLR: ACT_ORG_CLR) DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TWO_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
      else
      {
        if ( m_pcEncCfg->getRGBFormatFlag() )
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uiDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uiDepth], m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], false, m_ppcNoCorrYuv[uiDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
      }
      rpcTempCU->getTotalCost()  = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );
      rdCost = rpcTempCU->getTotalCost();
#if OUTPUT_MODE_COST
	  if (rdCost < rpcBestCU->getRdCostMode(1))
		  rpcBestCU->setRdCostMode(1, rdCost);
#endif
#if DEBUG_STRING
      DebugInterPredResiReco(sTest, *(m_ppcPredYuvTemp[uiDepth]), *(m_ppcResiYuvBest[uiDepth]), *(m_ppcRecoYuvTemp[uiDepth]), DebugStringGetPredModeMask(rpcTempCU->getPredictionMode(0)));
#endif
      if ( bEnableTrans )
      {
        if ( !i )
        {
          if ( rdCost < m_ppcBestCU[uiDepth]->tmpIntraBCRDCost )
          {
            m_ppcBestCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcBestCU[uiDepth]->bIntraBCCSCEnabled = true;
            m_ppcTempCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcTempCU[uiDepth]->bIntraBCCSCEnabled = true;
          }
        }
        else
        {
          if ( rdCost < m_ppcBestCU[uiDepth]->tmpIntraBCRDCost )
          {
            m_ppcBestCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcBestCU[uiDepth]->bIntraBCCSCEnabled = false;
            m_ppcTempCU[uiDepth]->tmpIntraBCRDCost = rdCost;
            m_ppcTempCU[uiDepth]->bIntraBCCSCEnabled = false;
          }
        }
      }
      xCheckDQP( rpcTempCU );
      rpcTempCUPre = rpcTempCU;
      xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest));
      if( bEnableTrans )
      {
        Bool bParentUseCSC = ( ((uiDepth > 2)) && (m_ppcBestCU[uiDepth -1]->bIntraBCCSCEnabled) );
        if(!i && (!rpcTempCUPre->getQtRootCbf(0) || bParentUseCSC))
        {
          return;
        }
        else if(!i)
        {
          dCostFst = rdCost;
          if( rpcTempCU != rpcTempCUPre )
          {
            rpcTempCU->initEstData( uiDepth, orgQP, bTransquantBypassFlag );
            rpcTempCU->copyPartFrom( rpcBestCU, 0, uiDepth );
          }
        }
        else
        {
          if ( rpcTempCU == rpcTempCUPre )
          {
            rdCost = dCostFst;
#if OUTPUT_MODE_COST
			if (rdCost < rpcBestCU->getRdCostMode(1))
				rpcBestCU->setRdCostMode(1, rdCost);
#endif
          }
        }
      }
      else
      {
        return;
      }
    }
  }
  else
  {
    rdCost = MAX_DOUBLE;
  }
}

Void TEncCu::xCheckRDCostHashInter( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, Bool& isPerfectMatch DEBUG_STRING_FN_DECLARE(sDebug) )
{
  DEBUG_STRING_NEW(sTest)

  isPerfectMatch = false;
  UChar uhDepth = rpcTempCU->getDepth( 0 );
  rpcTempCU->setDepthSubParts( uhDepth, 0 );
  rpcTempCU->setSkipFlagSubParts( false, 0, uhDepth );
  rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uhDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTER, 0, uhDepth );
  rpcTempCU->setMergeFlagSubParts( false, 0, 0, uhDepth );

  if ( m_pcPredSearch->predInterHashSearch( rpcTempCU, m_ppcOrigYuv[uhDepth], m_ppcPredYuvTemp[uhDepth], isPerfectMatch ) )
  {
    TComDataCU *rpcTempCUPre = NULL;
    Bool   bEnableTrans      = rpcBestCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans();
    UChar  uiColourTransform = 0;
    Bool   bRGB              = m_pcEncCfg->getRGBFormatFlag();
    SChar   orgQP            = rpcTempCU->getQP( 0 );
    Bool   bTransquantBypassFlag = rpcTempCU->getCUTransquantBypass(0);
    const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
    if ( bTransquantBypassFlag && (sps.getBitDepth( CHANNEL_TYPE_LUMA ) != sps.getBitDepth( CHANNEL_TYPE_CHROMA )) )
    {
      bEnableTrans = false;
    }

    TComYuv* pcTmpPredYuv = m_ppcPredYuvTemp[uhDepth];
    for(UInt i = 0;  i < 2 ; i++)
    {
      uiColourTransform = ( bRGB && bEnableTrans )? (1-i): i;
      if ( i == 0 )
      {
        if ( bEnableTrans )
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], (uiColourTransform? ACT_TRAN_CLR: ACT_ORG_CLR) DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TWO_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
        }
      }
      else
      {
        if ( m_pcEncCfg->getRGBFormatFlag() )
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
        else
        {
          if ( !getEnableInterTUACT() )
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_TRAN_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
          else
          {
            m_pcPredSearch->encodeResAndCalcRdInterCU( rpcTempCU, m_ppcOrigYuv[uhDepth], pcTmpPredYuv, m_ppcResiYuvTemp[uhDepth], m_ppcResiYuvBest[uhDepth], m_ppcRecoYuvTemp[uhDepth], false, m_ppcNoCorrYuv[uhDepth], ACT_ORG_CLR DEBUG_STRING_PASS_INTO(sTest) );
          }
        }
      }
      rpcTempCU->getTotalCost() = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

      if(!i)
      {
        Double rdCost1 = rpcTempCU->getTotalCost();
        if( rdCost1 < m_ppcBestCU[uhDepth]->tmpInterRDCost )
        {
          m_ppcBestCU[uhDepth]->tmpInterRDCost   = rdCost1;
          m_ppcBestCU[uhDepth]->bInterCSCEnabled = true;
          m_ppcTempCU[uhDepth]->tmpInterRDCost   = rdCost1;
          m_ppcTempCU[uhDepth]->bInterCSCEnabled = true;
        }
      }
      else
      {
        Double rdCost = rpcTempCU->getTotalCost();
        if( rdCost < m_ppcBestCU[uhDepth]->tmpInterRDCost )
        {
          m_ppcBestCU[uhDepth]->tmpInterRDCost   = rdCost;
          m_ppcBestCU[uhDepth]->bInterCSCEnabled = false;
          m_ppcTempCU[uhDepth]->tmpInterRDCost   = rdCost;
          m_ppcTempCU[uhDepth]->bInterCSCEnabled = false;
        }
      }

      xCheckDQP( rpcTempCU );
      rpcTempCUPre = rpcTempCU;

      xCheckBestMode( rpcBestCU, rpcTempCU, uhDepth DEBUG_STRING_PASS_INTO(sDebug) DEBUG_STRING_PASS_INTO(sTest) );
      if(bEnableTrans)
      {
        if( !rpcBestCU->isInter(0) || rpcBestCU->isSkipped(0)  )
        {
          return;
        }
        Bool bParentUseCSC = ( (uhDepth != 0) && (m_ppcBestCU[uhDepth -1]->bInterCSCEnabled) );
        if(!i && (!rpcTempCUPre->getQtRootCbf(0) || bParentUseCSC))
        {
          return;
        }
        else if(!i && rpcTempCUPre->getQtRootCbf(0))
        {
          if( rpcTempCU != rpcTempCUPre )
          {
            rpcTempCU->initEstData( uhDepth, orgQP, bTransquantBypassFlag);
            rpcTempCU->copyPartFrom( rpcBestCU, 0, uhDepth );
          }
        }
      }
      else
      {
        return;
      }
    }
  }
}


/** Check R-D costs for a CU with PCM mode.
 * \param rpcBestCU pointer to best mode CU data structure
 * \param rpcTempCU pointer to testing mode CU data structure
 * \returns Void
 *
 * \note Current PCM implementation encodes sample values in a lossless way. The distortion of PCM mode CUs are zero. PCM mode is selected if the best mode yields bits greater than that of PCM mode.
 */
Void TEncCu::xCheckIntraPCM( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU )
{
  if(getFastDeltaQp())
  {
    const TComSPS &sps=*(rpcTempCU->getSlice()->getSPS());
    const UInt fastDeltaQPCuMaxPCMSize = Clip3((UInt)1<<sps.getPCMLog2MinSize(), (UInt)1<<sps.getPCMLog2MaxSize(), 32u);
    if (rpcTempCU->getWidth( 0 ) > fastDeltaQPCuMaxPCMSize)
    {
      return;   // only check necessary PCM in fast deltaqp mode
    }
  }
  
  UInt uiDepth = rpcTempCU->getDepth( 0 );

  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );

  rpcTempCU->setIPCMFlag(0, true);
  rpcTempCU->setIPCMFlagSubParts (true, 0, rpcTempCU->getDepth(0));
  rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uiDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTRA, 0, uiDepth );
  rpcTempCU->setTrIdxSubParts ( 0, 0, uiDepth );
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );

  m_pcPredSearch->IPCMSearch( rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth], m_ppcRecoYuvTemp[uiDepth]);

  m_pcRDGoOnSbacCoder->load(m_pppcRDSbacCoder[uiDepth][CI_CURR_BEST]);

  m_pcEntropyCoder->resetBits();

  if ( rpcTempCU->getSlice()->getPPS()->getTransquantBypassEnableFlag())
  {
    m_pcEntropyCoder->encodeCUTransquantBypassFlag( rpcTempCU, 0,          true );
  }

  m_pcEntropyCoder->encodeSkipFlag ( rpcTempCU, 0,          true );
  m_pcEntropyCoder->encodePredMode ( rpcTempCU, 0,          true );
#if SCM_S0043_PLT_DELTA_QP
  m_pcEntropyCoder->encodePLTModeInfo( rpcTempCU, 0, true );
#endif
  m_pcEntropyCoder->encodePartSize ( rpcTempCU, 0, uiDepth, true );
  m_pcEntropyCoder->encodeIPCMInfo ( rpcTempCU, 0, true );

  m_pcRDGoOnSbacCoder->store(m_pppcRDSbacCoder[uiDepth][CI_TEMP_BEST]);

  rpcTempCU->getTotalBits() = m_pcEntropyCoder->getNumberOfWrittenBits();
  rpcTempCU->getTotalBins() = ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
  rpcTempCU->getTotalCost() = m_pcRdCost->calcRdCost( rpcTempCU->getTotalBits(), rpcTempCU->getTotalDistortion() );

  xCheckDQP( rpcTempCU );
  DEBUG_STRING_NEW(a)
  DEBUG_STRING_NEW(b)
  xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(a) DEBUG_STRING_PASS_INTO(b));
}

UInt TEncCu::xCheckPLTMode(TComDataCU *&rpcBestCU, TComDataCU *&rpcTempCU, Bool forcePLTPrediction, UInt uiIterNumber, UInt *pltSize)
{
  UInt uiDepth = rpcTempCU->getDepth( 0 );

  rpcTempCU->setSkipFlagSubParts( false, 0, uiDepth );
  rpcTempCU->setIPCMFlag(0, false);
  rpcTempCU->setIPCMFlagSubParts (false, 0, rpcTempCU->getDepth(0));
  rpcTempCU->setPartSizeSubParts( SIZE_2Nx2N, 0, uiDepth );
  rpcTempCU->setPredModeSubParts( MODE_INTRA, 0, uiDepth );
  rpcTempCU->setTrIdxSubParts ( 0, 0, uiDepth );
  rpcTempCU->setPLTModeFlagSubParts(true, 0, rpcTempCU->getDepth(0));
  rpcTempCU->setChromaQpAdjSubParts( rpcTempCU->getCUTransquantBypass(0) ? 0 : m_cuChromaQpOffsetIdxPlus1, 0, uiDepth );

  UInt testedModes=m_pcPredSearch->PLTSearch(rpcTempCU, m_ppcOrigYuv[uiDepth], m_ppcPredYuvTemp[uiDepth], m_ppcResiYuvTemp[uiDepth],
    m_ppcResiYuvBest[uiDepth], m_ppcRecoYuvTemp[uiDepth], forcePLTPrediction, uiIterNumber, pltSize);

  xCheckDQP( rpcTempCU );
  DEBUG_STRING_NEW(a)
	  DEBUG_STRING_NEW(b)
#if OUTPUT_MODE_COST
	  if (rpcTempCU->getTotalCost() < rpcBestCU->getRdCostMode(2))
		  rpcBestCU->setRdCostMode(2, rpcTempCU->getTotalCost());
#endif
  xCheckBestMode(rpcBestCU, rpcTempCU, uiDepth DEBUG_STRING_PASS_INTO(a) DEBUG_STRING_PASS_INTO(b));

  return (testedModes);
}


/** check whether current try is the best with identifying the depth of current try
 * \param rpcBestCU
 * \param rpcTempCU
 * \param uiDepth
 */
Void TEncCu::xCheckBestMode( TComDataCU*& rpcBestCU, TComDataCU*& rpcTempCU, UInt uiDepth DEBUG_STRING_FN_DECLARE(sParent) DEBUG_STRING_FN_DECLARE(sTest) DEBUG_STRING_PASS_INTO(Bool bAddSizeInfo) )
{
  if( rpcTempCU->getTotalCost() < rpcBestCU->getTotalCost() )
  {
    TComYuv* pcYuv;
    // Change Information data
    TComDataCU* pcCU = rpcBestCU;
    rpcBestCU = rpcTempCU;
    rpcTempCU = pcCU;

    // Change Prediction data
    pcYuv = m_ppcPredYuvBest[uiDepth];
    m_ppcPredYuvBest[uiDepth] = m_ppcPredYuvTemp[uiDepth];
    m_ppcPredYuvTemp[uiDepth] = pcYuv;

    // Change Reconstruction data
    pcYuv = m_ppcRecoYuvBest[uiDepth];
    m_ppcRecoYuvBest[uiDepth] = m_ppcRecoYuvTemp[uiDepth];
    m_ppcRecoYuvTemp[uiDepth] = pcYuv;

    pcYuv = NULL;
    pcCU  = NULL;

    // store temp best CI for next CU coding
    m_pppcRDSbacCoder[uiDepth][CI_TEMP_BEST]->store(m_pppcRDSbacCoder[uiDepth][CI_NEXT_BEST]);


#if DEBUG_STRING
    DEBUG_STRING_SWAP(sParent, sTest)
    const PredMode predMode=rpcBestCU->getPredictionMode(0);
    if ((DebugOptionList::DebugString_Structure.getInt()&DebugStringGetPredModeMask(predMode)) && bAddSizeInfo)
    {
      std::stringstream ss(stringstream::out);
      ss <<"###: " << (predMode==MODE_INTRA?"Intra   ":(predMode==MODE_INTER?"Inter   ":"IntraBC ")) << partSizeToString[rpcBestCU->getPartitionSize(0)] << " CU at " << rpcBestCU->getCUPelX() << ", " << rpcBestCU->getCUPelY() << " width=" << UInt(rpcBestCU->getWidth(0)) << std::endl;
      sParent+=ss.str();
    }
#endif
  }
}

Void TEncCu::xCheckDQP( TComDataCU* pcCU )
{
  UInt uiDepth = pcCU->getDepth( 0 );

  const TComPPS &pps = *(pcCU->getSlice()->getPPS());
  if ( pps.getUseDQP() && uiDepth <= pps.getMaxCuDQPDepth() )
  {
    if( pcCU->getQtRootCbf(0) || ( pcCU->getPLTModeFlag(0) && pcCU->getPLTEscape(COMPONENT_Y, 0) ) )
    {
      m_pcEntropyCoder->resetBits();
      m_pcEntropyCoder->encodeQP( pcCU, 0, false );
      pcCU->getTotalBits() += m_pcEntropyCoder->getNumberOfWrittenBits(); // dQP bits
      pcCU->getTotalBins() += ((TEncBinCABAC *)((TEncSbac*)m_pcEntropyCoder->m_pcEntropyCoderIf)->getEncBinIf())->getBinsCoded();
      pcCU->getTotalCost() = m_pcRdCost->calcRdCost( pcCU->getTotalBits(), pcCU->getTotalDistortion() );
    }
    else
    {
      pcCU->setQPSubParts( pcCU->getRefQP( 0 ), 0, uiDepth ); // set QP to default QP
    }
  }
}

Void TEncCu::xCopyAMVPInfo (AMVPInfo* pSrc, AMVPInfo* pDst)
{
  pDst->iN = pSrc->iN;
  for (Int i = 0; i < pSrc->iN; i++)
  {
    pDst->m_acMvCand[i] = pSrc->m_acMvCand[i];
  }
}
Void TEncCu::xCopyYuv2Pic(TComPic* rpcPic, UInt uiCUAddr, UInt uiAbsPartIdx, UInt uiDepth, UInt uiSrcDepth, TComDataCU* pcCU )
{
  UInt uiAbsPartIdxInRaster = g_auiZscanToRaster[uiAbsPartIdx];
  UInt uiSrcBlkWidth = rpcPic->getNumPartInCtuWidth() >> (uiSrcDepth);
  UInt uiBlkWidth    = rpcPic->getNumPartInCtuWidth() >> (uiDepth);
  UInt uiPartIdxX = ( ( uiAbsPartIdxInRaster % rpcPic->getNumPartInCtuWidth() ) % uiSrcBlkWidth) / uiBlkWidth;
  UInt uiPartIdxY = ( ( uiAbsPartIdxInRaster / rpcPic->getNumPartInCtuWidth() ) % uiSrcBlkWidth) / uiBlkWidth;
  UInt uiPartIdx = uiPartIdxY * ( uiSrcBlkWidth / uiBlkWidth ) + uiPartIdxX;
  m_ppcRecoYuvBest[uiSrcDepth]->copyToPicYuv( rpcPic->getPicYuvRec (), uiCUAddr, uiAbsPartIdx, uiDepth - uiSrcDepth, uiPartIdx);
  if( pcCU->getSlice()->getPPS()->getPpsScreenExtension().getUseColourTrans() && m_pcEncCfg->getRGBFormatFlag() )
  {
    TComRectangle cuCompRect;
    cuCompRect.x0     = 0;
    cuCompRect.y0     = 0;
    cuCompRect.width  = (pcCU->getSlice()->getSPS()->getMaxCUWidth()>>uiSrcDepth);
    cuCompRect.height = (pcCU->getSlice()->getSPS()->getMaxCUHeight()>>uiSrcDepth);

    for ( UInt ch = 0; ch < MAX_NUM_COMPONENT; ch++ )
    {
      m_ppcRecoYuvBest[uiSrcDepth]->copyPartToPartComponentMxN( ComponentID( ch ), m_ppcRecoYuvTemp[uiSrcDepth], cuCompRect );
    }
    m_ppcRecoYuvTemp[uiSrcDepth]->DefaultConvertPix( cuCompRect.x0, cuCompRect.y0, cuCompRect.width, pcCU->getSlice()->getSPS()->getBitDepths() );
    m_ppcRecoYuvTemp[uiSrcDepth]->copyToPicYuv( rpcPic->getPicYuvCSC(), uiCUAddr, uiAbsPartIdx, uiDepth - uiSrcDepth, uiPartIdx);
  }

  m_ppcPredYuvBest[uiSrcDepth]->copyToPicYuv( rpcPic->getPicYuvPred (), uiCUAddr, uiAbsPartIdx, uiDepth - uiSrcDepth, uiPartIdx);
}

Void TEncCu::xCopyYuv2Tmp( UInt uiPartUnitIdx, UInt uiNextDepth )
{
  UInt uiCurrDepth = uiNextDepth - 1;
  m_ppcRecoYuvBest[uiNextDepth]->copyToPartYuv( m_ppcRecoYuvTemp[uiCurrDepth], uiPartUnitIdx );
  m_ppcPredYuvBest[uiNextDepth]->copyToPartYuv( m_ppcPredYuvBest[uiCurrDepth], uiPartUnitIdx);
}

/** Function for filling the PCM buffer of a CU using its original sample array
 * \param pCU pointer to current CU
 * \param pOrgYuv pointer to original sample array
 */
Void TEncCu::xFillPCMBuffer     ( TComDataCU* pCU, TComYuv* pOrgYuv )
{
  const ChromaFormat format = pCU->getPic()->getChromaFormat();
  const UInt numberValidComponents = getNumberValidComponents(format);
  for (UInt componentIndex = 0; componentIndex < numberValidComponents; componentIndex++)
  {
    const ComponentID component = ComponentID(componentIndex);

    const UInt width  = pCU->getWidth(0)  >> getComponentScaleX(component, format);
    const UInt height = pCU->getHeight(0) >> getComponentScaleY(component, format);

    Pel *source      = pOrgYuv->getAddr(component, 0, width);
    Pel *destination = pCU->getPCMSample(component);

    const UInt sourceStride = pOrgYuv->getStride(component);

    for (Int line = 0; line < height; line++)
    {
      for (Int column = 0; column < width; column++)
      {
        destination[column] = source[column];
      }

      source      += sourceStride;
      destination += width;
    }
  }
}

#if ADAPTIVE_QP_SELECTION
/** Collect ARL statistics from one block
  */
Int TEncCu::xTuCollectARLStats(TCoeff* rpcCoeff, TCoeff* rpcArlCoeff, Int NumCoeffInCU, Double* cSum, UInt* numSamples )
{
  for( Int n = 0; n < NumCoeffInCU; n++ )
  {
    TCoeff u = abs( rpcCoeff[ n ] );
    TCoeff absc = rpcArlCoeff[ n ];

    if( u != 0 )
    {
      if( u < LEVEL_RANGE )
      {
        cSum[ u ] += ( Double )absc;
        numSamples[ u ]++;
      }
      else
      {
        cSum[ LEVEL_RANGE ] += ( Double )absc - ( Double )( u << ARL_C_PRECISION );
        numSamples[ LEVEL_RANGE ]++;
      }
    }
  }

  return 0;
}

//! Collect ARL statistics from one CTU
Void TEncCu::xCtuCollectARLStats(TComDataCU* pCtu )
{
  Double cSum[ LEVEL_RANGE + 1 ];     //: the sum of DCT coefficients corresponding to data type and quantization output
  UInt numSamples[ LEVEL_RANGE + 1 ]; //: the number of coefficients corresponding to data type and quantization output

  TCoeff* pCoeffY = pCtu->getCoeff(COMPONENT_Y);
  TCoeff* pArlCoeffY = pCtu->getArlCoeff(COMPONENT_Y);
  const TComSPS &sps = *(pCtu->getSlice()->getSPS());

  const UInt uiMinCUWidth = sps.getMaxCUWidth() >> sps.getMaxTotalCUDepth(); // NOTE: ed - this is not the minimum CU width. It is the square-root of the number of coefficients per part.
  const UInt uiMinNumCoeffInCU = 1 << uiMinCUWidth;                          // NOTE: ed - what is this?

  memset( cSum, 0, sizeof( Double )*(LEVEL_RANGE+1) );
  memset( numSamples, 0, sizeof( UInt )*(LEVEL_RANGE+1) );

  // Collect stats to cSum[][] and numSamples[][]
  for(Int i = 0; i < pCtu->getTotalNumPart(); i ++ )
  {
    UInt uiTrIdx = pCtu->getTransformIdx(i);

    if(pCtu->isInter(i) && pCtu->getCbf( i, COMPONENT_Y, uiTrIdx ) )
    {
      xTuCollectARLStats(pCoeffY, pArlCoeffY, uiMinNumCoeffInCU, cSum, numSamples);
    }//Note that only InterY is processed. QP rounding is based on InterY data only.

    pCoeffY  += uiMinNumCoeffInCU;
    pArlCoeffY  += uiMinNumCoeffInCU;
  }

  for(Int u=1; u<LEVEL_RANGE;u++)
  {
    m_pcTrQuant->getSliceSumC()[u] += cSum[ u ] ;
    m_pcTrQuant->getSliceNSamples()[u] += numSamples[ u ] ;
  }
  m_pcTrQuant->getSliceSumC()[LEVEL_RANGE] += cSum[ LEVEL_RANGE ] ;
  m_pcTrQuant->getSliceNSamples()[LEVEL_RANGE] += numSamples[ LEVEL_RANGE ] ;
}
#endif
//! \}
#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
void getDepthModeNeighbor(TComDataCU* pNeighbor, UInt uiNeighbor, UInt& uiDepth, UInt& uiMode, UInt idx, Double& dDepthWeight)
{
  if (pNeighbor != NULL)
  {
	uiDepth = pNeighbor->getDepth(uiNeighbor);
	uiMode = pNeighbor->getIntraDir(CHANNEL_TYPE_LUMA, uiNeighbor);
  }
  else
  {
	uiDepth = uiDepth;
	uiMode = 36;
	dDepthWeight = 0;
  }
  switch (idx)
  {
  case 0:
	if (uiMode == 26)
	{
	  dDepthWeight++;
	}
	break;
  case 1:
	if (uiMode == 10)
	{
	  dDepthWeight++;
	}
	break;
  case 2:
	if (uiMode == 18)
	{
	  dDepthWeight++;
	}
	break;
  case 3:
	if (uiMode == 2 || uiMode == 34)
	{
	  dDepthWeight++;
	}
	break;
  case 4:
	if (uiMode == 2 || uiMode == 34)
	{
	  dDepthWeight++;
	}
	break;
  default:
	printf("error when getDepthMode \n");
  }
}
#endif