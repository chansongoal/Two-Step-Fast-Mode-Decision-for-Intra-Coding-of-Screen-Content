/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TComRom.h
    \brief    global variables & functions (header)
*/

#ifndef __TCOMROM__
#define __TCOMROM__

#include "CommonDef.h"

#include<stdio.h>
#include<iostream>

//! \ingroup TLibCommon
//! \{

// ====================================================================================================================
#define MAX_PLT_SIZE                                     65
#define MAX_PRED_CHEK                                    4
#define MAX_PLT_ITER                                     2 // maximum number of plt derivation
// ====================================================================================================================
// Initialize / destroy functions
// ====================================================================================================================

Void         initROM();
Void         destroyROM();

// ====================================================================================================================
// Data structure related table & variable
// ====================================================================================================================

// flexible conversion from relative to absolute index
extern       UInt   g_auiZscanToRaster[ MAX_NUM_PART_IDXS_IN_CTU_WIDTH*MAX_NUM_PART_IDXS_IN_CTU_WIDTH ];
extern       UInt   g_auiRasterToZscan[ MAX_NUM_PART_IDXS_IN_CTU_WIDTH*MAX_NUM_PART_IDXS_IN_CTU_WIDTH ];
extern       UInt*  g_scanOrder[SCAN_NUMBER_OF_GROUP_TYPES][SCAN_NUMBER_OF_TYPES][ MAX_CU_DEPTH + 1 ][ MAX_CU_DEPTH + 1 ];

Void         initZscanToRaster ( Int iMaxDepth, Int iDepth, UInt uiStartVal, UInt*& rpuiCurrIdx );
Void         initRasterToZscan ( UInt uiMaxCUWidth, UInt uiMaxCUHeight, UInt uiMaxDepth         );

// conversion of partition index to picture pel position
extern       UInt   g_auiRasterToPelX[ MAX_NUM_PART_IDXS_IN_CTU_WIDTH*MAX_NUM_PART_IDXS_IN_CTU_WIDTH ];
extern       UInt   g_auiRasterToPelY[ MAX_NUM_PART_IDXS_IN_CTU_WIDTH*MAX_NUM_PART_IDXS_IN_CTU_WIDTH ];

Void         initRasterToPelXY ( UInt uiMaxCUWidth, UInt uiMaxCUHeight, UInt uiMaxDepth );

extern const UInt g_auiPUOffset[NUMBER_OF_PART_SIZES];

extern const Int g_quantScales[SCALING_LIST_REM_NUM];             // Q(QP%6)
extern const Int g_invQuantScales[SCALING_LIST_REM_NUM];          // IQ(QP%6)

#if RExt__HIGH_PRECISION_FORWARD_TRANSFORM
static const Int g_transformMatrixShift[TRANSFORM_NUMBER_OF_DIRECTIONS] = { 14, 6 };
#else
static const Int g_transformMatrixShift[TRANSFORM_NUMBER_OF_DIRECTIONS] = {  6, 6 };
#endif

extern const TMatrixCoeff g_aiT4 [TRANSFORM_NUMBER_OF_DIRECTIONS][4][4];
extern const TMatrixCoeff g_aiT8 [TRANSFORM_NUMBER_OF_DIRECTIONS][8][8];
extern const TMatrixCoeff g_aiT16[TRANSFORM_NUMBER_OF_DIRECTIONS][16][16];
extern const TMatrixCoeff g_aiT32[TRANSFORM_NUMBER_OF_DIRECTIONS][32][32];

// ====================================================================================================================
// Luma QP to Chroma QP mapping
// ====================================================================================================================

static const Int chromaQPMappingTableSize = 58;

extern const UChar  g_aucChromaScale[NUM_CHROMA_FORMAT][chromaQPMappingTableSize];


// ====================================================================================================================
// Scanning order & context mapping table
// ====================================================================================================================

extern const UInt   ctxIndMap4x4[4*4];

extern const UInt   g_uiGroupIdx[ MAX_TU_SIZE ];
extern const UInt   g_uiMinInGroup[ LAST_SIGNIFICANT_GROUPS ];

// ====================================================================================================================
// Intra prediction table
// ====================================================================================================================

extern const UChar  g_aucIntraModeNumFast_UseMPM[MAX_CU_DEPTH];
extern const UChar  g_aucIntraModeNumFast_NotUseMPM[MAX_CU_DEPTH];

extern const UChar  g_chroma422IntraAngleMappingTable[NUM_INTRA_MODE];

// ====================================================================================================================

extern        UChar g_uhPLTQuant[52];
extern        UChar g_uhPLTTBC[257];


// Mode-Dependent DST Matrices
// ====================================================================================================================

extern const TMatrixCoeff g_as_DST_MAT_4 [TRANSFORM_NUMBER_OF_DIRECTIONS][4][4];

// ====================================================================================================================
// Misc.
// ====================================================================================================================

extern       SChar   g_aucConvertToBit  [ MAX_CU_SIZE+1 ];   // from width to log2(width)-2


#if ENC_DEC_TRACE
extern FILE*  g_hTrace;
extern Bool   g_bJustDoIt;
extern const Bool g_bEncDecTraceEnable;
extern const Bool g_bEncDecTraceDisable;
extern Bool   g_HLSTraceEnable;
extern UInt64 g_nSymbolCounter;

#define COUNTER_START    1
#define COUNTER_END      0 //( UInt64(1) << 63 )

#define DTRACE_CABAC_F(x)     if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "%f", x );
#define DTRACE_CABAC_V(x)     if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "%d", x );
#define DTRACE_CABAC_VL(x)    if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "%lld", x );
#define DTRACE_CABAC_T(x)     if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "%s", x );
#define DTRACE_CABAC_X(x)     if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "%x", x );
#define DTRACE_CABAC_R( x,y ) if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, x,    y );
#define DTRACE_CABAC_N        if ( ( g_nSymbolCounter >= COUNTER_START && g_nSymbolCounter <= COUNTER_END )|| g_bJustDoIt ) fprintf( g_hTrace, "\n"    );

#else

#define DTRACE_CABAC_F(x)
#define DTRACE_CABAC_V(x)
#define DTRACE_CABAC_VL(x)
#define DTRACE_CABAC_T(x)
#define DTRACE_CABAC_X(x)
#define DTRACE_CABAC_R( x,y )
#define DTRACE_CABAC_N

#endif

const TChar* nalUnitTypeToString(NalUnitType type);

extern const TChar *MatrixType[SCALING_LIST_SIZE_NUM][SCALING_LIST_NUM];
extern const TChar *MatrixType_DC[SCALING_LIST_SIZE_NUM][SCALING_LIST_NUM];

extern const Int g_quantTSDefault4x4[4*4];
extern const Int g_quantIntraDefault8x8[8*8];
extern const Int g_quantInterDefault8x8[8*8];

extern const UInt g_scalingListSize [SCALING_LIST_SIZE_NUM];
extern const UInt g_scalingListSizeX[SCALING_LIST_SIZE_NUM];

#define SCM__S0269_PLT_RUN_MSB_IDX_CABAC_BYPASS_THRE              4       ///< CABAC bypass threshold
#define SCM__S0269_PLT_RUN_MSB_IDX_CTX_T1                         1
#define SCM__S0269_PLT_RUN_MSB_IDX_CTX_T2                         3
extern UChar g_ucRunTopLut[5];
extern UChar g_ucRunLeftLut[5];
extern UChar g_ucMsbP1Idx[256];
extern UChar g_getMsbP1Idx(UInt uiVal);
//! \}

#if ADAPTIVE_WEIGHTED_EARLY_TERMINATION
extern Double th1;
extern Double th2;
extern Double th3;
extern UChar min1;
extern UChar max1;
extern UChar min2;
extern UChar max2;
extern UChar min3;
extern UChar max3;
extern UChar min4;
extern UChar max4;
extern Bool bEnableAWET;
#endif

#if SUPPLEMENT_FOR_NATURE
extern Bool bEnableSupplementForNature;
#endif

#if GLOBAL_INFOMATION
extern std::string g_inputFileName;
extern UInt g_uiFrameToBeEncoded;
extern UInt g_uiNumBasicInPicWidth;
extern UInt g_uiNumBasicInPicHeight;
extern Int g_uiFrameIdx;
extern UInt g_uiBasicSize;
extern std::string ***CNNResult;
#endif

#if ARGV_TH
extern Double dAlpha;
extern Double dBeta;
extern Double dFactorNature;
extern Double dFactorNontext;
extern Double dSadDepth0;
extern Double dSadDepth1;
extern Double dSadDepth2;
#endif

#if OUTPUT_MODE_DEPTH_ENCODER
extern UInt uiModeOptimalIntra[5];
extern UInt uiModeOptimalIntraCSC[5];
extern UInt uiModeOptimalMerge[5];
extern UInt uiModeOptimalMergeCSC[5];
extern UInt uiModeOptimalSkip[5];
extern UInt uiModeOptimalSkipCSC[5];
extern UInt uiModeOptimalNormalIBC[5];
extern UInt uiModeOptimalNormalIBCCSC[5];
extern UInt uiModeOptimalAsyIBC[5];
extern UInt uiModeOptimalAsyIBCCSC[5];
extern UInt uiModeOptimalPLT[5];
extern UInt uiModeOptimalPLTCSC[5];
#endif

#if TIME_MODE_DEPTH
extern long lTimeMerge[5];
extern long lTimeSkip[5];
extern long lTimeFastIBC[5];
extern long lTimeNormalIBC[5];
extern long lTimeAsyIBC[5];
extern long lTimeIBCMix[5];
extern long lTimePLT[5];
extern long lTimeIntraF[5];
extern long lTimeIntraCSCF[5];
extern long lTimeIntraM[5];
extern long lTimeIntraCSCM[5];

extern UInt uiCheckMerge[5];
extern UInt uiCheckMergeCand[5];
extern UInt uiCheckSkipCand[5];
extern UInt uiCheckFastIBC[5];
extern UInt uiCheckNormalIBC[5];
extern UInt uiCheckAsyIBC[5];
extern UInt uiCheckIBCMix[5];
extern UInt uiCheckPLT[5];
extern UInt uiCheckIntraF[5];
extern UInt uiCheckIntraCSCF[5];
extern UInt uiCheckIntraM[5];
extern UInt uiCheckIntraCSCM[5];
#endif

#if TIME_CHECKED_CONTENT_DEPTH_MODE_IN_COMPRESSCU
extern long lTimeContentDepthMode[5][4][4];
extern UInt uiCheckedContentDepthMode[5][4][4];
#endif

#if TYPE_DEPTH_MODE
extern UInt uiContentDepthMode[5][4][7];
#endif
#if ACCURACY_CONTENT_DEPTH_MODE
extern UInt uiContentDepthModeTotal[5][4][4];
extern UInt uiContentDepthModeCorrect[5][4][4];
extern UInt uiContentDepthModeCorrectCNN[5][4][4];
#endif
#if TP_FP_FN_TN
extern UInt uiIntraDepthTPFPFNTN[4][8];
extern UInt uiMergeDepthTPFPFNTN[4][8];
extern UInt uiIBCDepthTPFPFNTN[4][8];
extern UInt uiPLTDepthTPFPFNTN[4][8];
#endif
#if EXPLANATIONS_OF_SPATIAL_PREDICTION
extern UInt uiIntraInCurrAndNeighContentDepth[5][4]; //the mode in current CU is Intra and there is at least one mode in neighboring CUs
extern UInt uiIntraInCurrContentDepth[5][4]; //the mode in current CU is Intra
extern UInt uiIntraInNeighContentDepth[5][4];	//there is at least one mode in neighboring CUs
extern UInt uiSCCInCurrAndNeighContentDepth[5][4];
extern UInt uiSCCInCurrContentDepth[5][4];
extern UInt uiSCCInNeighContentDepth[5][4];
#endif
#endif  //__TCOMROM__

