/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     encmain.cpp
    \brief    Encoder application main
*/

#include <time.h>
#include <iostream>
#include "TAppEncTop.h"
#include "TAppCommon/program_options_lite.h"

//! \ingroup TAppEncoder
//! \{

#include "../Lib/TLibCommon/Debug.h"
#if TYPE_DEPTH_MODE
Void print_info_type_depth_mode();
#endif
#if ACCURACY_CONTENT_DEPTH_MODE
Void print_info_type_depth_mode_accuracy_cnn();
#endif
#if TP_FP_FN_TN
Void print_info_depth_mode_TP_FP_FN_TN();
#endif
#if TIME_CHECKED_CONTENT_DEPTH_MODE_IN_COMPRESSCU
Void print_info_time_mode_content_depth();
#endif
#if EXPLANATIONS_OF_SPATIAL_PREDICTION
Void print_info_spatial_prediction();
#endif
#if TIME_MODE_DEPTH
Void print_info_time_mode_depth(Double dResult);
#endif
// ====================================================================================================================
// Main function
// ====================================================================================================================

int main(int argc, char* argv[])
{
  TAppEncTop  cTAppEncTop;

  // print information
  fprintf( stdout, "\n" );
  fprintf( stdout, "HM software: Encoder Version [%s] (including RExt)", NV_VERSION );
  fprintf( stdout, NVM_ONOS );
  fprintf( stdout, NVM_COMPILEDBY );
  fprintf( stdout, NVM_BITS );
  fprintf( stdout, "\n\n" );

  // create application encoder class
  cTAppEncTop.create();

  // parse configuration
  try
  {
    if(!cTAppEncTop.parseCfg( argc, argv ))
    {
      cTAppEncTop.destroy();
#if ENVIRONMENT_VARIABLE_DEBUG_AND_TEST
      EnvVar::printEnvVar();
#endif
      return 1;
    }
  }
  catch (df::program_options_lite::ParseFailure &e)
  {
    std::cerr << "Error parsing option \""<< e.arg <<"\" with argument \""<< e.val <<"\"." << std::endl;
    return 1;
  }
#if ARGV_TH
  dAlpha = atof(argv[argc - 7]);
  dBeta = atof(argv[argc - 6]);
  dFactorNature = atof(argv[argc - 5]);
  dFactorNontext = atof(argv[argc - 4]);
  dSadDepth0 = atof(argv[argc - 3]);
  dSadDepth1 = atof(argv[argc - 2]);
  dSadDepth2 = atof(argv[argc - 1]);
  printf("value: %f %f %f %f %f %f %f\n", dAlpha, dBeta, dFactorNature, dFactorNontext, dSadDepth0, dSadDepth1, dSadDepth2);
#endif
 #if LBCFMD 
  cTAppEncTop.parseCNN();
#endif

#if PRINT_MACRO_VALUES
  printMacroSettings();
#endif

#if ENVIRONMENT_VARIABLE_DEBUG_AND_TEST
  EnvVar::printEnvVarInUse();
#endif

  // starting time
  Double dResult;
  clock_t lBefore = clock();

  // call encoding function
  cTAppEncTop.encode();

  // ending time
  dResult = (Double)(clock()-lBefore) / CLOCKS_PER_SEC;
  printf("\n Total Time: %12.3f sec.\n", dResult);
#if TP_FP_FN_TN
  print_info_depth_mode_TP_FP_FN_TN();
#endif
#if TYPE_DEPTH_MODE
  printf("\nprint infor type depth mode: \n");
  print_info_type_depth_mode();
#endif
#if ACCURACY_CONTENT_DEPTH_MODE
  printf("print infor accuracy content depth mode: \n");
  print_info_type_depth_mode_accuracy_cnn();
#endif
#if TIME_CHECKED_CONTENT_DEPTH_MODE_IN_COMPRESSCU
  printf("print infor time checked content depth mode: \n");
  print_info_time_mode_content_depth();
#endif
#if EXPLANATIONS_OF_SPATIAL_PREDICTION
  printf("print infor explanations of spatial prediction: \n");
  print_info_spatial_prediction();
#endif

#if TIME_MODE_DEPTH
  printf("print infor time mode depth: \n");
  print_info_time_mode_depth(dResult);
#endif
#if LBCFMD
  for (int k = 0; k < g_uiFrameToBeEncoded; ++k)
  {
	for (int i = 0; i < g_uiNumBasicInPicHeight; i++)
	  { 
		  delete[] CNNResult[k][i];
	  }
	  delete[] CNNResult[k];
  }
  delete[] CNNResult;
#endif

  // destroy application encoder class
  cTAppEncTop.destroy();

  return 0;
}

#if TYPE_DEPTH_MODE
Void print_info_type_depth_mode()
{
  UInt uiNumContent = 5;
  UInt uiNumDepth = 4;
  UInt uiNumMode = 7;
  for (UInt uiContent = 0; uiContent < uiNumContent; uiContent++)
  {
	for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
	{
	  UInt uiTotalMode = 0;
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		uiTotalMode += uiContentDepthMode[uiContent][uiDepth][uiMode];
	  }
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		printf("%d ", uiContentDepthMode[uiContent][uiDepth][uiMode]);
	  }
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		if (uiContentDepthMode[uiContent][uiDepth][uiMode] == 0)
		  printf("%12.5f ", 0);
		else
		  printf("%12.5f ", (float)uiContentDepthMode[uiContent][uiDepth][uiMode] / uiTotalMode);
	  }
	  printf("\n");
	}
  }
  printf("\n");
}
#endif
#if ACCURACY_CONTENT_DEPTH_MODE
Void print_info_type_depth_mode_accuracy_cnn()
{
  UInt uiNumContent = 5;
  UInt uiNumDepth = 4;
  UInt uiNumMode = 4;
  for (UInt uiContent = 0; uiContent < uiNumContent; uiContent++)
  {
	for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
	{
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		printf("%d ", uiContentDepthModeTotal[uiContent][uiDepth][uiMode]);
	  }
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		printf("%d ", uiContentDepthModeCorrect[uiContent][uiDepth][uiMode]);
	  }
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		printf("%d ", uiContentDepthModeCorrectCNN[uiContent][uiDepth][uiMode]);
	  }

	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		if (uiContentDepthModeTotal[uiContent][uiDepth][uiMode] == 0)
		  printf("%12.5f ", 1.0);
		else
		  printf("%12.5f ", (float)uiContentDepthModeCorrect[uiContent][uiDepth][uiMode] / uiContentDepthModeTotal[uiContent][uiDepth][uiMode]);
	  }
	  for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
	  {
		if (uiContentDepthModeTotal[uiContent][uiDepth][uiMode] == 0)
		  printf("%12.5f ", 1.0);
		else
		  printf("%12.5f ", (float)uiContentDepthModeCorrectCNN[uiContent][uiDepth][uiMode] / uiContentDepthModeTotal[uiContent][uiDepth][uiMode]);
	  }
	  printf("\n");
	}
  }
  printf("\n");
}
#endif

#if TP_FP_FN_TN
Void print_info_depth_mode_TP_FP_FN_TN()
{
  UInt uiNumMode = 4;
  UInt uiNumMode2 = 4 * 2;
  UInt uiNumDepth = 4;
  //Intra mode
  for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
  {
	for (UInt uiMode = 0; uiMode < uiNumMode2; uiMode++)
	{
	  printf("%d ", uiIntraDepthTPFPFNTN[uiDepth][uiMode]);
	}
	printf("\n");
  }
  //Merge mode
  for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
  {
	for (UInt uiMode = 0; uiMode < uiNumMode2; uiMode++)
	{
	  printf("%d ", uiMergeDepthTPFPFNTN[uiDepth][uiMode]);
	}
	printf("\n");
  }
  //IBC mode
  for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
  {
	for (UInt uiMode = 0; uiMode < uiNumMode2; uiMode++)
	{
	  printf("%d ", uiIBCDepthTPFPFNTN[uiDepth][uiMode]);
	}
	printf("\n");
  }
  //PLT mode
  for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
  {
	for (UInt uiMode = 0; uiMode < uiNumMode2; uiMode++)
	{
	  printf("%d ", uiPLTDepthTPFPFNTN[uiDepth][uiMode]);
	}
	printf("\n");
  }
}
#endif

#if TIME_CHECKED_CONTENT_DEPTH_MODE_IN_COMPRESSCU
Void print_info_time_mode_content_depth()
{
	UInt uiNumContent = 5;
	UInt uiNumDepth = 4;
	UInt uiNumMode = 4;
	for (UInt uiContent = 0; uiContent < uiNumContent; uiContent++)
	{
		for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
		{
			//print time
			for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
			{
				printf("%12.3f ", (Double)lTimeContentDepthMode[uiContent][uiDepth][uiMode] / CLOCKS_PER_SEC);
			}
			//print checked times
			for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
			{
				printf("%12d ", uiCheckedContentDepthMode[uiContent][uiDepth][uiMode]);
			}
			//print complexity
			for (UInt uiMode = 0; uiMode < uiNumMode; uiMode++)
			{
				if (uiCheckedContentDepthMode[uiContent][uiDepth][uiMode] == 0)
					printf("%12.5f ", 0);
				else
					printf("%12.5f ", (Double)lTimeContentDepthMode[uiContent][uiDepth][uiMode] / (Double)uiCheckedContentDepthMode[uiContent][uiDepth][uiMode]);
			}
			printf("\n");
		}
	}
	printf("\n");
}
#endif

#if EXPLANATIONS_OF_SPATIAL_PREDICTION
Void print_info_spatial_prediction()
{
  UInt uiNumContent = 5;  //exclude mixed type
  UInt uiNumDepth = 4;

  for (UInt uiContent = 0; uiContent < uiNumContent; uiContent++)
  {
	for (UInt uiDepth = 0; uiDepth < uiNumDepth; uiDepth++)
	{
	  printf("%d %d %d %d %d %d\n", uiIntraInCurrContentDepth[uiContent][uiDepth], uiIntraInNeighContentDepth[uiContent][uiDepth], \
		uiIntraInCurrAndNeighContentDepth[uiContent][uiDepth],uiSCCInCurrContentDepth[uiContent][uiDepth], \
		uiSCCInNeighContentDepth[uiContent][uiDepth],uiSCCInCurrAndNeighContentDepth[uiContent][uiDepth]); 
	}
  }
  printf("\n");
}
#endif

#if TIME_MODE_DEPTH
Void print_info_time_mode_depth(Double dResult)
{
  printf("IntraF Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeIntraF[0] / CLOCKS_PER_SEC, (Double)lTimeIntraF[1] / CLOCKS_PER_SEC, (Double)lTimeIntraF[2] / CLOCKS_PER_SEC, (Double)lTimeIntraF[3] / CLOCKS_PER_SEC, (Double)lTimeIntraF[4] / CLOCKS_PER_SEC, (Double)lTimeIntraF[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("IntraCSCF Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeIntraCSCF[0] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCF[1] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCF[2] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCF[3] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCF[4] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCF[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("IntraM Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeIntraM[0] / CLOCKS_PER_SEC, (Double)lTimeIntraM[1] / CLOCKS_PER_SEC, (Double)lTimeIntraM[2] / CLOCKS_PER_SEC, (Double)lTimeIntraM[3] / CLOCKS_PER_SEC, (Double)lTimeIntraM[4] / CLOCKS_PER_SEC, (Double)lTimeIntraM[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("IntraCSCM Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeIntraCSCM[0] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCM[1] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCM[2] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCM[3] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCM[4] / CLOCKS_PER_SEC, (Double)lTimeIntraCSCM[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("Merge Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeMerge[0] / CLOCKS_PER_SEC, (Double)lTimeMerge[1] / CLOCKS_PER_SEC, (Double)lTimeMerge[2] / CLOCKS_PER_SEC, (Double)lTimeMerge[3] / CLOCKS_PER_SEC, (Double)lTimeMerge[4] / CLOCKS_PER_SEC, (Double)lTimeMerge[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("Skip Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeSkip[0] / CLOCKS_PER_SEC, (Double)lTimeSkip[1] / CLOCKS_PER_SEC, (Double)lTimeSkip[2] / CLOCKS_PER_SEC, (Double)lTimeSkip[3] / CLOCKS_PER_SEC, (Double)lTimeSkip[4] / CLOCKS_PER_SEC, (Double)lTimeSkip[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("FastIBC Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeFastIBC[0] / CLOCKS_PER_SEC, (Double)lTimeFastIBC[1] / CLOCKS_PER_SEC, (Double)lTimeFastIBC[2] / CLOCKS_PER_SEC, (Double)lTimeFastIBC[3] / CLOCKS_PER_SEC, (Double)lTimeFastIBC[4] / CLOCKS_PER_SEC, (Double)lTimeFastIBC[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("NormalIBC Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeNormalIBC[0] / CLOCKS_PER_SEC, (Double)lTimeNormalIBC[1] / CLOCKS_PER_SEC, (Double)lTimeNormalIBC[2] / CLOCKS_PER_SEC, (Double)lTimeNormalIBC[3] / CLOCKS_PER_SEC, (Double)lTimeNormalIBC[4] / CLOCKS_PER_SEC, (Double)lTimeNormalIBC[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("AsyIBC Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeAsyIBC[0] / CLOCKS_PER_SEC, (Double)lTimeAsyIBC[1] / CLOCKS_PER_SEC, (Double)lTimeAsyIBC[2] / CLOCKS_PER_SEC, (Double)lTimeAsyIBC[3] / CLOCKS_PER_SEC, (Double)lTimeAsyIBC[4] / CLOCKS_PER_SEC, (Double)lTimeAsyIBC[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("PLT Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimePLT[0] / CLOCKS_PER_SEC, (Double)lTimePLT[1] / CLOCKS_PER_SEC, (Double)lTimePLT[2] / CLOCKS_PER_SEC, (Double)lTimePLT[3] / CLOCKS_PER_SEC, (Double)lTimePLT[4] / CLOCKS_PER_SEC, (Double)lTimePLT[4] / CLOCKS_PER_SEC / dResult * 100);
  printf("IBCMix Time: %12.3f %12.3f %12.3f %12.3f %12.3f %12.3f percent. \n", (Double)lTimeIBCMix[0] / CLOCKS_PER_SEC, (Double)lTimeIBCMix[1] / CLOCKS_PER_SEC, (Double)lTimeIBCMix[2] / CLOCKS_PER_SEC, (Double)lTimeIBCMix[3] / CLOCKS_PER_SEC, (Double)lTimeIBCMix[4] / CLOCKS_PER_SEC, (Double)lTimeIBCMix[4] / CLOCKS_PER_SEC / dResult * 100);

  printf("IntraF Checked: %d %d %d %d %d times. \n", uiCheckIntraF[0], uiCheckIntraF[1], uiCheckIntraF[2], uiCheckIntraF[3], uiCheckIntraF[4]);
  printf("IntraCSCF Checked: %d %d %d %d %d times. \n", uiCheckIntraCSCF[0], uiCheckIntraCSCF[1], uiCheckIntraCSCF[2], uiCheckIntraCSCF[3], uiCheckIntraCSCF[4]);
  printf("IntraM Checked: %d %d %d %d %d times. \n", uiCheckIntraM[0], uiCheckIntraM[1], uiCheckIntraM[2], uiCheckIntraM[3], uiCheckIntraM[4]);
  printf("IntraCSCM Checked: %d %d %d %d %d times. \n", uiCheckIntraCSCM[0], uiCheckIntraCSCM[1], uiCheckIntraCSCM[2], uiCheckIntraCSCM[3], uiCheckIntraCSCM[4]);
  printf("Merge Checked: %d %d %d %d %d times. \n", uiCheckMerge[0], uiCheckMerge[1], uiCheckMerge[2], uiCheckMerge[3], uiCheckMerge[4]);
  printf("MergeCand Checked: %d %d %d %d %d times. \n", uiCheckMergeCand[0], uiCheckMergeCand[1], uiCheckMergeCand[2], uiCheckMergeCand[3], uiCheckMergeCand[4]);
  printf("SkipCand Checked: %d %d %d %d %d times. \n", uiCheckSkipCand[0], uiCheckSkipCand[1], uiCheckSkipCand[2], uiCheckSkipCand[3], uiCheckSkipCand[4]);
  printf("FastIBC Checked: %d %d %d %d %d times. \n", uiCheckFastIBC[0], uiCheckFastIBC[1], uiCheckFastIBC[2], uiCheckFastIBC[3], uiCheckFastIBC[4]);
  printf("NormalIBC Checked: %d %d %d %d %d times. \n", uiCheckNormalIBC[0], uiCheckNormalIBC[1], uiCheckNormalIBC[2], uiCheckNormalIBC[3], uiCheckNormalIBC[4]);
  printf("AsyIBC Checked: %d %d %d %d %d times. \n", uiCheckAsyIBC[0], uiCheckAsyIBC[1], uiCheckAsyIBC[2], uiCheckAsyIBC[3], uiCheckAsyIBC[4]);
  printf("PLT Checked: %d %d %d %d %d times. \n", uiCheckPLT[0], uiCheckPLT[1], uiCheckPLT[2], uiCheckPLT[3], uiCheckPLT[4]);
  printf("IBCMix Checked: %d %d %d %d %d times. \n", uiCheckIBCMix[0], uiCheckIBCMix[1], uiCheckIBCMix[2], uiCheckIBCMix[3], uiCheckIBCMix[4]);
}
#endif
//! \}
