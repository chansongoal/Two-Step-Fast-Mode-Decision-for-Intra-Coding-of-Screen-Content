/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     encmain.cpp
    \brief    Encoder application main
*/

#include <time.h>
#include <iostream>
#include "TAppEncTop.h"
#include "TAppCommon/program_options_lite.h"

//! \ingroup TAppEncoder
//! \{

#include "../Lib/TLibCommon/Debug.h"

// ====================================================================================================================
// Main function
// ====================================================================================================================

int main(int argc, char* argv[])
{
  TAppEncTop  cTAppEncTop;

  // print information
  fprintf( stdout, "\n" );
  fprintf( stdout, "HM software: Encoder Version [%s] (including RExt)", NV_VERSION );
  fprintf( stdout, NVM_ONOS );
  fprintf( stdout, NVM_COMPILEDBY );
  fprintf( stdout, NVM_BITS );
  fprintf( stdout, "\n\n" );

  // create application encoder class
  cTAppEncTop.create();

  // parse configuration
  try
  {
    if(!cTAppEncTop.parseCfg( argc, argv ))
    {
      cTAppEncTop.destroy();
#if ENVIRONMENT_VARIABLE_DEBUG_AND_TEST
      EnvVar::printEnvVar();
#endif
      return 1;
    }
  }
  catch (df::program_options_lite::ParseFailure &e)
  {
    std::cerr << "Error parsing option \""<< e.arg <<"\" with argument \""<< e.val <<"\"." << std::endl;
    return 1;
  }
#if ONLY_CBC_EARLY_TERMINATION || EARLY_TERMINATION_CBC
  dThNature = atof(argv[argc - 2]);
  dThNonText = atof(argv[argc - 1]);
  //printf("value: %f %f\n", dThNature, dThNonText);
#endif
 #if LBCFMD 
  Int framecounts = 0;
  Int row = 0;
  cTAppEncTop.parseCNN(argc, argv, &framecounts, &row);
  cTAppEncTop.parseStep2CNN(argc, argv, &framecounts, &row);
#endif

#if INTRA_MODE_FLAG		//call parseCNN  
  cTAppEncTop.parseIntraFlag(argc, argv, &framecounts, &row64, &Column64, 0);	flag64 = true;		//for 64*64
  cTAppEncTop.parseIntraFlag(argc, argv, &framecounts, &row32, &Column32, 1);	flag32 = true;		//for 32*32
  cTAppEncTop.parseIntraFlag(argc, argv, &framecounts, &row16, &Column16, 2);	flag16 = true;		//for 16*16
  cTAppEncTop.parseIntraFlag(argc, argv, &framecounts, &row8, &Column8, 3);		flag8 = true;		//for 8*8
  cTAppEncTop.parseIntraFlag(argc, argv, &framecounts, &row4, &Column4, 4);		flag4 = true;		//for 8*8
#endif
#if PRINT_MACRO_VALUES
  printMacroSettings();
#endif

#if ENVIRONMENT_VARIABLE_DEBUG_AND_TEST
  EnvVar::printEnvVarInUse();
#endif

  // starting time
  Double dResult;
  clock_t lBefore = clock();

  // call encoding function
  cTAppEncTop.encode();

  // ending time
  dResult = (Double)(clock()-lBefore) / CLOCKS_PER_SEC;
  printf("\n Total Time: %12.3f sec.\n", dResult);

#if LBCFMD
    for (int k = 0; k < framecounts; ++k)
  {
	  for (int i = 0; i < row; i++)
	  { 
		  delete[] CNNResult[k][i];
	  }
	  delete[] CNNResult[k];
  }
  delete[] CNNResult;

  for (int k = 0; k < framecounts; ++k)
  {
	  for (int i = 0; i < row; i++)
	  {
		  delete[] CNNStep2Result[k][i];
	  }
	  delete[] CNNStep2Result[k];
  }
  delete[] CNNStep2Result;
#endif

#if INTRA_MODE_FLAG		//delete CNNResults
  if (flag64 == true)
  {
	  for (int k = 0; k < framecounts; ++k)
	  {
		  for (int i = 0; i < row64; i++)
		  {
			  delete[] IntraFlag64[k][i];
		  }
		  delete[] IntraFlag64[k];
	  }
	  delete[] IntraFlag64;
  }

  if (flag32 == true)
  {
	  for (int k = 0; k < framecounts; ++k)
	  {
		  for (int i = 0; i < row32; i++)
		  {
			  delete[] IntraFlag32[k][i];
		  }
		  delete[] IntraFlag32[k];
	  }
	  delete[] IntraFlag32;
  }

  if (flag16 == true)
  {
	  for (int k = 0; k < framecounts; ++k)
	  {
		  for (int i = 0; i < row16; i++)
		  {
			  delete[] IntraFlag16[k][i];
		  }
		  delete[] IntraFlag16[k];
	  }
	  delete[] IntraFlag16;
  }

  if (flag8 == true)
  {
	  for (int k = 0; k < framecounts; ++k)
	  {
		  for (int i = 0; i < row8; i++)
		  {
			  delete[] IntraFlag8[k][i];
		  }
		  delete[] IntraFlag8[k];
	  }
	  delete[] IntraFlag8;
  }

  if (flag4 == true)
  {
	  for (int k = 0; k < framecounts; ++k)
	  {
		  for (int i = 0; i < row4; i++)
		  {
			  delete[] IntraFlag4[k][i];
		  }
		  delete[] IntraFlag4[k];
	  }
	  delete[] IntraFlag4;
  }
#endif

#if MODE_CHECKED_ENCODER
  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiModeCheckedIntra[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiModeCheckedIBC[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiModeCheckedSkip[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiModeCheckedPLT[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiTimeCheckedIntra[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiTimeCheckedIBC[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiTimeCheckedSkip[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiTimeCheckedPLT[m][n]);
	}
	printf("\n");
  }

  for (UInt m = 0; m < 4; ++m)
  {
	for (UInt n = 0; n < 5; ++n)
	{
	  printf("%d ", uiDepthSkipped[m][n]);
	}
	printf("\n");
  }
#endif
  // destroy application encoder class
  cTAppEncTop.destroy();

  return 0;
}

//! \}
