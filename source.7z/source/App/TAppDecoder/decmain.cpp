/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     decmain.cpp
    \brief    Decoder application main
*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "TAppDecTop.h"

//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Main function
// ====================================================================================================================

int main(int argc, char* argv[])
{
  Int returnCode = EXIT_SUCCESS;
  TAppDecTop  cTAppDecTop;

  // print information
  fprintf( stdout, "\n" );
  fprintf( stdout, "HM software: Decoder Version [%s] (including RExt)", NV_VERSION );
  fprintf( stdout, NVM_ONOS );
  fprintf( stdout, NVM_COMPILEDBY );
  fprintf( stdout, NVM_BITS );
  fprintf( stdout, "\n" );

  // create application decoder class
  cTAppDecTop.create();

  // parse configuration
  if(!cTAppDecTop.parseCfg( argc, argv ))
  {
    cTAppDecTop.destroy();
    returnCode = EXIT_FAILURE;
    return returnCode;
  }

#if CU_CONTENT_TYPE_DECODER 
  Int framecounts = 0;
  Int row = 0;
  cTAppDecTop.parseCNN(argc, argv, &framecounts, &row);
  cTAppDecTop.parseStep2CNN(argc, argv, &framecounts, &row);
#endif

  // starting time
  Double dResult;
  clock_t lBefore = clock();

  // call decoding function
  cTAppDecTop.decode();

  if (cTAppDecTop.getNumberOfChecksumErrorsDetected() != 0)
  {
    printf("\n\n***ERROR*** A decoding mismatch occured: signalled md5sum does not match\n");
    returnCode = EXIT_FAILURE;
  }

  // ending time
  dResult = (Double)(clock()-lBefore) / CLOCKS_PER_SEC;
  printf("\n Total Time: %12.3f sec.\n", dResult);

  printf("\n Intra Optimal: %d %d %d %d %d times.", uiModeOptimalIntra[0], uiModeOptimalIntra[1], uiModeOptimalIntra[2], uiModeOptimalIntra[3], uiModeOptimalIntra[4]);
  printf("\n IntraCSC Optimal: %d %d %d %d %d times.", uiModeOptimalIntraCSC[0], uiModeOptimalIntraCSC[1], uiModeOptimalIntraCSC[2], uiModeOptimalIntraCSC[3], uiModeOptimalIntraCSC[4]);
  printf("\n Merge Optimal: %d %d %d %d %d times.", uiModeOptimalMerge[0], uiModeOptimalMerge[1], uiModeOptimalMerge[2], uiModeOptimalMerge[3], uiModeOptimalMerge[4]);
  printf("\n Skip Optimal: %d %d %d %d %d times.", uiModeOptimalSkip[0], uiModeOptimalSkip[1], uiModeOptimalSkip[2], uiModeOptimalSkip[3], uiModeOptimalSkip[4]);
  printf("\n NormalIBC Optimal: %d %d %d %d %d times.", uiModeOptimalNormalIBC[0], uiModeOptimalNormalIBC[1], uiModeOptimalNormalIBC[2], uiModeOptimalNormalIBC[3], uiModeOptimalNormalIBC[4]);
  printf("\n AsyIBC Optimal: %d %d %d %d %d times.", uiModeOptimalAsyIBC[0], uiModeOptimalAsyIBC[1], uiModeOptimalAsyIBC[2], uiModeOptimalAsyIBC[3], uiModeOptimalAsyIBC[4]);
  printf("\n PLT Optimal: %d %d %d %d %d times.", uiModeOptimalPLT[0], uiModeOptimalPLT[1], uiModeOptimalPLT[2], uiModeOptimalPLT[3], uiModeOptimalPLT[4]);

#if CU_CONTENT_TYPE_DECODER
  printf("\n\n Nature Content Mode Distribution: \n");
  for (UInt uiMode = 0; uiMode < 7; uiMode++)
  {
	for (UInt uiDepth = 0; uiDepth < 4; uiDepth++)
	{
	  printf("%d ", uiNatureModeDepth[uiMode][uiDepth]);
	}
	printf("\n");
  }
  printf("\n NonText Content Mode Distribution: \n");
  for (UInt uiMode = 0; uiMode < 7; uiMode++)
  {
	for (UInt uiDepth = 0; uiDepth < 4; uiDepth++)
	{
	  printf("%d ", uiNonTextModeDepth[uiMode][uiDepth]);
	}
	printf("\n");
  }
  printf("\n Text Content Mode Distribution: \n");
  for (UInt uiMode = 0; uiMode < 7; uiMode++)
  {
	for (UInt uiDepth = 0; uiDepth < 4; uiDepth++)
	{
	  printf("%d ", uiTextModeDepth[uiMode][uiDepth]);
	}
	printf("\n");
  }
  printf("\n ColorPatch Content Mode Distribution: \n");
  for (UInt uiMode = 0; uiMode < 7; uiMode++)
  {
	for (UInt uiDepth = 0; uiDepth < 4; uiDepth++)
	{
	  printf("%d ", uiColorPatchModeDepth[uiMode][uiDepth]);
	}
	printf("\n");
  }
  printf("\n Mix Content Mode Distribution: \n");
  for (UInt uiMode = 0; uiMode < 7; uiMode++)
  {
	for (UInt uiDepth = 0; uiDepth < 4; uiDepth++)
	{
	  printf("%d ", uiMixModeDepth[uiMode][uiDepth]);
	}
	printf("\n");
  }
#endif
  /*printf("\n Intra Optimal: %d %d %d %d %d times.", uiModeOptimalIntra[0], uiModeOptimalIntra[1], uiModeOptimalIntra[2], uiModeOptimalIntra[3], uiModeOptimalIntra[4]);
  printf("\n IntraCSC Optimal: %d %d %d %d %d times.", uiModeOptimalIntraCSC[0], uiModeOptimalIntraCSC[1], uiModeOptimalIntraCSC[2], uiModeOptimalIntraCSC[3], uiModeOptimalIntraCSC[4]);
  printf("\n Merge Optimal: %d %d %d %d %d times.", uiModeOptimalMerge[0], uiModeOptimalMerge[1], uiModeOptimalMerge[2], uiModeOptimalMerge[3], uiModeOptimalMerge[4]);
  printf("\n MergeCSC Optimal: %d %d %d %d %d times.", uiModeOptimalMergeCSC[0], uiModeOptimalMergeCSC[1], uiModeOptimalMergeCSC[2], uiModeOptimalMergeCSC[3], uiModeOptimalMergeCSC[4]);
  printf("\n Skip Optimal: %d %d %d %d %d times.", uiModeOptimalSkip[0], uiModeOptimalSkip[1], uiModeOptimalSkip[2], uiModeOptimalSkip[3], uiModeOptimalSkip[4]);
  printf("\n SkipCSC Optimal: %d %d %d %d %d times.", uiModeOptimalSkipCSC[0], uiModeOptimalSkipCSC[1], uiModeOptimalSkipCSC[2], uiModeOptimalSkipCSC[3], uiModeOptimalSkipCSC[4]);
  printf("\n NormalIBC Optimal: %d %d %d %d %d times.", uiModeOptimalNormalIBC[0], uiModeOptimalNormalIBC[1], uiModeOptimalNormalIBC[2], uiModeOptimalNormalIBC[3], uiModeOptimalNormalIBC[4]);
  printf("\n NormalIBCCSC Optimal: %d %d %d %d %d times.", uiModeOptimalNormalIBCCSC[0], uiModeOptimalNormalIBCCSC[1], uiModeOptimalNormalIBCCSC[2], uiModeOptimalNormalIBCCSC[3], uiModeOptimalNormalIBCCSC[4]);
  printf("\n AsyIBC Optimal: %d %d %d %d %d times.", uiModeOptimalAsyIBC[0], uiModeOptimalAsyIBC[1], uiModeOptimalAsyIBC[2], uiModeOptimalAsyIBC[3], uiModeOptimalAsyIBC[4]);
  printf("\n AsyIBCCSC Optimal: %d %d %d %d %d times.", uiModeOptimalAsyIBCCSC[0], uiModeOptimalAsyIBCCSC[1], uiModeOptimalAsyIBCCSC[2], uiModeOptimalAsyIBCCSC[3], uiModeOptimalAsyIBCCSC[4]);
  printf("\n PLT Optimal: %d %d %d %d %d times.", uiModeOptimalPLT[0], uiModeOptimalPLT[1], uiModeOptimalPLT[2], uiModeOptimalPLT[3], uiModeOptimalPLT[4]);
  printf("\n PLTCSC Optimal: %d %d %d %d %d times.", uiModeOptimalPLTCSC[0], uiModeOptimalPLTCSC[1], uiModeOptimalPLTCSC[2], uiModeOptimalPLTCSC[3], uiModeOptimalPLTCSC[4]);*/

#if CU_CONTENT_TYPE_DECODER
  for (int k = 0; k < framecounts; ++k)
  {
	for (int i = 0; i < row; i++)
	{
	  delete[] CNNResult[k][i];
	}
	delete[] CNNResult[k];
  }
  delete[] CNNResult;

  for (int k = 0; k < framecounts; ++k)
  {
	for (int i = 0; i < row; i++)
	{
	  delete[] CNNStep2Result[k][i];
	}
	delete[] CNNStep2Result[k];
  }
  delete[] CNNStep2Result;
#endif

  // destroy application decoder class
  cTAppDecTop.destroy();

  return returnCode;
}

//! \}
