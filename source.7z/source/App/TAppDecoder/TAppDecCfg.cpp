/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2015, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecCfg.cpp
    \brief    Decoder configuration class
*/

#include <cstdio>
#include <cstring>
#include <string>
#include "TAppDecCfg.h"
#include "TAppCommon/program_options_lite.h"
#include "TLibCommon/TComChromaFormat.h"
#ifdef WIN32
#define strdup _strdup
#endif

using namespace std;
namespace po = df::program_options_lite;


//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Public member functions
// ====================================================================================================================

/** \param argc number of arguments
    \param argv array of arguments
 */
Bool TAppDecCfg::parseCfg( Int argc, TChar* argv[] )
{
  Bool do_help = false;
  string cfg_TargetDecLayerIdSetFile;
  string outputColourSpaceConvert;
  Int warnUnknowParameter = 0;

  po::Options opts;
  opts.addOptions()


  ("help",                      do_help,                               false,      "this help text")
  ("BitstreamFile,b",           m_bitstreamFileName,                   string(""), "bitstream input file name")
  ("ReconFile,o",               m_reconFileName,                       string(""), "reconstructed YUV output file name\n"
                                                                                   "YUV writing is skipped if omitted")
  ("WarnUnknowParameter,w",     warnUnknowParameter,                                  0, "warn for unknown configuration parameters instead of failing")
  ("SkipFrames,s",              m_iSkipFrame,                          0,          "number of frames to skip before random access")
  ("OutputBitDepth,d",          m_outputBitDepth[CHANNEL_TYPE_LUMA],   0,          "bit depth of YUV output luma component (default: use 0 for native depth)")
  ("OutputBitDepthC,d",         m_outputBitDepth[CHANNEL_TYPE_CHROMA], 0,          "bit depth of YUV output chroma component (default: use 0 for native depth)")
  ("OutputColourSpaceConvert",  outputColourSpaceConvert,              string(""), "Colour space conversion to apply to input 444 video. Permitted values are (empty string=UNCHANGED) " + getListOfColourSpaceConverts(false))
  ("MaxTemporalLayer,t",        m_iMaxTemporalLayer,                   -1,         "Maximum Temporal Layer to be decoded. -1 to decode all layers")
  ("SEIDecodedPictureHash",     m_decodedPictureHashSEIEnabled,        1,          "Control handling of decoded picture hash SEI messages\n"
                                                                                   "\t1: check hash in SEI messages if available in the bitstream\n"
                                                                                   "\t0: ignore SEI message")
  ("SEINoDisplay",              m_decodedNoDisplaySEIEnabled,          true,       "Control handling of decoded no display SEI messages")
  ("TarDecLayerIdSetFile,l",    cfg_TargetDecLayerIdSetFile,           string(""), "targetDecLayerIdSet file name. The file should include white space separated LayerId values to be decoded. Omitting the option or a value of -1 in the file decodes all layers.")
  ("RespectDefDispWindow,w",    m_respectDefDispWindow,                0,          "Only output content inside the default display window\n")
  ("SEIColourRemappingInfoFilename",  m_colourRemapSEIFileName,        string(""), "Colour Remapping YUV output file name. If empty, no remapping is applied (ignore SEI message)\n")
#if O0043_BEST_EFFORT_DECODING
  ("ForceDecodeBitDepth",       m_forceDecodeBitDepth,                 0U,         "Force the decoder to operate at a particular bit-depth (best effort decoding)")
#endif
  ("OutputDecodedSEIMessagesFilename",  m_outputDecodedSEIMessagesFilename,    string(""), "When non empty, output decoded SEI messages to the indicated file. If file is '-', then output to stdout\n")
  ("ClipOutputVideoToRec709Range",      m_bClipOutputVideoToRec709Range,  false, "If true then clip output video to the Rec. 709 Range on saving")
  ;

  po::setDefaults(opts);
  po::ErrorReporter err;
  const list<const TChar*>& argv_unhandled = po::scanArgv(opts, argc, (const TChar**) argv, err);

  for (list<const TChar*>::const_iterator it = argv_unhandled.begin(); it != argv_unhandled.end(); it++)
  {
    fprintf(stderr, "Unhandled argument ignored: `%s'\n", *it);
  }

  if (argc == 1 || do_help)
  {
    po::doHelp(cout, opts);
    return false;
  }

  if (err.is_errored)
  {
    if (!warnUnknowParameter)
    {
      /* errors have already been reported to stderr */
      return false;
    }
  }

  m_outputColourSpaceConvert = stringToInputColourSpaceConvert(outputColourSpaceConvert, false);
  if (m_outputColourSpaceConvert>=NUMBER_INPUT_COLOUR_SPACE_CONVERSIONS)
  {
    fprintf(stderr, "Bad output colour space conversion string\n");
    return false;
  }

  if (m_bitstreamFileName.empty())
  {
    fprintf(stderr, "No input file specified, aborting\n");
    return false;
  }

  if ( !cfg_TargetDecLayerIdSetFile.empty() )
  {
    FILE* targetDecLayerIdSetFile = fopen ( cfg_TargetDecLayerIdSetFile.c_str(), "r" );
    if ( targetDecLayerIdSetFile )
    {
      Bool isLayerIdZeroIncluded = false;
      while ( !feof(targetDecLayerIdSetFile) )
      {
        Int layerIdParsed = 0;
        if ( fscanf( targetDecLayerIdSetFile, "%d ", &layerIdParsed ) != 1 )
        {
          if ( m_targetDecLayerIdSet.size() == 0 )
          {
            fprintf(stderr, "No LayerId could be parsed in file %s. Decoding all LayerIds as default.\n", cfg_TargetDecLayerIdSetFile.c_str() );
          }
          break;
        }
        if ( layerIdParsed  == -1 ) // The file includes a -1, which means all LayerIds are to be decoded.
        {
          m_targetDecLayerIdSet.clear(); // Empty set means decoding all layers.
          break;
        }
        if ( layerIdParsed < 0 || layerIdParsed >= MAX_NUM_LAYER_IDS )
        {
          fprintf(stderr, "Warning! Parsed LayerId %d is not within allowed range [0,%d]. Ignoring this value.\n", layerIdParsed, MAX_NUM_LAYER_IDS-1 );
        }
        else
        {
          isLayerIdZeroIncluded = layerIdParsed == 0 ? true : isLayerIdZeroIncluded;
          m_targetDecLayerIdSet.push_back ( layerIdParsed );
        }
      }
      fclose (targetDecLayerIdSetFile);
      if ( m_targetDecLayerIdSet.size() > 0 && !isLayerIdZeroIncluded )
      {
        fprintf(stderr, "TargetDecLayerIdSet must contain LayerId=0, aborting" );
        return false;
      }
    }
    else
    {
      fprintf(stderr, "File %s could not be opened. Using all LayerIds as default.\n", cfg_TargetDecLayerIdSetFile.c_str() );
    }
  }

  return true;
}

#if CU_CONTENT_TYPE_DECODER
Bool TAppDecCfg::parseCNN(Int argc, TChar* argv[], Int* framecounts, Int* row)
{
  string CNNPath = "../CNNResults/";
  string SeqName = m_bitstreamFileName;
#if GLOBAL_INFOMATION
  g_inputFileName = m_bitstreamFileName;
#endif
  Int lenSeqName = static_cast<int>(SeqName.size());
  Int pos = static_cast<int>(SeqName.find_last_of('/'));
  Int pos2 = static_cast<int>(SeqName.find_first_of('_'));
  SeqName = SeqName.substr(pos + 1, pos2-pos-1);
  UInt uiSourceWidth = 0;
  UInt uiSourceHeight = 0;
  if (SeqName == "BasketballScreen")
  {
	SeqName = "BasketballScreen_2560x1440";
	uiSourceWidth = 2560;
	uiSourceHeight = 1440;
  }	
  else if (SeqName == "ChineseEditing")
  {
	SeqName = "ChineseEditing_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Console")
  {
	SeqName = "Console_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Desktop")
  {
	SeqName = "Desktop_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "EBURainFruits")
  {
	SeqName = "EBURainFruits_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "FlyingGraphics")
  {
	SeqName = "FlyingGraphics_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Kimono1")
  {
	SeqName = "Kimono1_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Map")
  {
	SeqName = "Map_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "MissionControlClip2")
  {
	SeqName = "MissionControlClip2_2560x1440";
	uiSourceWidth = 2560;
	uiSourceHeight = 1440;
  }
  else if (SeqName == "MissionControlClip3")
  {
	SeqName = "MissionControlClip3_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Programming")
  {
	SeqName = "Programming_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "Robot")
  {
	SeqName = "Robot_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "SlideShow")
  {
	SeqName = "SlideShow_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "WebBrowsing")
  {
	SeqName = "WebBrowsing_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }

  string FileName = CNNPath + SeqName + ".txt";
  *framecounts = 100;
  //cout << m_bitstreamFileName << ' ' << lenSeqName << ' ' << pos << ' ' << pos2 << ' ' << SeqName << ' ' << FileName << endl;
  Column = (uiSourceWidth / 64 + (uiSourceWidth % 64 == 0 ? 0 : 1)) * 2;
  *row = (uiSourceHeight / 64 + (uiSourceHeight % 64 == 0 ? 0 : 1)) * 2;
  UInt row32 = (uiSourceHeight >> 5) + (uiSourceHeight % 32 == 0 ? 0 : 1);

  fstream infile;
  infile.open(FileName, ios::in);
  if (!infile)
  {
	cerr << FileName << endl;
	cerr << "cannot open cnnresults file A" << endl;
	exit(1);
  }

  CNNResult = new string**[*framecounts];
  for (int k = 0; k < *framecounts; k++)
  {
	CNNResult[k] = new string*[(*row)];
	for (int i = 0; i < *row; i++)
	{
	  CNNResult[k][i] = new string[Column];
	}
  }

  for (int k = 0; k < *framecounts; k++)
  {
	for (int i = 0; i < (*row); i++)
	{
	  for (int j = 0; j < Column; j++)
		CNNResult[k][i][j] = "4";
	}
  }

  string c;
#if ONLY_ENABLE_FOR_NATURE || SUPPLEMENT_FOR_NATURE
  UInt uiCount = 0;
#endif
  for (int frame1 = 0; frame1 < *framecounts; frame1++)
  {
	for (int i = 0; i < (row32); i++)
	{
	  for (int j = 0; j < Column; j++)
	  {
		getline(infile, c, '\n');
		CNNResult[frame1][i][j] = c;
#if ONLY_ENABLE_FOR_NATURE || SUPPLEMENT_FOR_NATURE
		if (c == "0")
		{
		  uiCount++;
		}
#endif
		if (infile.eof())     break;
	  }
	}
  }
#if ONLY_ENABLE_FOR_NATURE || SUPPLEMENT_FOR_NATURE
  if (float(uiCount) / (*framecounts) / (*row) / Column > 0.9)
  {
#if ONLY_ENABLE_FOR_NATURE
	bEnableAWET = true;
#endif
#if SUPPLEMENT_FOR_NATURE
	bEnableSupplementForNature = false;
#endif
  }
  else
  {
#if ONLY_ENABLE_FOR_NATURE
	bEnableAWET = false;
#endif
#if SUPPLEMENT_FOR_NATURE
	bEnableSupplementForNature = true;
#endif
  }
#endif
  infile.close();
  return 1;

}
Bool TAppDecCfg::parseStep2CNN(Int argc, TChar* argv[], Int* framecounts, Int* row)
{
  string CNNPath = "../CNNResults/";
  string SeqName = m_bitstreamFileName;
  Int lenSeqName = static_cast<int>(SeqName.size());
  Int pos = static_cast<int>(SeqName.find_last_of('/'));
  Int pos2 = static_cast<int>(SeqName.find_first_of('_'));
  SeqName = SeqName.substr(pos + 1, pos2 - pos - 1);
  UInt uiSourceWidth = 0;
  UInt uiSourceHeight = 0;
  if (SeqName == "BasketballScreen")
  {
	SeqName = "BasketballScreen_2560x1440";
	uiSourceWidth = 2560;
	uiSourceHeight = 1440;
  }
  else if (SeqName == "ChineseEditing")
  {
	SeqName = "ChineseEditing_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Console")
  {
	SeqName = "Console_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Desktop")
  {
	SeqName = "Desktop_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "EBURainFruits")
  {
	SeqName = "EBURainFruits_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "FlyingGraphics")
  {
	SeqName = "FlyingGraphics_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Kimono1")
  {
	SeqName = "Kimono1_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Map")
  {
	SeqName = "Map_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "MissionControlClip2")
  {
	SeqName = "MissionControlClip2_2560x1440";
	uiSourceWidth = 2560;
	uiSourceHeight = 1440;
  }
  else if (SeqName == "MissionControlClip3")
  {
	SeqName = "MissionControlClip3_1920x1080";
	uiSourceWidth = 1920;
	uiSourceHeight = 1080;
  }
  else if (SeqName == "Programming")
  {
	SeqName = "Programming_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "Robot")
  {
	SeqName = "Robot_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "SlideShow")
  {
	SeqName = "SlideShow_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  else if (SeqName == "WebBrowsing")
  {
	SeqName = "WebBrowsing_1280x720";
	uiSourceWidth = 1280;
	uiSourceHeight = 720;
  }
  string FileName = CNNPath + SeqName + "_step2.txt";
  *framecounts = 100;
  Column = (uiSourceWidth / 64 + (uiSourceWidth % 64 == 0 ? 0 : 1)) * 2;
  *row = (uiSourceHeight / 64 + (uiSourceHeight % 64 == 0 ? 0 : 1)) * 2;
  UInt row32 = (uiSourceHeight >> 5) + (uiSourceHeight % 32 == 0 ? 0 : 1);

  fstream infile;
  infile.open(FileName, ios::in);
  if (!infile)
  {
	cerr << FileName << endl;
	cerr << "cannot open cnnstep2results file B" << endl;
	exit(1);
  }

  CNNStep2Result = new string**[*framecounts];
  for (int k = 0; k < *framecounts; k++)
  {
	CNNStep2Result[k] = new string*[(*row)];
	for (int i = 0; i < *row; i++)
	{
	  CNNStep2Result[k][i] = new string[Column];
	}
  }

  for (int k = 0; k < *framecounts; k++)
  {
	for (int i = 0; i < (*row); i++)
	{
	  for (int j = 0; j < Column; j++)
		CNNStep2Result[k][i][j] = "4";
	}
  }

  string c;
  for (int frame1 = 0; frame1 < *framecounts; frame1++)
  {
	for (int i = 0; i < (row32); i++)
	{
	  for (int j = 0; j < Column; j++)
	  {
		getline(infile, c, '\n');
		CNNStep2Result[frame1][i][j] = c;
		if (infile.eof())     break;
	  }
	}
  }

  infile.close();
  return 1;
}
#endif
//! \}
